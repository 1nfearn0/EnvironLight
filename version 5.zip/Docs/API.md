# EnvironCore v0.5 local API

The device serves JSON over HTTP and live data over WebSocket on its local IP.
Read routes are available on the LAN. Mutation and audio-download routes require
`Authorization: Bearer <device-api-key>`. The configured key must contain at
least 16 characters; controls stay disabled when it is blank.

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/v1/manifest` | Identity, profile, pins, rates, retention and capability truth |
| GET | `/api/v1/live` | Current schema-3 sensor snapshot |
| GET | `/api/v1/health` | Memory, storage, acquisition and transport health |
| GET | `/api/v1/history?resolution=60&limit=240&before_seq=…` | Ascending history page; resolutions 1, 10, 60, 300 or 3600 seconds |
| GET | `/api/v1/events?limit=100&before_seq=…` | Timestamped event evidence page |
| GET | `/api/v1/scenes` | Named reference scenes |
| GET | `/api/v1/radio` | Connection, surveys, anonymous observations and named-device evidence |
| GET | `/api/v1/captures` | Manual capture state and format metadata |
| POST | `/api/v1/captures` | Arm `{ "seconds": 5 }`, 10 or 30 |
| GET | `/api/v1/captures/download` | Start the armed capture and stream its WAV file |
| POST | `/api/v1/scenes` | Save `{ "name": "Room reference" }` after sufficient valid history |
| POST | `/api/v1/radio/enroll` | Open a timed enrolment window, then attach a name to an observed ID |
| POST | `/api/v1/radio/rename` | Rename a known device |
| POST | `/api/v1/radio/archive` | Disable a known record without deleting its identity |
| POST | `/api/v1/radio/scan` | Request a bounded Wi-Fi survey |
| POST | `/api/v1/radio/provision` | Store one of three trusted local networks |
| POST | `/api/v1/ota` | Upload an ESP-IDF application image as `application/octet-stream`, authenticated by `X-EC-OTA-Signature`; verify it, select the inactive OTA slot and reboot |
| GET | `/api/v1/export` | CSV page from the bounded history store |
| GET | `/api/v1/legacy` | Read-only manifest of preserved older CSV archives |
| GET | `/ws/v1/live` | Binary audio/pressure frames plus JSON light and snapshot frames |

History resolutions of 300 seconds and 3,600 seconds are calculated from the
retained one-minute records. This keeps the 24-hour and 28-day plots bounded
while using energy-correct audio averaging and arithmetic physical-sensor
averaging. Missing data stays null and contributes no invented zero.

The WebSocket binary header is 20 bytes, little-endian: magic `0x4345`, version
1, type, sequence, monotonic microseconds, payload length and quality flags.
Type 1 is the fixed 660-byte audio summary; type 3 is the fixed 76-byte pressure
summary. The exact field layout is defined once in `ec_protocol.h` and tested
against the browser decoder.

Legacy `/api/live`, `/api/audio`, `/api/light`, `/api/spectrum` and `/data`
reads remain available for existing EnvironCore dashboards. Unknown API routes
return 404.

Unknown BLE detail is aggregate-only in normal operation. An authorised timed
enrolment window temporarily exposes rotating candidate tokens; successful
enrolment closes the window. Expiry is enforced by the server as well as the
browser. Browser WebSocket upgrades require an Origin authority matching Host,
and that Host must be the current device IPv4 address or its own mDNS name.

OTA uses a separate pre-shared key of at least 32 characters. The browser sends
`HMAC-SHA256(key, "EnvironCore-OTA-v1" || SHA256(image) || uint64be(size))` as
lowercase hex in `X-EC-OTA-Signature`; the key itself is never transmitted.
The running image remains pending for a 30-second grace period and is confirmed
only after the server and fresh live audio acquisition are healthy. Otherwise
the board reboots and the rollback-enabled bootloader restores the prior slot.
