# Validation record

## Automated evidence

`tools/test-host.sh` compiles portable C with AddressSanitizer and
UndefinedBehaviorSanitizer, then runs the dashboard tests with Node. It covers:

- FFT frequency and level, energy-domain sound averaging, A/C weighting,
  psychrometric calculations, pressure height and exposure hysteresis;
- Bosch compensation fixture, DHT checksum/range rejection and adaptive-light
  boundaries;
- binary packet bounds/endian layout and WAV duration/header correctness;
- named radio enrolment, persistence semantics, anonymous expiry and bounded
  eviction;
- history wrap, pagination, one-hour/day-range rollups, CRC damage, partial
  writes, reboot recovery, missing data and reference-scene requirements;
- PCHIP behaviour, recurrence/correlation edge cases, explicit gaps, CSV
  escaping, snapshot validation, bounded browser buffers and live-frame decode.

The two application targets are built with ESP-IDF 5.5.1. Release binaries are
generated with blank credentials and passive observer-only NimBLE security
features disabled because neither profile initiates or accepts BLE connections.

## Physical commissioning still required

| Check | Acceptance evidence |
|---|---|
| Audio | Continuous operation without DMA/DSP drops; known-tone bin; provisional dBA offset compared with the chosen reference |
| AS7341 | Complete two-phase frames near the stated rate; exposure settles without oscillation under dim, normal and saturated light |
| BMP280 | Achieved sample rate and noise reported; no bus starvation or implausible compensation values |
| DHT22 | Stable 2.5-second cadence, checksum failures counted, heat-placement bias recorded |
| Radio coexistence | 24-hour Wi-Fi/BLE/audio run with reconnect, survey and overrun counters reviewed |
| Storage | Reboot recovery, full-ring wrap and legacy archive preservation checked on the existing flash |
| Interface | All eight views checked on the intended iPhone in portrait and landscape; capture download verified at 5, 10 and 30 seconds |
| OTA | Successful inactive-slot update, interrupted-upload survival and rollback from a deliberately unconfirmed image |
| Web boundary | Device-page WebSocket accepted; deliberately mismatched browser Origin rejected |
| BLE privacy | Candidate detail visible only during enrolment; stale token rejected; aggregate bins remain available outside the window |

Absolute sound level, spectral irradiance, lux and correlated colour temperature
remain estimates until the assembly is calibrated against suitable references.
The dashboard exposes these limits beside the measurements.
