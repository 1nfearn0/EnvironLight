# EnvironCore remote access — simple implementation plan

Prepared 12 September 2026 for Oliver's EnvironCore v0.2.

## The result

When this is finished, the ESP32 stays at home collecting data and the travelling laptop opens the same dashboard at:

**http://192.168.1.131/**

Tailscale carries that connection securely through a small always-on device at home. There is no router port forwarding and the ESP32 remains unavailable from the ordinary public internet.

## What is needed

1. **The existing Plusnet Hub 2** remains the main router.
2. **EnvironCore** remains powered and connected to home Wi-Fi.
3. **The travelling laptop** runs the Tailscale application already downloaded.
4. **One always-on home gateway** runs Tailscale on the same home network as EnvironCore.

Use the first gateway option already available:

- A spare Windows or Linux laptop/desktop that can remain powered at home.
- Any Raspberry Pi 3/4/5 or Pi Zero 2 W already available.
- A small used Linux thin client or mini PC.
- If none is available, obtain a Pi Zero 2 W or similar low-power Linux device, a suitable microSD card and power supply.

The old modem-routers are not required. Do not replace the Plusnet Hub 2 or flash the old routers for this job. OpenWrt marks the Sagem F@ST2704N as a low-resource 4 MB/32 MB device and says its support ended in 2022. The Vodafone Connect router is not a sensible supported Tailscale host either. They can remain spare equipment.

## Stage 1 — finish the physical EnvironCore rig

1. Solder a matching male header into the SCD40 breakout's plated holes.
2. Check that adjacent pads are not bridged with solder.
3. With power disconnected, wire:

   - SCD40 VCC/VIN to ESP32 3V3
   - SCD40 GND to common GND
   - SCD40 SDA to GPIO8
   - SCD40 SCL to GPIO9

4. Power EnvironCore from a dependable USB supply through the socket labelled COM.
5. Confirm the dashboard shows a real CO2 value and that SHT45, LTR390 and the microphone remain healthy.

A pushed lead through an unsoldered hole is suitable only for a supervised test. It is not dependable for an unattended logger.

## Stage 2 — make the ESP32 address dependable

1. Open the Plusnet Hub 2 administration page while at home.
2. Find the device currently using **192.168.1.131**.
3. Create a DHCP reservation so that the ESP32 always receives **192.168.1.131**.
4. Restart EnvironCore once and confirm the dashboard still opens locally.

Do not create a port-forwarding rule, DMZ rule or remote-management rule.

## Stage 3 — prepare the home gateway

### Recommended Linux/Raspberry Pi route

1. Install Raspberry Pi OS Lite or another supported Debian/Ubuntu Linux system.
2. Connect it to the Plusnet Hub 2 by Ethernet if convenient; home Wi-Fi also works.
3. Give it a clear name such as **environ-gateway**.
4. Install Tailscale using its official Linux instructions and sign in to the same Tailscale account as the travelling laptop.
5. Enable IPv4 forwarding on the gateway.
6. Advertise only EnvironCore's host route:

   `sudo tailscale set --advertise-routes=192.168.1.131/32`

7. In the Tailscale admin console, open **Machines**, choose **environ-gateway**, open **Subnets**, approve **192.168.1.131/32**, and save.
8. For a permanent home gateway, disable key expiry for this one machine after protecting the Tailscale account with multifactor authentication and keeping the gateway updated.

The official Tailscale subnet-router guide contains the current IP-forwarding commands and route-approval screens: https://tailscale.com/docs/features/subnet-routers

The official Linux installer is: https://tailscale.com/docs/install/linux

### Spare Windows-computer route

Windows can also be a subnet router, but the computer must remain awake, signed in to Tailscale and configured for IP forwarding. Use this only if a spare Windows computer is already available. A small Linux gateway is easier to keep stable and uses less power.

## Stage 4 — limit access

Route approval makes the address reachable; the Tailscale access policy decides who may use it. Keep access limited to Oliver's Tailscale identity and TCP port 80 at **192.168.1.131**. Tailscale now recommends grants for new access policies.

Official guidance:

- Grants: https://tailscale.com/docs/features/access-control/grants
- Route injection and approval: https://tailscale.com/docs/reference/route-injection

Do this after the first connectivity test so that a policy typo does not obscure whether routing itself works.

## Stage 5 — prove it works before the next trip

1. At home, confirm **http://192.168.1.131/** works normally over home Wi-Fi.
2. Confirm the laptop and **environ-gateway** both appear connected in the Tailscale Machines page.
3. Put the laptop on a phone hotspot or another network so it is no longer using home Wi-Fi.
4. Keep Tailscale connected on the laptop.
5. Open **http://192.168.1.131/**.
6. Confirm live values update for at least two minutes.
7. Restart the home gateway, wait for it to reconnect automatically, and repeat the outside-network test.
8. Restart EnvironCore and confirm it returns to 192.168.1.131 and restores its saved history.

Do not leave for a trip until both restart tests pass.

## If it does not open remotely

Check these in order:

1. EnvironCore still opens from another device on home Wi-Fi.
2. The home gateway is powered, online and visible in Tailscale Machines.
3. The **192.168.1.131/32** route is advertised and approved.
4. The travelling laptop is connected to Tailscale and accepting subnet routes; Windows accepts them by default.
5. The Tailscale access policy allows Oliver's identity to reach TCP port 80 at 192.168.1.131.
6. EnvironCore still owns 192.168.1.131 in the Plusnet Hub 2.

## What can be done while no gateway exists

Leave EnvironCore powered. It continues sampling, keeps 72 hours of minute history in PSRAM and commits rotating history to internal flash for roughly 27–28 days. The laptop and dashboard do not need to remain open. Remote viewing begins only after an always-on home gateway has been installed and tested.

## One-session checklist for when Oliver is home

- [ ] Choose the spare computer or small Linux gateway.
- [ ] Solder the SCD40 header and confirm all sensors locally.
- [ ] Reserve 192.168.1.131 in the Plusnet Hub 2.
- [ ] Install and sign in to Tailscale on the home gateway.
- [ ] Enable IP forwarding.
- [ ] Advertise and approve 192.168.1.131/32.
- [ ] Test from a phone hotspot.
- [ ] Restrict access to Oliver and TCP port 80.
- [ ] Test gateway and ESP32 restarts.
- [ ] Label the gateway power supply and leave both devices ventilated.
