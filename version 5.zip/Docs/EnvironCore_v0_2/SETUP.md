# EnvironCore v0.2 — Oliver's room observatory

The firmware and entire dashboard are in one Arduino sketch. Keep **partitions.csv** alongside it: this small file defines the 16 MB flash layout. No external Arduino libraries, web assets or filesystem-uploader plugin are required.

## Upload in Arduino IDE

1. Open **EnvironCore_v0_2/EnvironCore_v0_2.ino**. Keep the enclosing folder's name unchanged.
2. Enter your Wi-Fi name and password in **WIFI_SSID** and **WIFI_PASSWORD** near the top. Edit them locally; do not send the password in chat.
3. Use **esp32 by Espressif Systems 3.3.11** in Boards Manager. This is the installed package used for verification.
4. Set:

| Tools option | Setting |
|---|---|
| Board | ESP32S3 Dev Module |
| Flash Size | 16MB (128Mb) |
| PSRAM | OPI PSRAM |
| Flash Mode | QIO 80MHz |
| Partition Scheme | Custom — uses the supplied partitions.csv |
| CPU Frequency | 240 MHz |
| Core Debug Level | None |
| Erase All Flash Before Sketch Upload | Disabled |
| USB Mode | Hardware CDC and JTAG |
| USB CDC On Boot | Enabled when using the native USB socket |
| Port | The board's current port; previously COM12, but it may change |

**Using the USB-to-UART socket instead?** Set **USB CDC On Boot to Disabled** and use that socket's port for uploading and Serial Monitor. Serial output follows this choice. The firmware starts from a USB power supply without waiting for a computer.

5. Verify and upload. If connection fails, hold BOOT, tap RESET, release BOOT, select the detected port and retry.
6. Open Serial Monitor at **115200**, with **Newline** selected. It prints the actual dashboard IP. Open **http://that-IP/** from the same home LAN. The former **192.168.1.131** address is not guaranteed until reserved in your router. The optional hostname is **http://environcore.local/**; your previous Windows setup did not resolve it reliably.

### Initialise history once

After a first upload with this layout, the serial output will normally say the history filesystem is unavailable. The firmware never auto-formats it.

For a **new history partition**, send **FORMAT ENVIRONCORE** in Serial Monitor. This erases and initialises the selected history partition. Wait for **Flash ready**. A mounted filesystem refuses the command, protecting its existing history.

**Export anything valuable from old firmware before changing partition layouts or formatting.** Do not use this command to recover a damaged filesystem containing data you need. Keep the same partition layout for later v0.2 uploads.

## After upload

- Allow about 3 seconds for the first readings and about 10 seconds for both light modes to settle.
- The SCD40 reports its first genuine CO2 value about 5 seconds after it is found.
- Acoustic event detection starts after about 32 seconds of background learning.
- First history record: 1 minute; first chart line: 2 minutes.
- First persistent flash batch: 5 completed minutes.
- Diagnostics should show about **8 MB PSRAM**, **4,320 RAM records**, and **12.9 MiB filesystem capacity** with the specified settings.
- Keep the SHT45 away from the ESP32's heat and allow it to settle.

No example data is embedded in the firmware. A laptop design preview, if open, is explicitly labelled as simulated.

## Verified wiring

| Signal | ESP32-S3 |
|---|---|
| SHT45, LTR390 and SCD40 SDA | GPIO8 |
| SHT45, LTR390 and SCD40 SCL | GPIO9 |
| SHT45 address | 0x44 |
| LTR390 address | 0x53 |
| SCD40 address | 0x62 |
| SCD40 VCC / VIN | 3V3 for this ESP32 bus |
| ICS-43434 BCLK / SCK | GPIO16 |
| ICS-43434 WS / LRCLK | GPIO17 |
| ICS-43434 SD / DOUT | GPIO15 |
| ICS-43434 L/R | GND — left channel |
| ICS-43434 VDD | 3V3 |
| All grounds | Common GND |

Retain your existing working wiring. Do not power the microphone from 5 V.
The circular plated holes on a breakout board are intended for soldered header pins. A pushed-in lead may work for a short supervised test, but solder the header before unattended use.

## Your extras

- **While you were away:** recorded temperature range since this browser's previous visit, limited to the chosen window and retained history.
- **Dew point and air VPD:** condensation threshold and air drying potential. Surface/leaf temperatures are not measured.
- **Light accumulation:** measured lux-hours, with missing intervals excluded. This is not plant DLI.
- **Acoustic event journal:** sudden rises above learned background, highlighting bright/high-frequency candidates. These can be keys, speech, electronics or birds; there is no presence detection or bird identification.
- **Visible data quality:** blanks for stale readings, gaps across reboots and clock changes, audio coverage, saturation and storage diagnostics.
- **Real CO2 story:** live SCD40 ppm, simple ventilation guidance, a CO2 history chart and auxiliary SCD40 temperature/humidity for comparison with the SHT45.

## Storage and export

The PSRAM ring holds **4,320 minute records / 72 hours**, using **432,000 bytes** (about 0.41 MiB). PSRAM is volatile. A 240-record internal-RAM fallback is attempted if PSRAM is unavailable, with a dashboard warning. Audio DMA, working buffers and task stacks stay internal.

Flash uses 28 rotating files of up to 1,440 records. CO2-capable records are 100 bytes: about **4.03 MB** of record payload at full retention, plus headers and filesystem overhead. Normal continuous operation retains approximately **27–28 days**. Original 88-byte v2 archive segments remain readable and exportable; the firmware seals them and starts a 100-byte v3 segment for new CO2 records. Interrupted/corrupt tails can shorten retention. Only the oldest file within this firmware's /ec2 directory is replaced when the archive rolls over.

Flash commits **five records every five minutes**. A power cut may lose the uncommitted batch and current partial minute: roughly up to five minutes. Record/header checksums identify partial or damaged tails after reboot, preserving valid earlier records. Write or read-back failure stops flash logging and raises a warning; RAM collection continues. Export recent history and investigate rather than treating the archive as infallible.

- **Recent CSV:** all retained RAM minutes, including uncommitted records.
- **All saved CSV:** all valid saved archive files, oldest first.
- **Segment CSV:** a selected saved block.
- Export requests are paginated; the independent collector/audio tasks continue. Rotation during an export fails explicitly instead of silently omitting data.

Filenames use dd-MM-yy; CSV timestamps are UTC ISO 8601. Charts use Europe/London with BST/GMT. Before time sync, epoch is zero and boot ID + uptime preserve ordering. Times are not invented or backfilled. After sync, charts use timestamped rows; unsynchronised rows remain available in CSV.

### CSV columns

Timestamp_utc is followed by:
seq, epoch, boot, uptime_s, span_ms, temperature, humidity, lux, uvi, rms, peak, low, mid, high, coverage, clip, als_raw, uv_raw, co2, scd_temperature, scd_humidity, events, flags.

Temperature is °C, RH and coverage/clip/band shares are percentages, sound is dBFS. Span is milliseconds. Sensor values are valid-sample means per interval; RMS is energy-averaged, peak is the largest sampled amplitude, and bands are aggregated spectral energy shares. Raw ALS/UV means may mix gain settings and are diagnostic only.

Flags are a bit mask: 1 = valid clock; 2 = at least 25 SHT readings; 4 = at least 20 ALS readings; 8 = at least 20 UV readings; 16 = at least 95% audio coverage; 32 = latest ALS saturated; 64 = latest UV saturated; 128 = at least one valid SCD40 measurement. Charts exclude invalid values for the selected metric. Flags 32/64 describe the latest reading, not every reading in the minute.

## Measurement details

**Audio:** continuous 24 kHz, standard Philips I2S with two 32-bit slots, signed 24-bit left-channel extraction and DC blocking. Every sample contributes to average/peak metrics. Smoothing occurs in the energy domain. A full-scale sine has approximately -3.01 dBFS RMS under this convention. Peak is sampled peak, not intersample true peak. These are **relative digital dBFS, not calibrated SPL or dBA**.

A 512-point Hann-window FFT runs on every block, with 46.875 Hz bin spacing. Band shares are relative to the total energy within 80 Hz–8 kHz: low 80–400 Hz, mid 400 Hz–2 kHz, high 2–8 kHz. Edges follow available bins. All-zero digital input is treated as suspect. The device retains features, not audio recordings. Event candidates have a three-second cooldown; they are not a classifier.

**LTR390:** 20-bit / 400 ms integration, 500 ms repetition, alternating ALS/UV and one discarded conversion after each switch. Gains are independent, use hysteresis, and decrease near saturation. Lux = 0.6 × ALS / (gain × 4). Estimated UVI = UV / (2300 × gain / 18). Separate ALS/UV window factors default to 1.0. Every conversion uses its acquisition gain. Raw counts change with gain.

UV describes the sensor's position, not outdoor exposure. Glass, angle, enclosure and calibration affect the result. Do not use it to determine sun protection. Use gain-corrected lux/UVI for trends across gain changes.

**SHT45:** high-repeatability measurements every two seconds, no heater, CRC validation for both values, physical range checks and stale-value handling. Its compact direct driver is embedded, avoiding external library dependencies.

**SCD40:** native periodic measurement mode at its specified five-second cadence. The driver checks the data-ready word and CRC on all three returned words before accepting CO2, temperature and humidity. A failed transaction triggers a clean stop/restart sequence after a retry delay. SCD40 temperature and humidity are diagnostic companions; self-heating and board placement can shift them, so the separate SHT45 remains the room climate reference. CO2 is not estimated from those values.

## API, future sensors and network

The old /data fields remain: **temperature, humidity, light, uv, noiseFast, noiseSmooth**. Your existing logger can keep reading them. Failed/stale values now become JSON null. NoiseFast is the latest approximately 21 ms block; noiseSmooth is a five-second energy-domain smoother. NoiseAverage is about a one-second aggregate.

The /history, /archive and /archive-page endpoints provide bounded reads for the dashboard. SCD40 is active at address 0x62 and adds top-level co2, scdTemperature, scdHumidity, scdOk, freshness and error fields to /data. PM1006K remains a null planned sensor. No PM UART pins or power rails are configured; verify its exact variant, voltage, UART pins, warm-up and packet checksum before connecting it.

The server is read-only HTTP on port 80 with LAN-subnet and Host-header checks, no permissive CORS, no external web assets, and no remote format/reboot/OTA/configuration route. There is no login or TLS: devices already on the permitted LAN can read it. Router/proxy configuration can change reachability, so keep normal home-network isolation. Do not port-forward it.

Credentials are compiled into the firmware for simplicity, never printed or returned over HTTP. Do not share a sketch after filling them in. ENABLE_NTP permits outgoing clock synchronisation only, with no sensor uploads; disable it if no intentional internet service use is wanted, accepting unsynchronised time after reboot.

The ESP32 keeps collecting with the laptop away, including during Wi-Fi outages, and reconnects automatically. **Tailscale on the travelling laptop alone does not provide remote access to this ESP32.** Remote viewing still needs an always-on home gateway/subnet router or another secure route home. This build does not create one.

## Sources and verification

The exact installed Arduino-ESP32 3.3.11 headers/board definitions were checked. See REVIEW.txt for actual compile and test results.

- [Sensirion SHT4x datasheet](https://sensirion.com/resource/datasheet/sht4x): commands, CRC and conversions.
- [TDK ICS-43434 datasheet](https://product.tdk.cn/system/files/dam/doc/product/sw_piezo/mic/mems-mic/data_sheet/ds-000069-ics-43434-v1.2.pdf): I2S format and valid sample rates.
- [Espressif I2S API](https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/peripherals/i2s.html): channel API, DMA and overflow callbacks.
- [Adafruit LTR390 reference implementation](https://github.com/adafruit/Adafruit_CircuitPython_LTR390/blob/main/adafruit_ltr390.py): gain, resolution, measurement period and conversions.

Physical sensor accuracy, signal integrity and long-duration/power-cut behaviour still require testing on your board. No upload or router change has been performed.

## Agreed Lab hierarchy

Rig root: C:\Lab\Home Systems\Environmental Monitoring\EnvironCore

- Firmware: Code\ESP32-S3\EnvironCore_v0_2\EnvironCore_v0_2.ino
- Required partition layout: Code\ESP32-S3\EnvironCore_v0_2\partitions.csv
- This guide and review: Docs\EnvironCore_v0_2\
- Save dashboard CSV downloads to Data\Exports\ (your browser may initially put them in Downloads).
- Existing live logger output remains in Data\Raw\; derived analysis belongs in Data\Processed\.
