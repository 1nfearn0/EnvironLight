# EnvironCore v0.5 — Canonical Design Specification

**Status:** Working design revision 2  
**Date:** 16 October 2026  
**Platform:** EnvironCore family  
**First complete hardware profile:** EnvironLight, ESP32-S3-WROOM-1 N16R8  
**Future radio profile:** RadioScout, DOIT ESP32 DevKit V1 / ESP32-WROOM-32D  

## 1. Purpose

EnvironCore v0.5 is a local-first room observatory, not a cosmetic revision of the v0.4 dashboard. It continuously measures the acoustic, spectral-light, atmospheric and radio environment; exposes measurement quality and limitations; keeps useful history; and presents the result as a responsive scientific instrument that remains warm, calm and recognisably Sun-Drunk.

The first complete device is **EnvironLight**. **EnvironCore** is the family and shared platform. Future boards join the family through capabilities rather than duplicated sketches or hard-coded dashboard assumptions.

The engineering plan supplies the achievable instrument design. This specification records the user's updates and the family-wide implementation contracts. Hardware-only claims remain explicitly unverified until the built firmware runs on the physical board.

## 2. Authority and decision order

When sources disagree, implementation follows this order:

1. Decisions made by the user in the current design conversation.
2. *EnvironCore v0.5 Instrument Mode: Engineering Architecture and Delivery Plan* for the technical plan and the balance between ambition, detail and achievable engineering.
3. Known-working v0.4.1 configurations and code that directly fit, or can be cleanly adapted to, that architecture. Working pins, buses and behaviour are evidence; they do not overrule the target design.
4. *Engineering Handoff and Final Delivery* for execution discipline, compatibility and delivery checks.
5. *A Research-Grade Room Observatory* for scientific and visual inspiration.

Existing code is evidence, not a constraint. It is retained only when it fits the new design without preserving a weak architecture.

### 2.1 Departures from the engineering report

The original engineering report remains intact as a reference. Its earlier Arduino packaging, no-PCM-transport policy, wake-word option and one-click device forgetting are superseded by the user's decisions below. All other departures require a documented reason and a check against primary documentation or measurements.

| Subject | Current direction | Reason or verification |
|---|---|---|
| Build system | One ESP-IDF workspace; native I2S and HTTP/WebSocket components | User chose to move directly to the final framework. ESP-IDF v5.5 documentation confirms DMA I2S acquisition and WebSocket support. |
| Pressure acquisition | Restore the engineering target of 50 Hz; 20 Hz is the normal browser stream | Revision 1 had reduced acquisition to 20 Hz without evidence. Bosch BST-BMP280-DS001-26, sections 3.8–3.10, defines conversion timing and shadowed reads. A 50 Hz poll is not proof of 50 distinct conversions. |
| AS7341 exposure | Restore the 20–70% preferred band, 70–85% low headroom and immediate reduction above 85%; low-frame thresholds 8–20% and below 8% | These are the engineering plan's controller choices, not manufacturer accuracy guarantees. The manufacturer's integration formula and gain settings are checked separately. |
| Frontend | Locally bundled uPlot, vanilla ES modules, custom CSS, WebGL2 waterfall with Canvas2D fallback, monotone cubic interpolation | Retain the engineering plan's lean stack. Pin the exact tested release during implementation; no arbitrary framework migration. |
| Audio captures | Explicit 5/10/30-second downloads and optional LAN PCM | User decision; no playback or transcription. |
| Wake word | Deferred | User decision. |
| Device names | Persistent registry, no ordinary delete button | User decision. |
| Family expansion | EnvironCore capability contracts and later disabled WROOM RadioScout target | User decision. Future drivers do not become claimed working profiles merely by appearing in a manifest. |
| Visual system | Official Dawn and Dusk values in section 13 | User's palette images and 16 October direction supersede the dark-theme wording in the handoff. |
| Longer retention | Previously agreed tiered retention, enforced by measured byte budgets | User approved the horizons; this is not permission to allocate unbounded RAM or rewrite valid old archives. |

### 2.2 Source checks for implementation

Use the Bosch BMP280 datasheet **BST-BMP280-DS001-26 revision 1.26**, the ams AS7341 datasheet **DS000504 version 3**, and documentation for the exact pinned ESP-IDF release. Recheck the relevant source whenever a driver API, clock, buffer placement, exposure, oversampling or timing choice changes. Record the document revision, chosen settings, calculation, test and result in the build/validation notes. A setting copied from another board is an initial hypothesis until it agrees with this wiring and sensor revision.

## 3. Locked decisions

| Area | Decision |
|---|---|
| Framework | Move directly to ESP-IDF. Do not maintain parallel Arduino and IDF applications. An Arduino library may be wrapped as an IDF component only when it materially reduces work and remains isolated behind a component interface. |
| Product naming | EnvironCore is the family/platform. EnvironLight is the first full sensor profile. RadioScout is the later WROOM-32D radio profile. |
| Primary board | ESP32-S3-WROOM-1 N16R8 with 16 MB flash and 8 MB PSRAM. |
| Audio | Continuous on-device analysis, rich waveform/spectrum/spectrogram, optional full-rate LAN PCM, and explicit 5/10/30-second manual download captures. No playback UI. No speech transcription. |
| Wake word | Deferred. The interfaces may reserve a future capability, but no wake-word engine, model or UI is included in v0.5. |
| Light | AS7341 is a first-class instrument with adaptive exposure, raw and normalised views, a continuous-looking but honestly labelled interpolated envelope, per-channel history and a waterfall. |
| Atmosphere | DHT22 and BMP280 are retained, with honest cadence, quality states and derived metrics. Pressure is treated as a potentially dynamic signal, not merely a weather-card number. |
| Radio | Meaningful Wi-Fi and BLE observation is included in EnvironLight. More intrusive or channel-hopping Wi-Fi analysis is isolated for the later RadioScout. |
| Known devices | Persist enrolled device names and evidence. No normal dashboard delete button. Do not permanently identify unknown neighbouring devices. |
| Remote access | Device remains a local service. Remote access is through the Lenovo host and Tailscale; no public port and no mandatory cloud. |
| Transport | WebSocket is primary for live streams. REST remains for manifests, configuration, diagnostics, history, exports and v0.4 compatibility. Sensing continues with no browser connected. |
| History | Derived high-rate data about 10 minutes; 1-second summaries about 60 minutes; 10-second summaries about 24 hours; 1-minute summaries about 28 days; bounded event and diagnostic logs. |
| Visual direction | Official Dawn and Dusk colours: sunny beach party, summer-evening poolside laughter, Tuscany and the French Riviera with a slight Miami Deco influence. Light warm surfaces, playful colour and precise plots. |
| Code navigation | A documented ESP-IDF workspace with explicit app entry points, cohesive components, short files and no giant generated header containing the entire dashboard. |

## 4. Baseline audit: v0.4.1 ZIP

The two supplied v0.4.1 ZIP files are byte-identical. Their SHA-256 is `925f39d8d3c32b8a6d87026bc9fbf80b0acdf9258255040db5b9ff592576d658`.

The archive contains an Arduino sketch composed almost entirely of headers, including a 1,339-line embedded dashboard and an 856-line API header. It is a useful working prototype, but not a maintainable base structure for the new instrument.

### 4.1 Preserve or port

| Baseline element | v0.5 treatment |
|---|---|
| EnvironLight wiring | Preserve as the initial hardware profile: DHT22 GPIO 4; BMP280 SDA/SCL GPIO 6/7; AS7341 SDA/SCL GPIO 8/9; ICS43434 SD/BCLK/WS GPIO 15/16/17. Confirm electrically on hardware before release. |
| Sensor inventory | Preserve DHT22, BMP280, AS7341 and ICS43434 support. |
| Independent I2C buses | Preserve the intent; implement with IDF bus/device handles and recoverable drivers. |
| Trusted-network selection and reconnection | Port the behaviour, but move credentials out of source and improve state reporting. |
| Offline sensing | Preserve as a non-negotiable system property. |
| Health counters and stale-data invalidation | Port and extend with acquisition rate, latency, queue and drop metrics. |
| Monotonic boot ID, sequence numbers and wall-clock sync | Preserve and formalise in every record envelope. |
| LittleFS history and reboot recovery | Preserve working mount, recovery, legacy CSV parsing and export behaviour. Add new retention tiers alongside them only where the resource budget justifies it; existing archives are not reformatted to fit a new code structure. |
| Reference scenes | Preserve and extend to sensor-specific and multimodal baselines. |
| Useful REST fields | Preserve via compatibility adapters where the meaning remains valid. |
| Failure isolation | Preserve: one missing or stalled sensor must not stop other sensing or the interface. |
| Calibration constants | Migrate as labelled provisional calibration metadata, not as laboratory truth. |

### 4.2 Replace or redesign

| Baseline limitation | v0.5 decision |
|---|---|
| Audio reads one 1,024-sample/64 ms window roughly once per second at 16 kHz. | Continuous 48 kHz DMA capture and overlapped STFT in dedicated tasks. |
| Hand-written FFT and insertion-sorted rolling percentiles share global buffers. | ESP-DSP FFT plus bounded, independently owned buffers and streaming quantile/statistics structures. |
| AS7341 runs at fixed 128× gain with a nominal three-second schedule. | Non-blocking complete-frame state machine with adaptive gain/integration and measured cadence. |
| Synchronous `WebServer` and two-second polling. | Native IDF HTTP server with WebSocket live transport and REST control/history. |
| BLE is only a readable diagnostics peripheral. | BLE observation, enrolled-device evidence, anonymous density and optional diagnostic provisioning. |
| Wi-Fi analysis is limited to the current link. | Current-link telemetry plus bounded AP/channel survey on EnvironLight; advanced passive metadata analysis on RadioScout. |
| Dashboard is one large C++ raw string. | Separate HTML, CSS and TypeScript/JavaScript source, built into compressed assets. |
| Dashboard is a long page with many cards and expandable detail. | Stable top-level instrument views with shared time/cursor state and progressive detail. |
| History is minute-only CSV with two-file rotation. | Retain the working archive path and add bounded rollup tiers. Use versioned CRC-protected segments for new compact data where needed, with a documented migration and legacy export. |
| Source ZIP says v0.4.1 while firmware and API identify v0.4.0. | Begin a single semantically versioned v0.5 identity across firmware, schema, manifest and UI. |
| `Secrets.h` contains real credentials. | Purge credentials from distributable source, rotate exposed passwords, supply `secrets.example`, and load local credentials from ignored configuration/NVS. |

## 5. Workspace and build architecture

The repository will be one EnvironCore workspace with two applications and shared components.

| Path | Responsibility |
|---|---|
| `apps/environlight_s3/` | Active ESP32-S3 EnvironLight application, board defaults, partition table and app entry point. |
| `apps/radioscout_esp32/` | Future ESP32-WROOM-32D RadioScout application. Present in source but excluded from the default build/release. |
| `components/platform_core/` | Lifecycle, clocks, record envelope, capabilities, watchdogs and fault states. |
| `components/board_profiles/` | Pins, buses, memory constraints and component inventory for each physical profile. |
| `components/audio_pipeline/` | I2S capture, DSP, acoustic features, event candidates and optional PCM egress. |
| `components/light_pipeline/` | AS7341 driver adapter, exposure controller, derived features and quality state. |
| `components/atmosphere/` | DHT22/BMP280 acquisition, derived climate quantities and pressure analysis. |
| `components/radio_core/` | Shared Wi-Fi/BLE observations, privacy policy, known-device registry and radio summaries. |
| `components/event_engine/` | Timestamp-aligned candidates, evidence fusion, confidence and event log. |
| `components/history_store/` | RAM rings, persistent segments, CRC/recovery, retention and export. |
| `components/telemetry/` | Versioned frames, WebSocket subscriptions, REST resources and backpressure. |
| `components/ui_server/` | Compressed dashboard assets, caching, local configuration and compatibility routes. |
| `web/` | Human-editable dashboard source and tests. |
| `models/` | Versioned event-classifier artefacts and feature manifests; no wake-word model. |
| `tests/` | Host tests, component tests, protocol fixtures and hardware test scripts. |
| `docs/` | Project map, build manifest, calibration notes, migration guide and validation record. |

Each app has its own `sdkconfig.defaults` and target. The normal build compiles only `environlight_s3`; RadioScout code therefore adds no flash, RAM, task or radio burden to EnvironLight. Shared `radio_core` code is compiled for a target only when that app enables the relevant Kconfig capabilities.

`PROJECT_MAP.md` will answer four questions on one page: where the program starts, which component owns each sensor, where each API is defined, and how to build either target. Public component headers describe contracts; private headers and source remain within the component. Include-order coupling from the Arduino sketch is not carried forward.

## 6. Runtime architecture and priorities

### 6.1 Task model

| Task | Initial cadence/trigger | Priority intent | May block on |
|---|---:|---|---|
| Audio capture | Continuous DMA, 256–512-sample reads | Highest application task | I2S receive only |
| Audio DSP | Ring availability; 2,048-sample frames, 512-sample hop | High | Capture-ring wait |
| Light acquisition | Exposure state machine; target at least 5 complete spectra/s when the exposure permits | High-medium | I2C transaction only |
| Pressure acquisition | 50 Hz acquisition target; 20 Hz normal browser stream | Medium | I2C transaction only |
| Climate acquisition | DHT22 every 2.5 s | Low-medium | Sensor read only |
| Radio observation | Adaptive BLE scan and low-duty Wi-Fi survey | Medium-low | Driver events/queues |
| Event fusion | Candidate queue | Medium | Queue wait |
| Rollup/history | 1 s, 10 s and 60 s boundaries | Low | Storage queue, never acquisition |
| Telemetry | Client subscription and frames | Low-medium | Socket queue |
| Storage writer | Buffered segment writes | Low | Filesystem |

The exact core affinity is established by measurement. Capture/DSP and networking should not contend on the same core unnecessarily, but core pinning is not treated as dogma. Every queue is bounded. Producers never wait indefinitely for UI, storage or a slow client.

### 6.2 Time model

Every sample or derived frame carries:

- `monotonic_us`, from the ESP high-resolution monotonic timer;
- `epoch_us` when wall time is synchronised, otherwise null;
- `boot_id` and monotonic `seq`;
- `source_id`, `schema_version`, `quality_flags` and `sample_age_us`;
- the acquisition interval or span represented by the value.

NTP adjustments never rewrite monotonic ordering. The firmware records the mapping between monotonic and wall time and flags discontinuities. Multimodal fusion operates on monotonic time.

### 6.3 Backpressure and graceful reduction

Acquisition is protected in this order:

1. Drop superseded dashboard visual frames.
2. Reduce a client from 20 Hz to 10 Hz.
3. Reduce waveform detail and spectrogram transport bins.
4. Lower optional BLE scan duty and postpone Wi-Fi surveys.
5. Disable experimental Dynamics rendering or local ML inference.

Continuous audio acquisition, sensor truth and low-rate history are never sacrificed to keep an overloaded browser visually smooth. Each reduction is visible in diagnostics.

## 7. EnvironLight sensing pipelines

### 7.1 Continuous acoustic pipeline

#### Acquisition and STFT defaults

| Parameter | Default |
|---|---:|
| Sample rate | 48,000 samples/s, mono |
| Native sample representation | ICS43434 24-bit sample carried in a 32-bit I2S slot |
| Analysis frame | 2,048 samples / 42.67 ms |
| Hop | 512 samples / 10.67 ms |
| Overlap | 75% |
| Window | Periodic Hann, with window-energy correction |
| Internal transform rate | 93.75 frames/s |
| Live scalar/spectral presentation | 20 frames/s target, timestamped |
| FFT backend | ESP-DSP, with a verified reference transform in tests |
| Spectrogram range | Initially 20 Hz–20 kHz, logarithmic display axis |
| Long high-rate ring | Target quantised 256-bin columns at up to 20 Hz for about 10 minutes; about 2.93 MiB for bin values before headers |
| Live detailed spectrum | Up to 256 display bins, subscription-controlled |

The dashboard receives max-preserving or high-percentile reductions for short-lived energy rather than an average that erases clicks, bird calls or impacts. Missing frames stay missing.

The 10-minute spectral ring extends the engineering report's initial one-minute budget to the user's agreed retention. Allocate it only after accounting for all other PSRAM users. If measurements require 128-bin retention or a shorter detailed ring, expose that negotiated capacity and retain the full-rate DSP plus detailed live spectrum. There is no silent default reduction merely to simplify implementation.

#### Acoustic products

- Waveform min/max envelopes and optional short waveform slices.
- RMS and peak dBFS with explicit span.
- Estimated dBZ, dBA and dBC only after the appropriate digital weighting filters; all remain labelled **estimated** until calibrated.
- Leq for 1 s, 10 s, 60 s and selected dashboard ranges.
- L10/L50/L90 only over windows containing enough valid coverage; the UI states the window and coverage.
- Crest factor, zero-crossing rate, spectral centroid, bandwidth, roll-off, flatness, flux and dominant peaks.
- Log-frequency spectrum, peak hold and persistence.
- Octave and one-third-octave summaries where CPU validation permits.
- Adaptive room-relative event candidates using level-above-floor, flux, duration and spectral shape.

The current prototype calibration offset is migrated as provisional metadata. It must not silently convert dBFS into an authoritative SPL. A calibration record contains reference level, calibrator/source, date, firmware version, gain path, temperature and residual uncertainty.

#### Manual captures and raw streaming

The user may explicitly request a **5, 10 or 30 second** capture. The operation has a visible armed/recording state, an automatic stop, and no playback control.

The preferred path streams PCM directly to the requesting LAN client as a standards-compliant WAV download, avoiding a permanent voice archive in flash. The file preserves the useful native dynamic range; its exact 24-bit versus losslessly packed 32-bit representation is chosen after driver validation and documented in the metadata. A sidecar JSON resource records sample rate, sample format, board, microphone, time, calibration state, dropped samples and firmware/model versions.

Optional full-rate PCM over the LAN uses an explicit, single-client, time-limited subscription. It is off by default. Continuous PCM is not written to flash. A disconnected capture is marked incomplete rather than padded or invented.

Deliberately labelled captures may be used for later classifier training. Speech recognition, transcription, speaker identification and wake-word processing are absent.

### 7.2 AS7341 spectral-light pipeline

The measured channels remain discrete bands at nominal centres 415, 445, 480, 515, 555, 590, 630 and 680 nm, plus clear and NIR. The interface may draw a smooth envelope between the eight visible samples, but it is labelled **interpolated AS7341 channel envelope**, never a continuous laboratory spectrum.

Each complete frame contains raw counts, basic/exposure-normalised values, integration settings, gain, ADC utilisation, headroom, exposure state, complete-frame timestamp, acquisition duration and sequence. Preserve the baseline's non-blocking start/progress/read concept. At `ATIME=29` and `ASTEP=599`, integration is about 50.04 ms per phase: `(29+1) × (599+1) × 2.78 microseconds`. A complete visible spectrum needs both multiplexer phases plus overhead; its rate is measured from completed frames.

#### Auto-exposure contract

- Aim for a raw peak between 20% and 70% of the valid ADC range.
- Mark 70–85% as low headroom and reduce exposure immediately above 85%, or when the sensor reports saturation.
- For 8–20%, increase exposure after two consecutive low frames; below 8%, move up more promptly unless already at the exposure limit. Distinguish darkness from insufficient exposure.
- Change one exposure level at a time, prefer gain changes for responsiveness, and cap total integration so the requested complete-spectrum cadence remains honest.
- Mark frames after a setting change as `settling`; never mix multiplexer phases from different exposure settings.
- Publish actual complete frames/s. The UI must not claim 5 Hz when integration or I2C behaviour delivers less.

Start with the engineering ladder: gain 1×, 2×, 4×, 8×, 16×, 32×, 64× and 128×; integration approximately 12.5, 25, 50 and 100 ms. These are selected operating levels, not the sensor's full gain range. Register pairs must follow the manufacturer formula; ADC full-scale must follow the active integration settings and sensor saturation status. Test the complete-frame cadence and settling before adding any higher-gain or longer-exposure option.

#### Light products

- Raw and exposure-normalised channel spectrum with real axes and channel markers; use browser-side monotone cubic interpolation through the eight measured anchors.
- Absolute response/brightness trend kept separate from normalised spectral shape.
- Per-channel traces and shape/intensity waterfalls.
- Delta-to-reference scene and before/after difference view.
- Spectral centroid, dominant channel, red:blue ratio, visible-band entropy, spectral flux and warm/cool balance.
- CIE x/y and CCT only when the broad-band measurement is plausibly white; otherwise CCT is unavailable rather than misleading.
- Circadian/melanopic values remain clearly labelled proxies unless a defensible calibration and calculation are introduced.
- The “orange phone” response test is a release criterion: a sufficiently bright, unsaturated orange display near the sensor must create an obvious and prompt channel/difference response.

### 7.3 Atmosphere and pressure

The DHT22 remains slow and is sampled no faster than a sensible 2.5-second interval. Temperature and RH feed dew point, absolute humidity, vapour-pressure deficit and heat-index calculations with formulas documented in the UI.

The BMP280 follows the engineering target of **50 distinct pressure samples/s**, with a normal 20 Hz browser stream and optional higher-rate research subscription. Start by evaluating the report's temperature ×2, pressure ×4, IIR-off configuration on the existing bus, raised to 400 kHz only after reliable communication is confirmed. Bosch's conversion timing, standby settings and register shadowing must determine the scheduling. Normal-mode polling at 50 Hz alone does not establish exact sample timing; forced-mode scheduling is an option if it better provides complete, distinct, regularly timed conversions.

Retain a 1,024-sample analysis window (20.48 s at a verified 50 Hz), remove mean and linear drift, apply a Hann window, and refresh pressure PSD about every two seconds. Preserve the engineering bands 0.05–0.2, 0.2–1, 1–5 and 5–20 Hz as experimental outputs. The lowest band is near the resolution limit of this window and requires cautious interpretation or a longer window; no band is claimed useful until noise and timing are measured. Raw pressure, slow filtered pressure, actual sample intervals and all processing settings remain available. Any lower-rate fallback is explicit and changes the supported frequency range.

Pressure products include:

- fast residual after removal of slow drift;
- rolling slope and robust variability;
- pressure-step/pulse candidates;
- experimental low-frequency band power where the window supports it;
- relative barometric-height change from a stable local reference, clearly marked experimental;
- alignment with acoustic, light and climate events for door/ventilation candidates.

DHT22/BMP280 temperature disagreement is preserved as a diagnostic and placement clue, not silently averaged.

## 8. Radio: EnvironLight now, RadioScout later

### 8.1 What EnvironLight includes

EnvironLight treats radio as a real sensing family while respecting that ESP32-S3 Wi-Fi and BLE share one 2.4 GHz radio.

- Connected Wi-Fi link: SSID/site label, BSSID pseudonym, channel, RSSI, reconnects, reason codes, IP state, throughput and time-sync status.
- Bounded AP surveys: BSSID pseudonym, SSID only where the user elects to display it, channel, RSSI and advertised security; no payload inspection.
- Channel landscape: observed AP count and signal distribution per channel, explicitly a scan-based view rather than true airtime utilisation.
- BLE field: advertisement rate, unique anonymous count in rolling windows, RSSI distribution, service/manufacturer category when non-sensitive and useful, and scan duty.
- Known-device evidence: enrolled identifiers/signatures, user-assigned name, last seen, source, smoothed RSSI and confidence state.
- Radio diagnostics: coexistence mode, scan parameters, driver drops, survey age and any automatic throttling.

Initial BLE scan duty is conservative and adaptive. Wi-Fi surveys are non-blocking, infrequent and postponed when audio overruns, WebSocket backlog or reconnect instability appears. EnvironLight does not channel-hop promiscuously while it is acting as the room observatory and LAN server.

### 8.2 Known devices and presence

The registry is local and persistent. Enrolment is an explicit temporary mode in which the user chooses an observation and gives it a name. Stored records include a generated device UUID, name, locally keyed identifier/signature, source types, first/last seen, evidence history summary and enabled/archived state.

The ordinary dashboard offers rename, annotate and archive/disable—not delete. A protected maintenance/reset path may erase records when genuinely required, but it is not a casual per-device button.

Presence states are `present`, `probable`, `away` and `unknown`. They are derived from current evidence, signal history, observation gaps and the reliability of the enrolled signature. They are never presented as proof of a person. Unknown devices contribute only to short-lived anonymous counts and distributions; they are not assigned permanent identities.

### 8.3 RadioScout on ESP32-WROOM-32D

The WROOM-32D is a good later dedicated scout because it can spend its resources on Wi-Fi/BLE observation without carrying EnvironLight's audio, spectral and dashboard workload. It is not expected to perform the S3's DSP role.

`apps/radioscout_esp32` is scaffolded as a separate, disabled application target sharing `radio_core`. Its initial build flag is off and it is excluded from the default CI/release matrix until deliberately enabled and tested.

Planned modes are:

| Mode | Behaviour |
|---|---|
| Connected observer | Stays on the LAN channel, performs BLE observation and connected-link/network diagnostics, and publishes normal family telemetry. |
| Wi-Fi survey | Channel-hops for bounded periods and records frame metadata such as type/subtype, RSSI, channel and time; never stores payload bodies. |
| Burst combined | Alternates short survey windows with a home-channel return and summary delivery, only after loss and timing behaviour are measured. |

The scout will publish summaries into the same family schema, with its own `device_id`, profile and quality fields. CSI or deeper passive analysis is an experimental capability for this dedicated target, not a promise in the EnvironLight release.

### 8.4 Future boards

Future modules are covered by the architecture, not predicted in advance. A board supplies:

1. a board profile;
2. one or more capability providers;
3. schema descriptors and quality fields;
4. component-level tests;
5. dashboard view descriptors or an existing compatible capability.

The dashboard renders capabilities from the manifest and continues when a capability is absent. New families should not require cloning and editing the whole application.

## 9. Event intelligence and classification

### 9.1 Event candidates

Sensor components produce bounded, evidence-rich candidates rather than final stories:

- acoustic transient, sustained level, tonal/mechanical texture and spectral change;
- rapid spectral-light intensity or shape change;
- pressure pulse/drift and temperature/RH movement;
- known-device arrival/departure evidence and anonymous radio-density change;
- sensor, clock, network, storage or task-health fault.

### 9.2 Fusion

The event engine aligns candidates by monotonic time. Fast acoustic/light/radio evidence uses a small seconds-scale window; climate and slow pressure consequences may extend to tens of seconds. Each fused event stores:

- neutral type and time span;
- confidence and evidence list;
- sensor quality/coverage at the time;
- competing explanations or `unknown` where evidence is weak;
- links to retained derived frames, not invented data;
- optional user label and note.

Examples such as `door_or_ventilation_candidate` and `mechanical_candidate` remain candidates until trained and validated. The system explains which measurements contributed.

### 9.3 ML path

Feature-rich DSP and event capture are mandatory; a trained model is not allowed to block the rest of v0.5. The model interface accepts a versioned feature vector and returns class scores plus model/version metadata. A no-model implementation returns `unclassified` while the heuristic/event engine remains useful.

Deliberately labelled 5/10/30-second recordings and their derived features support offline training. The deployment adapter may later use ESP-DL or another IDF-compatible inference runtime after memory and latency measurements. Model absence or failure never interrupts sensing. Wake-word models are excluded.

## 10. Retention, persistence and exports

### 10.1 Retention tiers

| Tier | Target retention | Location | Contents |
|---|---:|---|---|
| Live derived | About 10 min | PSRAM | Quantised spectrogram, waveform envelopes, acoustic summaries, light frames, fast pressure and event links. |
| 1-second | About 60 min | PSRAM | Aligned multimodal summaries and quality/coverage. |
| 10-second | About 24 h | LittleFS segmented ring | Compact scaled values, event counters and quality. |
| 1-minute | About 28 days | LittleFS segmented ring | Robust aggregates, extrema, percentiles where valid, spectral summaries, coverage and faults. |
| Events/diagnostics | Bounded by count and byte budget | LittleFS segmented rings | Event evidence, boot/fault/recovery and configuration changes. |
| Manual PCM | Capture duration only | Direct LAN stream; transient buffering | Explicit 5/10/30-second WAV download, no continuous archive. |

Targets are enforced by byte budgets as well as time. If record sizes or filesystem measurements differ, the manifest reports actual capacity and the oldest complete segments rotate first. A full or damaged filesystem degrades to RAM sensing and raises a visible fault.

Preserve the known-working LittleFS mount/recovery behaviour and legacy CSV archives. New compact rollup/event logs may use versioned fixed or length-delimited binary entries with CRC and segment headers when this is needed for the retention budget; that does not require a wholesale rewrite of the existing archive. New CSV/JSON exports are generated on demand. Recovery ignores a torn final record, preserves earlier valid segments and reports the repair. Migration must account for the space already occupied by old archives and must never auto-format a filesystem simply because mounting or schema detection failed.

### 10.2 Exports

- Range-selected CSV for scalar/rollup history.
- JSON/NDJSON for full metadata, quality and events.
- WAV plus metadata JSON for deliberate manual captures.
- A manifest snapshot alongside exported data so downstream analysis knows firmware, schema, board, calibration and units.

No dashboard action deletes the main history. Destructive maintenance is separate, protected and explicit.

## 11. Telemetry and API

### 11.1 Live WebSocket

The primary path is `/ws/v1/live`. A client first sends a bounded subscription describing streams, rates, bin counts and history span. The server acknowledges the effective settings, which may be lower than requested.

Stream types include:

- `status` and `diagnostics` JSON control frames;
- `audio_summary`, `wave_envelope` and `audio_spectrum` compact binary frames;
- `light_frame`, `pressure_frame`, `radio_frame` and `event` frames;
- periodic time-sync and dropped-frame counters.

Binary frames have a short common header containing protocol version, type, flags, sequence, monotonic time and payload length. Numeric packing, endianness and quantisation are documented and fixture-tested. The target is below approximately 25 KiB/s for one normal high-rate dashboard. At most two high-rate clients are supported initially.

### 11.2 REST

Versioned resources include:

| Route family | Purpose |
|---|---|
| `/api/v1/manifest` | Identity, board, capabilities, schema, rates, retention and calibration state. |
| `/api/v1/live` | Latest coherent low-rate snapshot. |
| `/api/v1/history` | Range and resolution-selected summaries. |
| `/api/v1/events` | Event query, evidence and user annotations. |
| `/api/v1/scenes` | Reference-scene list and explicit capture. |
| `/api/v1/captures` | Arm/status/download metadata for 5/10/30-second manual capture. |
| `/api/v1/radio` | Current field, known-device evidence and enrolment controls. |
| `/api/v1/config` | Validated local configuration; mutating operations protected. |
| `/api/v1/health` | Component health, ages, rates, errors, task and memory truth. |
| `/api/v1/export` | Stream generated CSV/NDJSON and metadata. |

Legacy `/api/live`, `/api/audio`, `/api/light`, `/api/history`, `/api/network`, `/api/system`, `/api/health` and `/data` are compatibility adapters for meanings that remain defensible. Deprecated fields are identified in response headers/manifest and never silently repurposed.

## 12. Dashboard information architecture

The interface is one responsive application with eight stable views:

| View | Primary content |
|---|---|
| Observatory | Coherent room state, multimodal event ribbon, selected live instruments, confidence/quality and current departures from baseline. |
| Sound | Large synchronized waveform/level, spectrum and spectrogram; peak hold, scales, windows, capture and calibration detail. |
| Light | Interpolated channel envelope with real markers, brightness and shape, per-channel traces, waterfall, exposure diagnostics and reference difference. |
| Atmosphere | Temperature/RH/pressure alignment, derived moisture metrics, pressure residuals/trends and sensor agreement. |
| Radio | Presence, Wi-Fi landscape, BLE field, known devices, Network Lab and radio diagnostics. |
| Dynamics | Clearly experimental recurrence, phase-space and cross-signal tools; never mixed into ordinary status claims. |
| Timeline | Linked history, events, scene references, zoom/range, export and missing-data gaps. |
| System | Health, rates, latency, memory, storage, tasks, network, calibration, versions and configuration. |

Navigation is persistent, keyboard/touch accessible and route-addressable. On a phone, the current view remains one tap from the primary navigation and deep controls use sheets rather than an endless stack of accordions. Shared range, cursor and pause state synchronises charts. **Pause/freeze display never pauses sensing**, and frozen/stale/offline states are visually distinct.

Each quantitative value has a concise information affordance explaining what it is, units, window, source, limitations and why it matters. Default screens show the useful result; advanced parameters are available without hiding the instrument's measurement truth.

Follow the engineering report's frontend stack: locally bundled uPlot for aligned time series, vanilla ES modules, custom CSS Grid/variables, a small monotone cubic interpolator and a shared WebGL2 raster engine for the audio/light waterfalls and recurrence matrix. Provide a Canvas2D fallback. Keep dependencies local, pin the tested versions and use the same chart engine for history rather than introducing another handwritten renderer.

## 13. Official visual system

The visual reference is a relaxed, sociable summer evening: sun-warmed beach-party colour, giggling with friends by the pool in Poole, Tuscany and French Riviera warmth, with a slight Miami Deco influence. It should feel playful, tactile and a little tipsy in its colour and rhythm, while remaining easy to read and operate. The palette images supplied by the user are authoritative. RGB triplets below are exact conversions of their printed hex values, not samples taken from JPEG pixels.

### 13.1 Sun-Drunk Dawn: bright foundation

| Token | Hex | RGB | Intended role |
|---|---|---|---|
| Warm Sand | `#F5E8D3` | 245, 232, 211 | Main warm page field |
| Shell Pink | `#F8D7D8` | 248, 215, 216 | Gentle state/background variation |
| Marigold | `#F4C542` | 244, 197, 66 | Selected/attention accent, never long text |
| Papaya Peach | `#F3A268` | 243, 162, 104 | Active warmth and event accent |
| Flamingo Coral | `#F46D75` | 244, 109, 117 | Highlight/alert accent with contrast check |
| Soft Terracotta | `#C98162` | 201, 129, 98 | Warm series/accent |
| Aqua | `#7FD6D4` | 127, 214, 212 | Light cool field |
| Pool Blue | `#43ACC2` | 67, 172, 194 | Cool series/accent |
| Moroccan Blue | `#2F6298` | 47, 98, 152 | Strong cool ink/series |
| Palm Green | `#5E8B63` | 94, 139, 99 | Healthy/settled accent |

### 13.2 Sun-Drunk Dusk: warm evening colour

| Token | Hex | RGB | Intended role |
|---|---|---|---|
| Warm Plaster Cream | `#F4E1C6` | 244, 225, 198 | Chart/panel surface |
| Noto Stone | `#E3C9A4` | 227, 201, 164 | Dividers, grid and quiet structure |
| Sunburnt Apricot | `#E98F5F` | 233, 143, 95 | Warm data/event accent |
| Guava Coral | `#EF6258` | 239, 98, 88 | High-attention state with accessible pairing |
| Terracotta Tile | `#C86A49` | 200, 106, 73 | Warm categorical series |
| Pool-Water Teal | `#2AB8B3` | 42, 184, 179 | Live/streaming accent |
| Sicilian Sea | `#0D7886` | 13, 120, 134 | Strong cool data/ink |
| Fig Leaf | `#244A35` | 36, 74, 53 | Limited text/axis ink and contrast detail |

### 13.3 Application rules

- Light warm fields dominate: Warm Sand and Warm Plaster Cream, with Shell Pink and Aqua secondary surfaces. Papaya, coral, marigold and teal provide visible, sociable accents. Dusk is a warm-evening palette; its name is not a request for a dark mode.
- Fig Leaf, Sicilian Sea and Moroccan Blue are limited to readable text, axes, selected traces and small contrast details. They must not become the overall page, navigation rail or default panel backgrounds.
- Use a light typographic hierarchy, soft corners and restrained Deco-inspired arcs, stepped details or borders where they improve navigation. Keep decoration away from data marks, labels and scales.
- Charts optimise scientific legibility first. Spectral plots use wavelength-appropriate colours; spectrograms use a perceptually ordered map with a labelled scale; categorical series are colour-blind checked and use line style/markers as redundant encoding.
- Data marks must not disappear into decorative palette similarity. Adjust the panel/background before compromising distinguishability.
- Smooth persistence, trailing envelopes and restrained motion can carry the beach-party/deep-house energy. Flashing, pulsing alarms, gratuitous particles and fake oscilloscope glow do not.
- Empty space is purposeful but not enormous. The dashboard prioritises plots and relationships over oversized number cards.
- Text, controls, focus rings and states meet WCAG AA contrast where applicable. Reduced-motion and high-contrast preferences are respected.
- Missing, stale, estimated, settling, clipped and uncalibrated data have explicit visual encodings beyond colour.

## 14. Security and privacy

- The distributable repository contains no live Wi-Fi password, token or private key. Credentials already included in the supplied baseline should be considered exposed and rotated.
- Local credentials are provisioned into ignored local configuration or NVS. Remote access terminates through the user's Lenovo/Tailscale arrangement, not an open ESP32 port.
- Mutating configuration, capture and enrolment routes require a local authenticated session or a physical-presence/provisioning action. Read-only observatory access may be separately configurable.
- Manual PCM capture is always explicit, visible and time-limited. There is no hidden or continuous voice archive.
- RadioScout and EnvironLight store no Wi-Fi payload contents. Unknown identifiers are locally keyed/pseudonymised and expire with short rolling windows.
- Named known-device data remains local, carries its evidence limitations and is not equated automatically with a person.
- Logs avoid credentials and raw unique identifiers. Export warns when it includes enrolled-device labels.

## 15. Diagnostics and error behaviour

The System view and API expose at least:

- actual sample/frame rate for every sensor;
- current and maximum acquisition/DSP latency;
- I2S ring high-water mark, overruns and dropped sample/frame counts;
- I2C transaction failures, consecutive failures, recovery attempts and sensor age;
- light exposure state, multiplexer phase errors, settling and complete spectra/s;
- WebSocket clients, per-client effective rate, queued/dropped frames and bytes/s;
- Wi-Fi/BLE coexistence state, survey/scan duty, reconnect reasons and radio drops;
- heap/internal RAM/PSRAM totals, free/minimum and per-ring allocation;
- filesystem capacity, segment status, CRC/recovery events and actual retention;
- task stack high-water marks, watchdog/reset reason and boot ID;
- clock sync state and wall-time discontinuities;
- build ID, commit/source identifier, ESP-IDF/toolchain and dependency versions.

Fault states are `OK`, `DEGRADED`, `STALE`, `RECOVERING`, `MISSING`, `UNSUPPORTED` and `DISABLED`. A stale last value is not displayed as current. Recovery uses bounded backoff and cannot monopolise a bus or loop. A failed optional subsystem does not reboot the entire observatory unless memory integrity or the watchdog proves it unsafe to continue.

## 16. Validation and release gates

### 16.1 Build and static gates

- Reproducible clean builds for the supported EnvironLight target with warnings treated deliberately.
- Host/unit tests for FFT fixtures, weighting/rollup math, light exposure transitions, record CRC/recovery, event timing, protocol packing and registry privacy behaviour.
- Web lint/type/test/build plus responsive visual checks at representative phone, tablet and desktop sizes.
- No credentials in tracked files or generated release bundles.
- Build manifest records target, ESP-IDF, compiler, component versions, binary sizes and partition use.

### 16.2 Hardware gates

| Area | Acceptance |
|---|---|
| Baseline | All four EnvironLight sensors report or fail independently with truthful state. Existing pin behaviour is confirmed. |
| Audio continuity | Zero I2S capture overruns in the target 24-hour soak under normal live dashboard load. Any exception blocks release or changes the stated limit. |
| Audio truth | Known tone falls within one FFT bin before display aggregation; silence/noise/clap tests produce defensible RMS, peak, crest and flux behaviour; calibration labels remain honest. |
| Live latency | Normal local waveform/spectrum/spectrogram visual age target below 200 ms, measured and shown. |
| Manual capture | 5/10/30-second downloads have correct duration/header/metadata and report interruption or dropped samples. |
| Light cadence | Actual complete-frame rate is shown and reaches roughly 5 Hz in ordinary indoor exposure where the sensor/integration allows. |
| Light response | Cover, stable white source, brightness steps and orange-phone test produce immediate correct quality and spectral/difference behaviour without frozen stale bars. |
| Atmosphere | DHT cadence respects the sensor; pressure rate/noise and derived events are measured; sensor disagreement remains visible. |
| Radio coexistence | BLE observation and scheduled Wi-Fi survey do not introduce audio gaps. Throttling activates and is visible under stress. |
| History | Power interruption, torn final write, reboot recovery, full filesystem and all viewports show data or an honest error—never an indefinite blank chart. |
| Clients | One high-rate client is smooth; a second client triggers the documented negotiated fallback without affecting sensing. |
| Longevity | Heap, PSRAM, task stack, storage and client queues remain bounded through the soak. |

RadioScout has its own later hardware gates; its presence in the repository is not evidence that WROOM survey modes have been validated.

## 17. Implementation order

Implementation proceeds by vertical, testable increments while preserving a buildable main branch:

1. Establish ESP-IDF workspace, EnvironLight board profile, secrets boundary, build manifest and baseline sensor smoke tests.
2. Implement common time, capability, diagnostics and record contracts.
3. Port DHT22/BMP280/AS7341 baseline acquisition and validate pins/failure isolation.
4. Implement continuous I2S capture and reference-tested DSP before adding the live UI.
5. Implement versioned WebSocket/REST transport with synthetic fixtures and backpressure.
6. Build the bright Observatory/Sound foundation and validate phone performance.
7. Add adaptive AS7341 exposure, Light views, waterfall and orange-phone validation.
8. Add tiered history, Timeline, scenes, exports and recovery tests.
9. Add EnvironLight BLE/Wi-Fi field observation, persistent named registry and Radio view.
10. Add event fusion, labelled capture workflow, optional classifier adapter and Dynamics Lab.
11. Add the disabled RadioScout application target sharing `radio_core`; compile only when explicitly enabled.
12. Run complete hardware, coexistence, responsive-browser and 24-hour soak gates; record what is measured versus pending.

## 18. Explicit non-goals for v0.5

- Wake word, speech transcription, speaker recognition or conversation transcription.
- Continuous raw audio storage or an audio playback library.
- Public-cloud dependence or a public internet port on the ESP32.
- Claiming the AS7341 is a continuous calibrated spectroradiometer.
- Claiming uncalibrated microphone output is a standards-grade sound-level meter.
- Permanent tracking or attribution of unknown neighbouring devices.
- Packet-payload capture.
- Forcing all future boards into the EnvironLight binary.
- Keeping v0.4 source shapes merely because they already exist.

## 19. Change control

The user's current direction governs implementation. The engineering report remains the technical backbone, with explicit decisions recorded in section 2.1. Measured parameters—task affinity, exact register combinations, pressure scheduling, PCM packing, memory budgets and radio duty cycle—are settled by primary documentation, compilation and hardware tests. Record the evidence for changes; do not silently reduce a capability or expand the system beyond the agreed plan. Material changes to capability, privacy, retention, navigation or visual direction return to the user for a decision.
