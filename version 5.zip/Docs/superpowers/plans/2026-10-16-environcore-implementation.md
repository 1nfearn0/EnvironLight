# EnvironCore v0.5 Implementation Plan

> For agentic workers: use executing-plans to implement and verify each component. The user explicitly authorised writing and sending the code; proceed without further design approval.

**Goal:** Deliver a portable ESP-IDF EnvironLight application, shared family contracts, a disabled RadioScout app, a locally served eight-view dashboard, and reproducible verification instructions.

**Architecture:** Four components separate portable signal processing and state, hardware acquisition, radio observation, and HTTP/UI transport. Two app targets share them. Sensor tasks publish bounded snapshots; HTTP and persistence consume copies rather than holding acquisition locks.

**Tech Stack:** ESP-IDF 5.5, C11, ESP-DSP, esp_http_server, NimBLE, LittleFS, vanilla ES modules, locally bundled plotting assets.

**Spec:** `docs/specs/2026-10-15-environcore-v0.5-design.md`

## Global Constraints

- Preserve GPIOs 4, 6/7, 8/9 and 15/16/17 for the existing EnvironLight sensors.
- Continuous 48 kHz audio; 2048 FFT, 512 hop; browser target 20 Hz.
- Pressure target 50 Hz, light about 5 complete frames/s, DHT22 2.5 s.
- Explicit 5/10/30 s download captures; no playback, transcription or wake word.
- Exact official palette values, bright warm surfaces, eight stable views.
- No credentials in the source; no format-on-failure storage behaviour.
- All claims distinguish host tests, target compilation and physical validation.

## Review Focus

- Missing sensors and corrupt archive records do not hang acquisition or invent values.
- Slow/disconnected WebSocket and capture clients cannot block audio capture.
- Random BLE identifiers remain anonymous; named devices persist without ordinary delete.
- Unsynchronised wall time and reboots preserve ordering and gaps.
- Mobile rendering, freeze controls, empty data and model absence remain useful and honest.

## Tasks

### Task 1 Core contracts and scientific calculations

Files: `components/ec_core/include/ec.h`, `ec_math.h`, `ec_math.c`, `ec_state.c`, `tests/test_math.c`.
Interfaces: timestamped audio/light/atmosphere snapshots, bounded events, energy rollups, FFT reference and exposure decisions.
- [ ] Write tests for tone frequency/level, energy averaging, pressure/psychrometric formulas and exposure hysteresis; run missing-feature failure.
- [ ] Implement portable functions; run host tests with sanitizers.

### Task 2 Hardware acquisition

Files: `components/ec_sensors/`.
Interfaces: `ec_sensors_start()` publishes via `ec_update_audio/light/atmosphere`; capture service provides bounded WAV stream reads.
- [ ] Test register compensation/exposure/capture buffer boundaries.
- [ ] Implement native I2S, BMP280, AS7341 and DHT22 task pipelines with independent recovery and counters.
- [ ] Compile/check the component and document hardware-only checks.

### Task 3 Radio and family identities

Files: `components/ec_radio/`, `apps/radioscout_esp32/`.
Interfaces: `ec_radio_start()`, `ec_radio_json()`, `ec_radio_command()`; Wi-Fi and BLE maintain their own locks.
- [ ] Test registry enrolment/rename/archive and anonymous identifier lifetime.
- [ ] Implement Wi-Fi reconnect/survey, NimBLE advertisements and NVS named registry; separate disabled scout target.
- [ ] Verify input bounds, no raw identifiers in responses and no payload capture.

### Task 4 History and events

Files: `components/ec_core/ec_history.c`, `include/ec_history.h`.
Interfaces: `ec_history_init()`, `ec_history_tick()`, history/events/scenes query/export functions.
- [ ] Test ring wrap, CRC/torn-record rejection, empty valid windows and energy-correct rollups.
- [ ] Implement bounded RAM tiers and LittleFS logs, preserve legacy archive parsing, NVS reference scenes and exports.
- [ ] Verify no auto-format and bounded storage use.

### Task 5 Dashboard and transport

Files: `web/`, `components/ec_web/`.
Interfaces: `/api/v1/manifest`, `/api/v1/live`, `/ws/v1/live`, radio/config/history/scenes/capture routes; JSON contract documented in `docs/API.md`.
- [ ] Write protocol/UI tests for eight views, missing data, palettes and display freeze.
- [ ] Implement bright instrument UI, linked time-series/spectra/waterfalls, Dynamics Lab and downloads; embed assets deterministically.
- [ ] Run JS tests and browser layout/interaction checks against fixture server.

### Task 6 Integration and delivery

Files: app CMake/default configs, `README.md`, `PROJECT_MAP.md`, `tools/`, `docs/VALIDATION.md`.
- [ ] Integrate component startup, configuration and diagnostics; build all available targets or record the exact toolchain limitation.
- [ ] Run complete host/UI suite, perform independent review and fix material findings.
- [ ] Package clean source/assets/tests/docs in a ZIP, save it and send it to the user.
