#pragma once
#include "ec.h"
#include "cJSON.h"
cJSON *ec_snapshot_json(const ec_snapshot_t *snapshot,bool include_radio);
cJSON *ec_light_json(const ec_light_t *value);
cJSON *ec_system_json(void);
cJSON *ec_manifest_json(void);
cJSON *ec_events_json(void);
extern unsigned ec_ws_clients,ec_ws_drops;
