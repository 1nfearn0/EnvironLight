#pragma once
#include "esp_err.h"
esp_err_t ec_web_start(void);
