#include "ec_web.h"
#include "ec_json.h"
#include "ec_assets.h"
#include "ec_protocol.h"
#include "ec_history.h"
#include "ec_sensors.h"
#include "ec_radio.h"
#include "sdkconfig.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_system.h"
#include "mbedtls/md.h"
#include "mbedtls/sha256.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

static const char *TAG="ec_web";
static httpd_handle_t server;
unsigned ec_ws_clients,ec_ws_drops;
typedef struct {int fd;unsigned generation,rate;bool busy;uint64_t last_send,last_snapshot;uint32_t last_light;uint64_t last_pressure;} client_t;
static client_t clients[2]={{.fd=-1,.rate=20},{.fd=-1,.rate=20}};
static SemaphoreHandle_t client_lock,capture_lock;
static uint64_t capture_armed_us;

static esp_err_t json_send(httpd_req_t *r,cJSON *o){
    if(!o)return httpd_resp_send_err(r,HTTPD_500_INTERNAL_SERVER_ERROR,"Allocation failed");
    char *text=cJSON_PrintUnformatted(o);cJSON_Delete(o);
    if(!text)return httpd_resp_send_err(r,HTTPD_500_INTERNAL_SERVER_ERROR,"Allocation failed");
    httpd_resp_set_type(r,"application/json");httpd_resp_set_hdr(r,"Cache-Control","no-store");
    esp_err_t err=httpd_resp_send(r,text,HTTPD_RESP_USE_STRLEN);cJSON_free(text);return err;
}
static esp_err_t error_json(httpd_req_t *r,const char *status,const char *message){
    httpd_resp_set_status(r,status);cJSON *o=cJSON_CreateObject();cJSON_AddBoolToObject(o,"ok",false);cJSON_AddStringToObject(o,"error",message);return json_send(r,o);
}
static bool authorised(httpd_req_t *r){
    const char *key=CONFIG_EC_API_KEY;size_t n=strlen(key);
    if(n<16){error_json(r,"403 Forbidden","Set an API key of at least 16 characters in firmware configuration to enable controls");return false;}
    char value[160]={0};if(httpd_req_get_hdr_value_str(r,"Authorization",value,sizeof(value))!=ESP_OK||strncmp(value,"Bearer ",7)){error_json(r,"401 Unauthorized","A local control API key is required");return false;}
    size_t have=strlen(value+7);unsigned mismatch=(unsigned)(have^n);
    for(size_t i=0;i<n;i++)mismatch|=(unsigned char)key[i]^(unsigned char)(i<have?value[7+i]:0);
    if(mismatch){error_json(r,"401 Unauthorized","Invalid control API key");return false;}return true;
}
static bool same_origin(httpd_req_t *r){
    char origin[160]={0},host[96]={0};
    if(httpd_req_get_hdr_value_str(r,"Origin",origin,sizeof(origin))!=ESP_OK)return true;
    if(httpd_req_get_hdr_value_str(r,"Host",host,sizeof(host))!=ESP_OK)return false;
    const char *authority=NULL;
    if(!strncasecmp(origin,"http://",7))authority=origin+7;
    else if(!strncasecmp(origin,"https://",8))authority=origin+8;
    if(!authority||strchr(authority,'/')||strchr(authority,'?')||strchr(authority,'#'))return false;
    return !strcasecmp(authority,host)&&ec_radio_host_allowed(host);
}
static cJSON *body_json(httpd_req_t *r){
    if(r->content_len<=0||r->content_len>4096)return NULL;
    char *text=malloc(r->content_len+1);if(!text)return NULL;size_t got=0;
    while(got<r->content_len){int n=httpd_req_recv(r,text+got,r->content_len-got);if(n<=0){free(text);return NULL;}got+=(size_t)n;}
    text[got]=0;cJSON *o=cJSON_ParseWithLength(text,got+1);free(text);if(!cJSON_IsObject(o)){cJSON_Delete(o);return NULL;}return o;
}
static unsigned query_uint(httpd_req_t *r,const char *key,unsigned fallback){
    char query[256],value[32];if(httpd_req_get_url_query_str(r,query,sizeof(query))!=ESP_OK||httpd_query_key_value(query,key,value,sizeof(value))!=ESP_OK)return fallback;
    char *end;unsigned long v=strtoul(value,&end,10);if(!value[0]||*end||value[0]=='-'||v>UINT32_MAX)return fallback;return (unsigned)v;
}
static void route_path(httpd_req_t *r,char out[128]){
    size_t n=strnlen(r->uri,sizeof(char[128])-1);
    memcpy(out,r->uri,n);
    out[n]=0;
    char *q=strchr(out,'?');
    if(q)*q=0;
}
static cJSON *capture_status(void){
    cJSON *o=cJSON_CreateObject();cJSON_AddBoolToObject(o,"active",ec_capture_active());cJSON_AddBoolToObject(o,"pending",ec_capture_pending());cJSON_AddBoolToObject(o,"recording",ec_capture_recording());cJSON_AddNumberToObject(o,"seconds",ec_capture_seconds());cJSON_AddNumberToObject(o,"dropped_samples",ec_capture_dropped());
    cJSON_AddNumberToObject(o,"armed_monotonic_us",capture_armed_us);cJSON_AddNumberToObject(o,"sample_rate",EC_SAMPLE_RATE);cJSON_AddNumberToObject(o,"bits_per_sample",32);cJSON_AddNumberToObject(o,"channels",1);
    cJSON_AddStringToObject(o,"format","signed_32bit_little_endian_24_significant_bits_left_aligned");cJSON_AddStringToObject(o,"firmware",EC_VERSION);cJSON_AddStringToObject(o,"device_id",ec_device_id());
    cJSON_AddStringToObject(o,"calibration","factory_sensitivity_estimate_not_reference_calibrated");cJSON_AddBoolToObject(o,"flash_storage",false);return o;
}
static void capture_download_task(void *arg){
    httpd_req_t *r=arg;uint8_t header[44],buffer[4096];unsigned seconds=ec_capture_seconds();size_t expected=(size_t)seconds*EC_SAMPLE_RATE*4,sent=0;
    ec_wav_header(header,seconds*EC_SAMPLE_RATE);httpd_resp_set_type(r,"audio/wav");httpd_resp_set_hdr(r,"Cache-Control","no-store");httpd_resp_set_hdr(r,"Content-Disposition","attachment; filename=environlight_capture.wav");
    esp_err_t err=httpd_resp_send_chunk(r,(const char*)header,sizeof(header));
    uint64_t deadline=ec_now_us()+(uint64_t)(seconds+5)*1000000;
    while(err==ESP_OK&&sent<expected&&ec_now_us()<deadline){
        size_t n=ec_capture_read(buffer,sizeof(buffer),500);
        if(n){err=httpd_resp_send_chunk(r,(const char*)buffer,n);sent+=n;}
        else if(!ec_capture_active())break;
    }
    bool complete=sent==expected&&ec_capture_dropped()==0;
    if(complete&&err==ESP_OK)httpd_resp_send_chunk(r,NULL,0);
    else{ec_event("capture_incomplete","Manual capture incomplete or client too slow",1,1);httpd_sess_trigger_close(server,httpd_req_to_sockfd(r));}
    ec_capture_cancel();httpd_req_async_handler_complete(r);xSemaphoreGive(capture_lock);vTaskDelete(NULL);
}
static esp_err_t download_capture(httpd_req_t *r){
    if(!authorised(r))return ESP_OK;
    if(!ec_capture_seconds())return error_json(r,"409 Conflict","Arm a 5, 10 or 30 second capture first");
    if(xSemaphoreTake(capture_lock,0)!=pdTRUE)return error_json(r,"409 Conflict","A capture reader is already active");
    httpd_req_t *copy=NULL;esp_err_t e=httpd_req_async_handler_begin(r,&copy);
    if(e!=ESP_OK){xSemaphoreGive(capture_lock);return e;}
    if(xTaskCreate(capture_download_task,"wav_download",6144,copy,3,NULL)!=pdPASS){httpd_req_async_handler_complete(copy);xSemaphoreGive(capture_lock);return error_json(r,"503 Service Unavailable","Unable to start download worker");}
    return ESP_OK;
}
static esp_err_t csv_export(httpd_req_t *r){
    unsigned resolution=query_uint(r,"resolution",60),limit=query_uint(r,"limit",1000);
    cJSON *o=ec_history_json(resolution,limit,query_uint(r,"before_seq",0));if(!o)return error_json(r,"503 Service Unavailable","History unavailable");
    cJSON *rows=cJSON_GetObjectItemCaseSensitive(o,"records");httpd_resp_set_type(r,"text/csv; charset=utf-8");httpd_resp_set_hdr(r,"Content-Disposition","attachment; filename=environcore_history.csv");
    const char *keys[]={"seq","boot_id","epoch_s","t_us","span_s","temperature_c","humidity_rh","pressure_pa","dbfs","dba_est","peak_dbfs","coverage","light_centroid_nm","light_intensity"};
    const char *head="seq,boot_id,epoch_s,t_us,span_s,temperature_c,humidity_rh,pressure_pa,dbfs,dba_est,peak_dbfs,coverage,light_centroid_nm,light_intensity\n";
    esp_err_t e=httpd_resp_send_chunk(r,head,HTTPD_RESP_USE_STRLEN);cJSON *row=NULL;
    cJSON_ArrayForEach(row,rows){char line[512];size_t used=0;for(unsigned i=0;i<sizeof(keys)/sizeof(keys[0]);i++){
        cJSON *v=cJSON_GetObjectItemCaseSensitive(row,keys[i]);int n=snprintf(line+used,sizeof(line)-used,"%s",i?",":"");used+=(size_t)n;
        if(cJSON_IsNumber(v)&&isfinite(v->valuedouble)){n=snprintf(line+used,sizeof(line)-used,"%.9g",v->valuedouble);if(n>0)used+=(size_t)n;}
    }line[used++]='\n';if(e==ESP_OK)e=httpd_resp_send_chunk(r,line,used);if(e!=ESP_OK)break;}
    cJSON_Delete(o);if(e==ESP_OK)e=httpd_resp_send_chunk(r,NULL,0);return e;
}
static esp_err_t legacy_export(httpd_req_t *r){
    static const char *paths[]={"/data/history_prev.csv","/data/history.csv","/data/environlight_v2_prev.csv","/data/environlight_v2.csv"};
    unsigned i=query_uint(r,"file",3);if(i>=4)return error_json(r,"400 Bad Request","Legacy file index must be 0 to 3");
    FILE *f=fopen(paths[i],"rb");if(!f)return error_json(r,"404 Not Found","Legacy archive not present");
    httpd_resp_set_type(r,"text/csv");httpd_resp_set_hdr(r,"Content-Disposition","attachment; filename=environcore_legacy.csv");char buf[2048];size_t n;esp_err_t e=ESP_OK;
    while((n=fread(buf,1,sizeof(buf),f))>0){e=httpd_resp_send_chunk(r,buf,n);if(e!=ESP_OK)break;}fclose(f);if(e==ESP_OK)e=httpd_resp_send_chunk(r,NULL,0);return e;
}
static void restart_task(void *unused){(void)unused;vTaskDelay(pdMS_TO_TICKS(1200));esp_restart();}
static bool hex32(const char *text,uint8_t out[32]){
    if(!text||strlen(text)!=64)return false;
    for(unsigned i=0;i<32;i++){
        char pair[3]={text[i*2],text[i*2+1],0},*end=NULL;unsigned long value=strtoul(pair,&end,16);
        if(!end||*end)return false;
        out[i]=(uint8_t)value;
    }
    return true;
}
static bool ota_signature_ok(const uint8_t digest[32],size_t size,const uint8_t supplied[32]){
    static const char domain[]="EnvironCore-OTA-v1";uint8_t message[sizeof(domain)-1+32+8],expected[32];
    memcpy(message,domain,sizeof(domain)-1);memcpy(message+sizeof(domain)-1,digest,32);
    for(unsigned i=0;i<8;i++)message[sizeof(domain)-1+32+i]=(uint8_t)((uint64_t)size>>(56-i*8));
    const char *key=CONFIG_EC_OTA_KEY;size_t key_len=strlen(key);
    if(key_len<32||mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),(const uint8_t*)key,key_len,message,sizeof(message),expected)!=0)return false;
    unsigned mismatch=0;for(unsigned i=0;i<32;i++)mismatch|=expected[i]^supplied[i];return mismatch==0;
}
static esp_err_t ota_upload(httpd_req_t *r){
    if(strlen(CONFIG_EC_OTA_KEY)<32)return error_json(r,"403 Forbidden","Set a separate OTA signing key of at least 32 characters in firmware configuration");
    char signature_text[80]={0};uint8_t supplied_signature[32];
    if(httpd_req_get_hdr_value_str(r,"X-EC-OTA-Signature",signature_text,sizeof(signature_text))!=ESP_OK||!hex32(signature_text,supplied_signature))return error_json(r,"401 Unauthorized","A valid OTA image signature is required");
    const esp_partition_t *partition=esp_ota_get_next_update_partition(NULL);
    if(!partition)return error_json(r,"501 Not Implemented","This hardware profile has no OTA update slot");
    if(r->content_len<=0||(size_t)r->content_len>partition->size)return error_json(r,"413 Payload Too Large","Firmware image is empty or larger than the OTA slot");
    esp_ota_handle_t handle=0;esp_err_t err=esp_ota_begin(partition,r->content_len,&handle);
    if(err!=ESP_OK)return error_json(r,"503 Service Unavailable",esp_err_to_name(err));
    mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);
    if(mbedtls_sha256_starts(&sha,0)!=0){esp_ota_abort(handle);mbedtls_sha256_free(&sha);return error_json(r,"503 Service Unavailable","Unable to initialise OTA digest");}
    uint8_t *buffer=malloc(4096);size_t remaining=(size_t)r->content_len,written=0;unsigned timeouts=0;
    if(!buffer){esp_ota_abort(handle);mbedtls_sha256_free(&sha);return error_json(r,"503 Service Unavailable","No memory for OTA transfer");}
    while(remaining){
        size_t wanted=remaining<4096?remaining:4096;int n=httpd_req_recv(r,(char*)buffer,wanted);
        if(n==HTTPD_SOCK_ERR_TIMEOUT&&timeouts++<5)continue;
        if(n<=0){err=ESP_FAIL;break;}
        if(!written&&buffer[0]!=0xe9){err=ESP_ERR_INVALID_ARG;break;}
        err=esp_ota_write(handle,buffer,(size_t)n);if(err!=ESP_OK)break;
        if(mbedtls_sha256_update(&sha,buffer,(size_t)n)!=0){err=ESP_FAIL;break;}
        written+=(size_t)n;remaining-=(size_t)n;timeouts=0;
    }
    free(buffer);uint8_t digest[32];
    if(err==ESP_OK&&mbedtls_sha256_finish(&sha,digest)!=0)err=ESP_FAIL;
    mbedtls_sha256_free(&sha);
    if(err==ESP_OK&&!ota_signature_ok(digest,written,supplied_signature))err=ESP_ERR_INVALID_CRC;
    if(err==ESP_OK)err=esp_ota_end(handle);else esp_ota_abort(handle);
    if(err==ESP_OK)err=esp_ota_set_boot_partition(partition);
    if(err!=ESP_OK)return error_json(r,"400 Bad Request",esp_err_to_name(err));
    ec_event("ota","Verified firmware update received; reboot scheduled",1,0);
    cJSON *o=cJSON_CreateObject();cJSON_AddBoolToObject(o,"ok",true);cJSON_AddNumberToObject(o,"bytes",written);cJSON_AddBoolToObject(o,"rebooting",true);
    esp_err_t response=json_send(r,o);if(response==ESP_OK)xTaskCreate(restart_task,"ota_restart",2048,NULL,5,NULL);return response;
}
static esp_err_t get_api(httpd_req_t *r){
    char path[128];route_path(r,path);
    if(!strcmp(path,"/api/v1/captures/download"))return download_capture(r);
    if(!strcmp(path,"/api/v1/export")||!strcmp(path,"/api/archive.csv"))return csv_export(r);
    if(!strcmp(path,"/api/v1/legacy/download")||!strcmp(path,"/api/archive-legacy.csv"))return legacy_export(r);
    if(strstr(path,"manifest"))return json_send(r,ec_manifest_json());
    if(strstr(path,"history"))return json_send(r,ec_history_json(query_uint(r,"resolution",60),query_uint(r,"limit",240),query_uint(r,"before_seq",0)));
    if(strstr(path,"scenes"))return json_send(r,ec_scenes_json());
    if(strstr(path,"events"))return json_send(r,ec_history_events_json(query_uint(r,"limit",100),query_uint(r,"before_seq",0)));
    if(strstr(path,"legacy"))return json_send(r,ec_history_legacy_json());
    if(strstr(path,"radio")||strstr(path,"network"))return json_send(r,ec_radio_json());
    if(strstr(path,"captures"))return json_send(r,capture_status());
    if(strstr(path,"system")||strstr(path,"health"))return json_send(r,ec_system_json());
    if(strstr(path,"config")){cJSON *o=cJSON_CreateObject();cJSON_AddBoolToObject(o,"controls_enabled",strlen(CONFIG_EC_API_KEY)>=16);cJSON_AddStringToObject(o,"auth","Bearer");cJSON_AddStringToObject(o,"remote_access","Use your existing Lenovo/Tailscale route");return json_send(r,o);}
    bool live=!strcmp(path,"/api/v1/live")||!strcmp(path,"/api/live")||!strcmp(path,"/data");
    bool audio=!strcmp(path,"/api/audio");
    bool light=!strcmp(path,"/api/light")||!strcmp(path,"/api/spectrum");
    if(!live&&!audio&&!light)return error_json(r,"404 Not Found","API route not found");
    ec_snapshot_t snapshot;ec_get_snapshot(&snapshot);cJSON *o=ec_snapshot_json(&snapshot,true);
    if(audio){cJSON *a=cJSON_DetachItemFromObject(o,"audio");cJSON_Delete(o);return json_send(r,a);}
    if(light){cJSON *l=cJSON_DetachItemFromObject(o,"light");cJSON_Delete(o);return json_send(r,l);}
    if(!strcmp(path,"/api/live")||!strcmp(path,"/data")){
        cJSON_AddNumberToObject(o,"schema_version",EC_SCHEMA);cJSON_AddStringToObject(o,"family","EnvironCore");cJSON_AddStringToObject(o,"firmware",EC_VERSION);
        cJSON *v=cJSON_GetObjectItem(o,"atmos");cJSON_AddItemToObject(o,"temperature",cJSON_Duplicate(cJSON_GetObjectItem(v,"temperature_c"),true));cJSON_AddItemToObject(o,"humidity",cJSON_Duplicate(cJSON_GetObjectItem(v,"humidity_rh"),true));
        if(isfinite(snapshot.atmos.pressure_pa))cJSON_AddNumberToObject(o,"pressure",snapshot.atmos.pressure_pa/100);else cJSON_AddNullToObject(o,"pressure");
        cJSON_AddNumberToObject(o,"uptime_s",snapshot.uptime_us/1000000);cJSON_AddStringToObject(o,"compatibility_note","Use nested schema 3 objects for full instrument data");
    }
    return json_send(r,o);
}
static esp_err_t post_api(httpd_req_t *r){
    char path[128];route_path(r,path);
    if(!strcmp(path,"/api/v1/ota"))return ota_upload(r);
    if(!authorised(r))return ESP_OK;
    cJSON *body=body_json(r);if(!body)return error_json(r,"400 Bad Request","A JSON object no larger than 4096 bytes is required");
    esp_err_t result=ESP_ERR_NOT_SUPPORTED;cJSON *response=NULL;
    if(!strcmp(path,"/api/v1/captures")){
        cJSON *s=cJSON_GetObjectItemCaseSensitive(body,"seconds");
        unsigned seconds=(cJSON_IsNumber(s)&&s->valuedouble==(double)s->valueint&&s->valueint>0)?(unsigned)s->valueint:0;
        result=ec_is_scout()?ESP_ERR_NOT_SUPPORTED:ec_capture_arm(seconds);
        if(result==ESP_OK){capture_armed_us=ec_now_us();response=capture_status();ec_event("manual_capture","Explicit timed PCM capture armed",1,1);}
    }else if(!strcmp(path,"/api/v1/scenes")||!strcmp(path,"/api/scene/capture")){
        cJSON *name=cJSON_GetObjectItemCaseSensitive(body,"name");result=cJSON_IsString(name)?ec_scene_capture(name->valuestring):ESP_ERR_INVALID_ARG;
        if(result==ESP_OK)response=ec_scenes_json();
    }else if(!strncmp(path,"/api/v1/radio/",14)){result=ec_radio_command(path+14,body,&response);}
    cJSON_Delete(body);
    if(result==ESP_OK){if(!response)response=cJSON_CreateObject();cJSON_AddBoolToObject(response,"ok",true);return json_send(r,response);}
    cJSON_Delete(response);
    if(result==ESP_ERR_INVALID_ARG)return error_json(r,"400 Bad Request","Invalid field, duration or device identifier");
    if(result==ESP_ERR_INVALID_STATE)return error_json(r,"409 Conflict","Operation unavailable: capture busy, device not observed, or reference needs five valid minutes");
    if(result==ESP_ERR_NOT_FOUND)return error_json(r,"404 Not Found","Device or command not found");
    if(result==ESP_ERR_NOT_SUPPORTED)return error_json(r,"501 Not Implemented","This profile does not support the requested operation");
    return error_json(r,"503 Service Unavailable",esp_err_to_name(result));
}
static esp_err_t assets(httpd_req_t *r){
    char path[128];route_path(r,path);if(!strcmp(path,"/")||!strcmp(path,"/family"))snprintf(path,sizeof(path),"/index.html");
    for(size_t i=0;i<ec_assets_count;i++)if(!strcmp(path,ec_assets[i].path)){
        httpd_resp_set_type(r,ec_assets[i].type);httpd_resp_set_hdr(r,"Content-Encoding","gzip");httpd_resp_set_hdr(r,"Cache-Control","no-cache");httpd_resp_set_hdr(r,"X-Content-Type-Options","nosniff");
        httpd_resp_set_hdr(r,"Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss: http: https:; img-src 'self' data:; frame-ancestors 'self'");
        return httpd_resp_send(r,(const char*)ec_assets[i].data,ec_assets[i].length);
    }return httpd_resp_send_err(r,HTTPD_404_NOT_FOUND,"Resource not found");
}

typedef struct {unsigned slot,generation;} send_work_t;
static esp_err_t ws_json(int fd,cJSON *o){char *s=cJSON_PrintUnformatted(o);cJSON_Delete(o);if(!s)return ESP_ERR_NO_MEM;httpd_ws_frame_t f={.type=HTTPD_WS_TYPE_TEXT,.payload=(uint8_t*)s,.len=strlen(s)};esp_err_t e=httpd_ws_send_frame_async(server,fd,&f);cJSON_free(s);return e;}
static void send_work(void *arg){
    send_work_t work=*(send_work_t*)arg;free(arg);client_t c;
    xSemaphoreTake(client_lock,portMAX_DELAY);c=clients[work.slot];xSemaphoreGive(client_lock);
    if(c.generation!=work.generation)return;
    esp_err_t err=ESP_FAIL;
    if(httpd_ws_get_fd_info(server,c.fd)==HTTPD_WS_CLIENT_WEBSOCKET){
        ec_snapshot_t s;ec_get_snapshot(&s);uint8_t audio[EC_AUDIO_PACKET_SIZE],pressure[EC_PRESSURE_PACKET_SIZE];
        err=ESP_OK;
        if(!ec_is_scout()&&s.audio.t_us&&s.uptime_us-s.audio.t_us<2000000){
            size_t n=ec_encode_audio(&s.audio,audio,sizeof(audio));httpd_ws_frame_t f={.type=HTTPD_WS_TYPE_BINARY,.payload=audio,.len=n};err=httpd_ws_send_frame_async(server,c.fd,&f);
        }
        if(err==ESP_OK&&!ec_is_scout()&&s.atmos.pressure_us!=c.last_pressure){
            size_t n=ec_encode_pressure(&s.atmos,pressure,sizeof(pressure));httpd_ws_frame_t f={.type=HTTPD_WS_TYPE_BINARY,.payload=pressure,.len=n};err=httpd_ws_send_frame_async(server,c.fd,&f);c.last_pressure=s.atmos.pressure_us;
        }
        if(err==ESP_OK&&s.light.seq!=c.last_light){cJSON *o=cJSON_CreateObject();cJSON_AddStringToObject(o,"type","light");cJSON_AddItemToObject(o,"light",ec_light_json(&s.light));err=ws_json(c.fd,o);c.last_light=s.light.seq;}
        if(err==ESP_OK&&s.uptime_us-c.last_snapshot>=1000000){err=ws_json(c.fd,ec_snapshot_json(&s,true));c.last_snapshot=s.uptime_us;}
    }
    xSemaphoreTake(client_lock,portMAX_DELAY);
    if(clients[work.slot].generation==work.generation){
        clients[work.slot].busy=false;clients[work.slot].last_snapshot=c.last_snapshot;clients[work.slot].last_light=c.last_light;clients[work.slot].last_pressure=c.last_pressure;
        if(err!=ESP_OK){clients[work.slot].fd=-1;ec_ws_drops++;}
    }xSemaphoreGive(client_lock);
    if(err!=ESP_OK&&c.fd>=0)httpd_sess_trigger_close(server,c.fd);
}
static void stream_task(void *unused){
    (void)unused;TickType_t last=xTaskGetTickCount();
    for(;;){
        uint64_t now=ec_now_us();unsigned active=0;
        xSemaphoreTake(client_lock,portMAX_DELAY);
        for(unsigned i=0;i<2;i++) {
            if(clients[i].fd>=0)active++;
        }
        ec_ws_clients=active;
        for(unsigned i=0;i<2;i++){
            client_t *c=&clients[i];if(c->fd<0)continue;unsigned rate=active>1?10:c->rate;if(rate<1)rate=1;
            if(now-c->last_send<1000000/rate)continue;
            c->last_send=now;
            if(c->busy){ec_ws_drops++;continue;}
            send_work_t *w=malloc(sizeof(*w));if(!w){ec_ws_drops++;continue;}*w=(send_work_t){i,c->generation};c->busy=true;
            if(httpd_queue_work(server,send_work,w)!=ESP_OK){c->busy=false;free(w);ec_ws_drops++;}
        }xSemaphoreGive(client_lock);
        vTaskDelayUntil(&last,pdMS_TO_TICKS(25));
    }
}
static void ota_confirm_task(void *unused){
    (void)unused;vTaskDelay(pdMS_TO_TICKS(30000));ec_snapshot_t snapshot;ec_get_snapshot(&snapshot);uint64_t now=ec_now_us();
    bool healthy=server&&client_lock&&capture_lock&&!ec_is_scout()&&snapshot.audio.t_us&&now>=snapshot.audio.t_us&&now-snapshot.audio.t_us<3000000;
    if(healthy){
        if(esp_ota_mark_app_valid_cancel_rollback()==ESP_OK)ec_event("ota","New firmware confirmed after healthy instrument grace period",1,0);
    }else{
        ec_event("ota_rollback","New firmware did not reach healthy live acquisition; rolling back",1,0);vTaskDelay(pdMS_TO_TICKS(500));esp_restart();
    }
    vTaskDelete(NULL);
}
static esp_err_t websocket(httpd_req_t *r){
    int fd=httpd_req_to_sockfd(r);
    if(r->method==HTTP_GET){
        if(!same_origin(r))return error_json(r,"403 Forbidden","WebSocket origin must match this instrument");
        xSemaphoreTake(client_lock,portMAX_DELAY);int slot=-1;
        for(int i=0;i<2;i++)if(clients[i].fd<0||httpd_ws_get_fd_info(server,clients[i].fd)!=HTTPD_WS_CLIENT_WEBSOCKET){slot=i;break;}
        if(slot>=0){unsigned gen=clients[slot].generation+1;clients[slot]=(client_t){.fd=fd,.generation=gen,.rate=20};}
        xSemaphoreGive(client_lock);if(slot<0)return error_json(r,"503 Service Unavailable","Two live dashboard clients are already connected");return ESP_OK;
    }
    httpd_ws_frame_t f={0};esp_err_t err=httpd_ws_recv_frame(r,&f,0);if(err!=ESP_OK)return err;
    if(f.len>1024)return ESP_FAIL;
    uint8_t body[1025];
    f.payload=body;
    if(f.len){err=httpd_ws_recv_frame(r,&f,1024);if(err!=ESP_OK)return err;}
    body[f.len]=0;
    if(f.type==HTTPD_WS_TYPE_CLOSE){xSemaphoreTake(client_lock,portMAX_DELAY);for(int i=0;i<2;i++)if(clients[i].fd==fd)clients[i].fd=-1;xSemaphoreGive(client_lock);return ESP_OK;}
    if(f.type!=HTTPD_WS_TYPE_TEXT)return ESP_OK;
    cJSON *o=cJSON_Parse((char*)body);if(!o)return ESP_OK;cJSON *rate=cJSON_GetObjectItemCaseSensitive(o,"audio_summary_hz");unsigned effective=cJSON_IsNumber(rate)?(unsigned)rate->valueint:20;if(effective<1)effective=1;if(effective>20)effective=20;
    xSemaphoreTake(client_lock,portMAX_DELAY);for(int i=0;i<2;i++)if(clients[i].fd==fd)clients[i].rate=effective;xSemaphoreGive(client_lock);cJSON_Delete(o);
    o=cJSON_CreateObject();cJSON_AddStringToObject(o,"type","subscribed");cJSON_AddNumberToObject(o,"audio_summary_hz",ec_ws_clients>1?10:effective);cJSON_AddNumberToObject(o,"pressure_hz",20);cJSON_AddNumberToObject(o,"light_hz",5);return ws_json(fd,o);
}
esp_err_t ec_web_start(void){
    const esp_partition_t *running=esp_ota_get_running_partition();esp_ota_img_states_t state;
    bool pending=running&&esp_ota_get_state_partition(running,&state)==ESP_OK&&state==ESP_OTA_IMG_PENDING_VERIFY;
    client_lock=xSemaphoreCreateMutex();capture_lock=xSemaphoreCreateMutex();if(!client_lock||!capture_lock)return ESP_ERR_NO_MEM;
    httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();cfg.stack_size=14336;cfg.max_uri_handlers=16;cfg.max_open_sockets=7;cfg.lru_purge_enable=true;cfg.recv_wait_timeout=2;cfg.send_wait_timeout=1;cfg.uri_match_fn=httpd_uri_match_wildcard;
    esp_err_t err=httpd_start(&server,&cfg);if(err!=ESP_OK)return err;
    httpd_uri_t ws={.uri="/ws/v1/live",.method=HTTP_GET,.handler=websocket,.is_websocket=true,.handle_ws_control_frames=true};httpd_register_uri_handler(server,&ws);
    httpd_uri_t get={.uri="/api/*",.method=HTTP_GET,.handler=get_api};httpd_register_uri_handler(server,&get);
    httpd_uri_t post={.uri="/api/*",.method=HTTP_POST,.handler=post_api};httpd_register_uri_handler(server,&post);
    httpd_uri_t legacy={.uri="/data",.method=HTTP_GET,.handler=get_api};httpd_register_uri_handler(server,&legacy);
    httpd_uri_t asset={.uri="/*",.method=HTTP_GET,.handler=assets};httpd_register_uri_handler(server,&asset);
    if(xTaskCreate(stream_task,"telemetry",4096,NULL,3,NULL)!=pdPASS)return ESP_ERR_NO_MEM;
    if(pending&&xTaskCreate(ota_confirm_task,"ota_confirm",3072,NULL,2,NULL)!=pdPASS)return ESP_ERR_NO_MEM;
    ESP_LOGI(TAG,"Dashboard and API ready on port 80");return ESP_OK;
}
