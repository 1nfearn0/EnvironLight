#include "ec_json.h"
#include "ec_history.h"
#include "ec_radio.h"
#include "esp_heap_caps.h"
#include "esp_system.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include <math.h>

static void number(cJSON *o,const char *key,double v){if(isfinite(v))cJSON_AddNumberToObject(o,key,v);else cJSON_AddNullToObject(o,key);}
static void floats(cJSON *o,const char *key,const float *v,size_t n){cJSON *a=cJSON_AddArrayToObject(o,key);for(size_t i=0;i<n;i++)cJSON_AddItemToArray(a,isfinite(v[i])?cJSON_CreateNumber(v[i]):cJSON_CreateNull());}
static void integers(cJSON *o,const char *key,const void *values,size_t n,unsigned width,bool sign){
    cJSON *a=cJSON_AddArrayToObject(o,key);
    for(size_t i=0;i<n;i++){double v=width==1?((const uint8_t*)values)[i]:(sign?((const int16_t*)values)[i]:((const uint16_t*)values)[i]);cJSON_AddItemToArray(a,cJSON_CreateNumber(v));}
}
#define NUM(o,v,k) number(o,#k,(v)->k)
static cJSON *audio_json(const ec_audio_t *v){
    cJSON *o=cJSON_CreateObject();NUM(o,v,t_us);NUM(o,v,seq);NUM(o,v,flags);
    NUM(o,v,dbfs);NUM(o,v,peak_dbfs);NUM(o,v,spl_est);NUM(o,v,dba_est);NUM(o,v,dbc_est);
    NUM(o,v,leq_1s);NUM(o,v,leq_10s);NUM(o,v,leq_60s);NUM(o,v,l10);NUM(o,v,l50);NUM(o,v,l90);
    NUM(o,v,centroid_hz);NUM(o,v,bandwidth_hz);NUM(o,v,rolloff_hz);NUM(o,v,flatness);NUM(o,v,flux);
    NUM(o,v,dominant_hz);NUM(o,v,crest_db);NUM(o,v,zero_crossing_rate);NUM(o,v,coverage);
    NUM(o,v,capture_overruns);NUM(o,v,dsp_drops);NUM(o,v,processing_us);
    floats(o,"bands",v->bands,8);integers(o,"spectrum",v->spectrum,EC_BINS,1,false);
    integers(o,"wave_min",v->wave_min,EC_ENVELOPE,2,true);integers(o,"wave_max",v->wave_max,EC_ENVELOPE,2,true);
    cJSON_AddStringToObject(o,"calibration","estimated_factory_sensitivity");
    cJSON_AddStringToObject(o,"leq_units","dBA_est");return o;
}
cJSON *ec_light_json(const ec_light_t *v){
    cJSON *o=cJSON_CreateObject();NUM(o,v,t_us);NUM(o,v,seq);NUM(o,v,flags);
    integers(o,"raw",v->raw,8,2,false);floats(o,"basic",v->basic,8);floats(o,"profile",v->profile,8);
    NUM(o,v,clear_raw);NUM(o,v,nir_raw);NUM(o,v,gain);NUM(o,v,integration_ms);NUM(o,v,adc_used_pct);NUM(o,v,headroom_pct);NUM(o,v,actual_hz);
    NUM(o,v,centroid_nm);NUM(o,v,red_blue_ratio);NUM(o,v,entropy_pct);NUM(o,v,flux);NUM(o,v,cct_k);NUM(o,v,cie_x);NUM(o,v,cie_y);
    NUM(o,v,reads);NUM(o,v,errors);NUM(o,v,recoveries);return o;
}
static cJSON *atmos_json(const ec_atmos_t *v){
    cJSON *o=cJSON_CreateObject();NUM(o,v,t_us);NUM(o,v,seq);NUM(o,v,flags);NUM(o,v,climate_us);NUM(o,v,pressure_us);
    NUM(o,v,temperature_c);NUM(o,v,humidity_rh);NUM(o,v,bmp_temperature_c);NUM(o,v,pressure_pa);
    NUM(o,v,dew_point_c);NUM(o,v,absolute_humidity_gm3);NUM(o,v,vpd_kpa);NUM(o,v,heat_index_c);
    NUM(o,v,pressure_residual_pa);NUM(o,v,pressure_slope_pas);NUM(o,v,relative_height_m);NUM(o,v,pressure_noise_pa);NUM(o,v,pressure_hz);
    NUM(o,v,temperature_slope_cmin);NUM(o,v,humidity_slope_rhmin);NUM(o,v,ah_slope_gm3min);
    NUM(o,v,climate_reads);NUM(o,v,climate_errors);NUM(o,v,pressure_reads);NUM(o,v,pressure_errors);
    floats(o,"pressure_psd",v->pressure_psd,4);return o;
}
cJSON *ec_system_json(void){
    cJSON *o=cJSON_CreateObject();cJSON_AddStringToObject(o,"version",EC_VERSION);
    number(o,"heap_free",heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
    number(o,"heap_min",heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
    number(o,"heap_largest",heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
    number(o,"psram_free",heap_caps_get_free_size(MALLOC_CAP_SPIRAM));number(o,"psram_total",heap_caps_get_total_size(MALLOC_CAP_SPIRAM));
    number(o,"ws_clients",ec_ws_clients);number(o,"ws_drops",ec_ws_drops);number(o,"reset_reason",esp_reset_reason());
    cJSON_AddStringToObject(o,"idf_version",esp_get_idf_version());cJSON_AddStringToObject(o,"build_date",__DATE__ " " __TIME__);
    cJSON_AddItemToObject(o,"storage",ec_history_status_json());
    cJSON_AddStringToObject(o,"model_state","not_installed");cJSON_AddStringToObject(o,"event_engine","evidence_heuristics");
    return o;
}
cJSON *ec_snapshot_json(const ec_snapshot_t *s,bool radio){
    cJSON *o=cJSON_CreateObject();cJSON_AddStringToObject(o,"type","snapshot");number(o,"schema_version",EC_SCHEMA);
    cJSON_AddStringToObject(o,"device_id",ec_device_id());cJSON_AddStringToObject(o,"profile_id",ec_is_scout()?"radioscout":"environlight");
    number(o,"boot_id",s->boot_id);number(o,"seq",s->audio.seq);number(o,"uptime_us",s->uptime_us);number(o,"epoch_s",s->epoch_s);
    cJSON_AddItemToObject(o,"audio",audio_json(&s->audio));cJSON_AddItemToObject(o,"light",ec_light_json(&s->light));cJSON_AddItemToObject(o,"atmos",atmos_json(&s->atmos));
    cJSON_AddItemToObject(o,"system",ec_system_json());if(radio)cJSON_AddItemToObject(o,"radio",ec_radio_json());return o;
}
cJSON *ec_manifest_json(void){
    cJSON *o=cJSON_CreateObject();cJSON_AddStringToObject(o,"family","EnvironCore");cJSON_AddStringToObject(o,"device_id",ec_device_id());cJSON_AddStringToObject(o,"device_name",ec_device_name());
    cJSON_AddStringToObject(o,"profile_id",ec_is_scout()?"radioscout":"environlight");cJSON_AddStringToObject(o,"hostname",ec_hostname());
    cJSON_AddStringToObject(o,"version",EC_VERSION);number(o,"schema_version",EC_SCHEMA);
    cJSON_AddStringToObject(o,"board",ec_is_scout()?"ESP32-WROOM-32D DOIT 30-pin":"ESP32-S3-WROOM-1 N16R8");
    cJSON *cap=cJSON_AddArrayToObject(o,"capabilities");const char *caps[]={"audio_continuous","spectral","temperature","humidity","pressure","history","events","radio","known_devices"};
    for(size_t i=ec_is_scout()?5:0;i<sizeof(caps)/sizeof(caps[0]);i++)cJSON_AddItemToArray(cap,cJSON_CreateString(caps[i]));
    number(o,"audio_sample_rate",EC_SAMPLE_RATE);number(o,"fft_size",EC_FFT_N);number(o,"hop_size",EC_HOP_N);number(o,"audio_publish_hz",20);
    number(o,"spectrum_bins",EC_BINS);number(o,"spectrum_min_hz",20);number(o,"spectrum_max_hz",20000);
    cJSON_AddStringToObject(o,"spectrum_scale","log_frequency_dbfs");cJSON_AddStringToObject(o,"spectrum_quantization","-120 + byte * 120 / 255 dBFS");
    cJSON_AddStringToObject(o,"websocket","/ws/v1/live");cJSON_AddStringToObject(o,"binary_protocol","EC1 little endian header20 audio660 pressure76");
    cJSON_AddBoolToObject(o,"wake_word",false);cJSON_AddBoolToObject(o,"raw_audio_flash_storage",false);cJSON_AddBoolToObject(o,"trained_classifier",false);
    cJSON_AddItemToObject(o,"retention",ec_history_status_json());uint32_t size=0;if(esp_flash_get_size(NULL,&size)==ESP_OK)number(o,"flash_bytes",size);
    cJSON *sensors=cJSON_AddArrayToObject(o,"sensors");if(!ec_is_scout()){const char *names[]={"ICS43434","AS7341","BMP280","DHT22"};for(int i=0;i<4;i++)cJSON_AddItemToArray(sensors,cJSON_CreateString(names[i]));}
    cJSON *pins=cJSON_AddObjectToObject(o,"pins");number(pins,"dht",4);number(pins,"bmp_sda",6);number(pins,"bmp_scl",7);number(pins,"as_sda",8);number(pins,"as_scl",9);number(pins,"mic_sd",15);number(pins,"mic_bclk",16);number(pins,"mic_ws",17);
    return o;
}
cJSON *ec_events_json(void){
    ec_event_t events[32];size_t n=ec_events_copy(events,32,0);cJSON *o=cJSON_CreateObject(),*a=cJSON_AddArrayToObject(o,"events");
    for(size_t i=0;i<n;i++){ec_event_t *e=&events[i];cJSON *v=cJSON_CreateObject();NUM(v,e,seq);NUM(v,e,t_us);NUM(v,e,epoch_s);NUM(v,e,evidence);NUM(v,e,confidence);cJSON_AddStringToObject(v,"kind",e->kind);cJSON_AddStringToObject(v,"label",e->label);cJSON_AddItemToArray(a,v);}return o;
}
