#include "ec_sensor_math.h"
#include <math.h>
#include <string.h>

static uint16_t u16(const uint8_t *p) { return (uint16_t)p[0] | (uint16_t)p[1] << 8; }
void ec_bmp_decode_cal(const uint8_t b[24], ec_bmp_cal_t *c) {
    c->t1=u16(b); c->t2=(int16_t)u16(b+2); c->t3=(int16_t)u16(b+4);
    c->p1=u16(b+6); c->p2=(int16_t)u16(b+8); c->p3=(int16_t)u16(b+10);
    c->p4=(int16_t)u16(b+12); c->p5=(int16_t)u16(b+14); c->p6=(int16_t)u16(b+16);
    c->p7=(int16_t)u16(b+18); c->p8=(int16_t)u16(b+20); c->p9=(int16_t)u16(b+22);
}
bool ec_bmp_compensate(const ec_bmp_cal_t *c, int32_t t, int32_t p, float *tc, float *pa) {
    if (!c || !tc || !pa || c->p1==0 || t==0x80000 || p==0x80000 ||
        t<0 || t>0xfffff || p<0 || p>0xfffff) return false;
    /* Bosch BMP280 DS001-26 section 8.1 double-precision compensation. */
    double v1=((double)t/16384.0-(double)c->t1/1024.0)*c->t2;
    double v2=((double)t/131072.0-(double)c->t1/8192.0);
    v2=v2*v2*c->t3;
    double fine=v1+v2;
    *tc=(float)(fine/5120.0);
    v1=fine/2.0-64000.0;
    v2=v1*v1*c->p6/32768.0;
    v2+=v1*c->p5*2.0;
    v2=v2/4.0+c->p4*65536.0;
    v1=(c->p3*v1*v1/524288.0+c->p2*v1)/524288.0;
    v1=(1.0+v1/32768.0)*c->p1;
    if (fabs(v1)<1e-12) return false;
    double pressure=1048576.0-p;
    pressure=(pressure-v2/4096.0)*6250.0/v1;
    v1=c->p9*pressure*pressure/2147483648.0;
    v2=pressure*c->p8/32768.0;
    pressure+=(v1+v2+c->p7)/16.0;
    *pa=(float)pressure;
    return isfinite(*tc)&&isfinite(*pa)&&*tc>=-40&&*tc<=85&&*pa>=30000&&*pa<=110000;
}
bool ec_dht_decode(const uint8_t b[5], float *tc, float *rh) {
    if (!b||!tc||!rh||(uint8_t)(b[0]+b[1]+b[2]+b[3])!=b[4]) return false;
    *rh=(float)(((uint16_t)b[0]<<8)|b[1])/10.0f;
    *tc=(float)((((uint16_t)b[2]&0x7f)<<8)|b[3])/10.0f;
    if (b[2]&0x80) *tc=-*tc;
    return *rh>=0&&*rh<=100&&*tc>=-40&&*tc<=80;
}
void ec_light_exposure_step(unsigned *g, unsigned *t, int action) {
    if (!g||!t) return;
    if (*g>7) *g=7;
    if (*t>3) *t=3;
    if (action>0) { if (*g<7) ++*g; else if (*t<3) ++*t; }
    else if (action<0) { if (*t>0) --*t; else if (*g>0) --*g; }
}
/* Preserve baseline ATIME=29 / ASTEP=599 at the 50 ms exposure. The ladder
 * provides 12.51,25.02,50.04,100.08 ms under DS000504 v3's timing formula. */
uint16_t ec_light_astep(unsigned i) {
    static const uint16_t steps[4]={149,299,599,1199};
    return steps[i<4?i:3];
}
float ec_light_integration_ms(unsigned i) { return (EC_LIGHT_ATIME+1.0f)*(ec_light_astep(i)+1)*0.00278f; }
uint32_t ec_light_full_scale(unsigned i) {
    uint32_t fs=(EC_LIGHT_ATIME+1u)*(ec_light_astep(i)+1u);
    return fs<65535u?fs:65535u;
}

/* 48 kHz bilinear-transform A/C weighting, pole frequencies from IEC 61672
 * analytic curves (20.598997,107.65265,737.86223,12194.217 Hz), normalised to
 * 0 dB at digital 1 kHz. Second-order sections avoid a fragile sixth-order
 * direct form. The bilinear high-frequency warp is documented: this is an
 * estimated instrument, not a class-certified sound-level meter. */
static const double A[3][5]={
    {0.2341830426035607,0.4683660852071215,0.2341830426035607,-0.2245584580597791,0.0126066252715464},
    {1,-2,1,-1.893870494723071,0.8951597690946617},
    {1,-2,1,-1.994614455993021,0.9946217070140843}
};
static const double C[2][5]={
    {0.1978907070198737,0.3957814140397473,0.1978907070198737,-0.2245584580597791,0.0126066252715464},
    {1,-2,1,-1.994614455993021,0.9946217070140843}
};
void ec_weighting_reset(ec_weighting_t *s) { memset(s,0,sizeof(*s)); }
static double sos(double x, const double b[5], double z[2]) {
    double y=b[0]*x+z[0];
    z[0]=b[1]*x-b[3]*y+z[1]; z[1]=b[2]*x-b[4]*y;
    return y;
}
void ec_weighting_sample(ec_weighting_t *s,float sample,float *a,float *c) {
    double ya=sample,yc=sample;
    for(unsigned i=0;i<3;i++) ya=sos(ya,A[i],s->a[i]);
    for(unsigned i=0;i<2;i++) yc=sos(yc,C[i],s->c[i]);
    *a=(float)ya; *c=(float)yc;
}
