# Sensor implementation and validation notes

This component is native ESP-IDF 5.5. It contains no Arduino dependency.

| Instrument | Initial hardware settings | Timing and truth |
|---|---|---|
| ICS43434 | SD 15, BCLK 16, WS 17; L/R selects left; Philips I2S; mono 48 kHz; 32-bit slot | Independent continuous DMA reader. 512-sample hops; 2048-sample periodic Hann; 75% overlap. DMA and DSP losses have separate counters. An all-zero digital stream becomes stale. |
| BMP280 | SDA 6, SCL 7; address 0x76 then 0x77; bus 100 kHz; temperature ×2, pressure ×4, IIR off | One forced conversion per target 20 ms slot. Measuring status is checked before one shadowed six-byte read. Actual cadence is published. Every failed/interrupted series invalidates the pressure FFT window until 1024 new samples exist. |
| DHT22 | Data 4, open-drain host drive; external pull-up recommended | RMT records pulse durations without disabling interrupts for the sensor transaction. Requests are 2.5 s apart. Checksum and physical range checks are mandatory. |
| AS7341 | SDA 8, SCL 9; address 0x39; separate 100 kHz bus | Both SMUX phases use identical gain/integration. A frame publishes only when both succeed. Missing phases never combine with old channels. Actual complete-frame cadence is published. |

## Optical exposure

ATIME remains 29, preserving the known ASTEP 599 baseline at 50.04 ms. The
four ASTEP values 149/299/599/1199 give 12.51/25.02/50.04/100.08 ms per phase.
ADC full scale is `min(65535, (ATIME+1)*(ASTEP+1))`. The gains are
1/2/4/8/16/32/64/128. Gain increases precede integration increases; longer
integration is shortened first on a reduction. Changes occur between complete
frames, and the next frame carries a settling flag. The controller responds to
STATUS2 analog/digital saturation as well as ADC utilisation. More than 70%
utilisation means low headroom; saturation is separately flagged. The low end
of the ladder may produce fewer counts in very dark scenes: the quality flag
and raw counts remain visible.

Light `basic[]` is raw/(gain × integration milliseconds); `profile[]` is 0–100
relative to the current strongest channel. Flux is 0–1 RMS change in that
normalised shape. CIE/CCT outputs are coarse centre-sampled proxies, restricted
to broad roughly-white unsaturated, settled scenes. They require sensor
responsivity calibration before quantitative colorimetry is credible.

## Acoustic processing and capture

The digital RMS is dBFS after frame-mean removal. A/C estimates use persistent
48 kHz digital SOS filters, not an FFT-bin correction to an unweighted scalar.
The filters originate from the analytic A/C pole frequencies, bilinear
transformed and normalised at digital 1 kHz. This introduces the expected
high-frequency bilinear warp; there is no IEC meter-class claim. The provisional
baseline sensitivity offset is +120 dB (-26 dBFS at 94 dB SPL), adjustable at
build time. Levels remain estimated until physically calibrated.

Leq values are energy means of non-overlapping 512-sample weighted blocks.
Coverage uses actual processed samples against monotonic wall time. L10/L50/L90
are level-exceedance percentiles of those blocks over the available last minute;
they remain unavailable until at least 10 seconds of data and 90% coverage.

Spectrum bins are 256 logarithmic bins with edges `20*1000^(b/256)` Hz. Each
contains the strongest native FFT-bin amplitude. Empty display bins stay empty
at the -120 dBFS floor; interpolation is a display decision. Hann coherent-gain
normalisation makes a full-scale bin-centred sine 0 dBFS. The 8 broad sound
bands are percentages of spectral energy; flatness is 0–1. Wave envelopes use
int16 min/max over 64 chronological segments, with ±1 mapped to ±32767.

`ec_capture_arm(5|10|30)` reserves the single-client RAM-only PCM path. Recording
starts on the first `ec_capture_read`, allowing the phone to finish setting up
its download before any audio enters the small ring. An unread reservation
expires after 30 seconds. `ec_capture_pending` includes an armed or unread
completed capture; `ec_capture_recording` is true only while samples are being
recorded for an attached reader. The client must drain throughout recording. The 128 KiB ring
holds about 0.68 seconds of 48 kHz mono 32-bit PCM. The microphone's 24 useful
bits occupy bits 31:8; the bottom byte is cleared, preserving native useful
content losslessly. Ring overflow or DMA loss aborts capture rather than
blocking acquisition or adding zeros. `ec_capture_dropped()!=0` identifies an
incomplete capture; a DMA-loss count is a lower-bound indicator rather than a
claim to know the exact missing sample count. Always call `ec_capture_cancel`
after completing or abandoning a download. No flash audio archive, playback,
transcription or wake processing is implemented.

## Checks performed

`tests/test_sensors.c` passes a native C11 build with `-Wall -Wextra -Werror
-pedantic` and address/undefined-behaviour sanitizers. It checks Bosch's worked
compensation fixture, invalid ADC/calibration handling, DHT checksum, signed
temperature and range handling, all optical exposure timings, and measured
steady-state 125 Hz / 1 kHz / 4 kHz responses of the actual A/C filters.

Exact v5.5 I2S, I2C master and RMT RX headers were inspected for the used types,
members, timeout units and callback signatures. This does not substitute for
an ESP-IDF target build. Board operation, microphone slot alignment, achieved
cadence, sensor calibration and a 24-hour soak still require real hardware.

Primary references checked: ESP-IDF release-v5.5 peripheral API documentation;
Bosch BMP280 BST-BMP280-DS001-26 revision 1.26; ams AS7341 DS000504 v3-00.
The AS7341 SMUX routing configuration is also checked against the Adafruit
driver; its BSD attribution is retained alongside this component.
