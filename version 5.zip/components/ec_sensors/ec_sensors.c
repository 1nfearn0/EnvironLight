#include "ec_sensors.h"
#include "ec.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

void ec_audio_start(void);
void ec_environment_start(void);
void ec_light_start(void);

void ec_sensors_start(void) {
    static bool started;
    if (started||ec_is_scout()) return;
    started=true;
    ec_audio_start();
    ec_environment_start();
    ec_light_start();
    ESP_LOGI("sensors","Independent audio, light, pressure and climate workers started");
}
