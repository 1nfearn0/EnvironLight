#include "ec.h"
#include "ec_math.h"
#include "ec_sensor_math.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "driver/rmt_rx.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include <math.h>
#include <string.h>

#define PRESSURE_N 1024
#define PI 3.14159265358979323846f
static const char *TAG="atmosphere";
static ec_atmos_t atmos;
static SemaphoreHandle_t state_lock;

static void publish_locked(void) {
    /* Call with the atmosphere mutex held through ec_update_atmos, so the two
     * producers cannot publish older snapshots over newer climate fields. */
    atmos.seq++;atmos.t_us=esp_timer_get_time();
    atmos.flags=EC_QUALITY_ESTIMATED;
    if(!atmos.climate_us||!atmos.pressure_us||
       atmos.t_us-atmos.climate_us>10000000||atmos.t_us-atmos.pressure_us>1000000)
        atmos.flags|=EC_QUALITY_STALE;
}
static esp_err_t rd(i2c_master_dev_handle_t dev,uint8_t reg,void *out,size_t n) {
    return i2c_master_transmit_receive(dev,&reg,1,out,n,30);
}
static esp_err_t wr(i2c_master_dev_handle_t dev,uint8_t reg,uint8_t value) {
    uint8_t b[2]={reg,value};return i2c_master_transmit(dev,b,2,30);
}
static bool bmp_attach(i2c_master_bus_handle_t bus,i2c_master_dev_handle_t *dev,ec_bmp_cal_t *cal) {
    for(uint8_t addr=0x76;addr<=0x77;addr++) {
        i2c_device_config_t cfg={.dev_addr_length=I2C_ADDR_BIT_LEN_7,.device_address=addr,.scl_speed_hz=100000};
        i2c_master_dev_handle_t candidate=NULL;
        if(i2c_master_bus_add_device(bus,&cfg,&candidate)!=ESP_OK) continue;
        uint8_t id=0,raw[24],status=0;
        if(rd(candidate,0xd0,&id,1)==ESP_OK&&id==0x58&&wr(candidate,0xe0,0xb6)==ESP_OK) {
            vTaskDelay(pdMS_TO_TICKS(5));
            for(unsigned i=0;i<20;i++) {
                if(rd(candidate,0xf3,&status,1)!=ESP_OK) break;
                if(!(status&1)) break;
                vTaskDelay(1);
            }
            if(!(status&1)&&rd(candidate,0x88,raw,24)==ESP_OK) {
                ec_bmp_decode_cal(raw,cal);
                if(cal->p1&&cal->t1&&wr(candidate,0xf5,0)==ESP_OK) {
                    *dev=candidate;ESP_LOGI(TAG,"BMP280 found 0x%02x, 100 kHz, T×2/P×4, IIR off",addr);return true;
                }
            }
        }
        i2c_master_bus_rm_device(candidate);
    }
    return false;
}
static void pressure_analysis(float *history,unsigned head,unsigned count,float hz,
                              float *real,float *imag,float *slope,float *noise,float band[4]) {
    if(count<PRESSURE_N||hz<1) return;
    double sx=0,sy=0,sxx=0,sxy=0;
    for(unsigned i=0;i<PRESSURE_N;i++) {
        double x=(double)i/hz,y=history[(head+i)%PRESSURE_N];
        sx+=x;sy+=y;sxx+=x*x;sxy+=x*y;
    }
    double denominator=PRESSURE_N*sxx-sx*sx;
    double m=denominator?((PRESSURE_N*sxy-sx*sy)/denominator):0;
    double intercept=(sy-m*sx)/PRESSURE_N,ss=0,window_energy=0;
    for(unsigned i=0;i<PRESSURE_N;i++) {
        float residual=history[(head+i)%PRESSURE_N]-(float)(intercept+m*i/hz);
        float w=.5f-.5f*cosf(2*PI*i/PRESSURE_N);
        real[i]=residual*w;imag[i]=0;ss+=(double)residual*residual;window_energy+=w*w;
    }
    *slope=(float)m;*noise=(float)sqrt(ss/PRESSURE_N);
    ec_fft(real,imag,PRESSURE_N);
    memset(band,0,4*sizeof(float));
    const float edges[5]={.05f,.2f,1,5,20};
    float df=hz/PRESSURE_N;
    for(unsigned k=1;k<PRESSURE_N/2;k++) {
        float f=k*df;
        /* Single-sided density Pa²/Hz integrated over each measured band. */
        float psd=2*(real[k]*real[k]+imag[k]*imag[k])/(hz*(float)window_energy);
        for(unsigned b=0;b<4;b++) if(f>=edges[b]&&f<edges[b+1]) { band[b]+=psd*df;break; }
    }
    for(unsigned b=0;b<4;b++) if(edges[b+1]>hz/2) band[b]=NAN;
}
static void pressure_task(void *arg) {
    (void)arg;
    float *history=heap_caps_calloc(PRESSURE_N,sizeof(float),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    float *real=heap_caps_malloc(PRESSURE_N*sizeof(float),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    float *imag=heap_caps_malloc(PRESSURE_N*sizeof(float),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    i2c_master_bus_handle_t bus=NULL;
    i2c_master_bus_config_t bus_cfg={.i2c_port=I2C_NUM_0,.sda_io_num=GPIO_NUM_6,.scl_io_num=GPIO_NUM_7,
        .clk_source=I2C_CLK_SRC_DEFAULT,.glitch_ignore_cnt=7,.flags.enable_internal_pullup=true};
    while(i2c_new_master_bus(&bus_cfg,&bus)!=ESP_OK) {
        ESP_LOGE(TAG,"Pressure I2C bus init failed; retrying");vTaskDelay(pdMS_TO_TICKS(5000));
    }
    unsigned head=0,count=0,failures=0;
    uint64_t last_us=0,last_analysis=0,last_event=0;
    float reference=NAN,slow=NAN,hz=50,noise=NAN,slope=NAN,band[4]={NAN,NAN,NAN,NAN};
    for(;;) {
        i2c_master_dev_handle_t dev=NULL;ec_bmp_cal_t cal;
        if(!bmp_attach(bus,&dev,&cal)) {
            xSemaphoreTake(state_lock,portMAX_DELAY);atmos.pressure_errors++;publish_locked();
            ec_update_atmos(&atmos);xSemaphoreGive(state_lock);
            vTaskDelay(pdMS_TO_TICKS(5000));continue;
        }
        TickType_t next=xTaskGetTickCount();failures=0;count=head=0;last_us=0;
        for(;;) {
            uint8_t raw[6],status=8;float t=NAN,p=NAN;
            /* Forced mode schedules one distinct conversion per 20 ms slot.
             * 0x4d = osrs_t×2, osrs_p×4, forced. Nominal conversion 15.625 ms;
             * measuring status is checked before each shadowed 6-byte read. */
            bool ok=wr(dev,0xf4,0x4d)==ESP_OK;
            uint64_t deadline=esp_timer_get_time()+23000;
            vTaskDelay(pdMS_TO_TICKS(16));
            while(ok) {
                if(rd(dev,0xf3,&status,1)!=ESP_OK) { ok=false;break; }
                if(!(status&8)) break;
                if((uint64_t)esp_timer_get_time()>=deadline) { ok=false;break; }
                vTaskDelay(1);
            }
            if(ok) ok=rd(dev,0xf7,raw,6)==ESP_OK;
            if(ok) {
                int32_t adc_p=((int32_t)raw[0]<<12)|((int32_t)raw[1]<<4)|(raw[2]>>4);
                int32_t adc_t=((int32_t)raw[3]<<12)|((int32_t)raw[4]<<4)|(raw[5]>>4);
                ok=ec_bmp_compensate(&cal,adc_t,adc_p,&t,&p);
            }
            uint64_t now=esp_timer_get_time();
            if(ok) {
                failures=0;
                float dt=last_us?(now-last_us)/1e6f:.02f;
                if(dt>0) hz=.95f*hz+.05f/dt;
                last_us=now;
                if(!isfinite(reference)) reference=p;
                if(!isfinite(slow)) slow=p;
                slow+=(1-expf(-dt/30))*(p-slow);
                if(history) {
                    /* An interrupted conversion series does not qualify as a
                     * uniformly sampled FFT window. Refill before a new PSD. */
                    if(dt>.03f) { count=head=0;for(unsigned b=0;b<4;b++) band[b]=NAN; }
                    history[head]=p;head=(head+1)%PRESSURE_N;if(count<PRESSURE_N) count++;
                }
                if(history&&real&&imag&&count==PRESSURE_N&&now-last_analysis>=2000000) {
                    pressure_analysis(history,head,count,hz,real,imag,&slope,&noise,band);last_analysis=now;
                }
                float residual=p-slow;
                if(isfinite(noise)&&noise>0&&fabsf(residual)>fmaxf(3,6*noise)&&now-last_event>5000000) {
                    ec_event("pressure_candidate","Experimental pressure change above local variability",.4f,4);last_event=now;
                }
                xSemaphoreTake(state_lock,portMAX_DELAY);
                atmos.pressure_pa=p;atmos.bmp_temperature_c=t;atmos.pressure_us=now;atmos.pressure_reads++;
                atmos.pressure_hz=hz;atmos.pressure_residual_pa=residual;atmos.pressure_slope_pas=slope;
                atmos.pressure_noise_pa=noise;atmos.relative_height_m=ec_relative_height(p,reference);
                memcpy(atmos.pressure_psd,band,sizeof(band));publish_locked();
                ec_update_atmos(&atmos);xSemaphoreGive(state_lock);
            } else {
                count=head=0;
                for(unsigned b=0;b<4;b++) band[b]=NAN;
                xSemaphoreTake(state_lock,portMAX_DELAY);atmos.pressure_errors++;publish_locked();
                ec_update_atmos(&atmos);xSemaphoreGive(state_lock);
                if(++failures>=5) { ec_event("sensor_fault","BMP280 read failed; retrying independently",1,4);break; }
            }
            xTaskDelayUntil(&next,pdMS_TO_TICKS(20));
        }
        i2c_master_bus_rm_device(dev);i2c_master_bus_reset(bus);vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

static bool IRAM_ATTR dht_done(rmt_channel_handle_t channel,const rmt_rx_done_event_data_t *data,void *context) {
    (void)channel;
    BaseType_t wake=pdFALSE;size_t count=data->num_symbols;
    xQueueSendFromISR((QueueHandle_t)context,&count,&wake);return wake==pdTRUE;
}
static bool dht_receive(rmt_channel_handle_t rx,QueueHandle_t queue,rmt_symbol_word_t symbols[64],float *t,float *h) {
    size_t old;while(xQueueReceive(queue,&old,0)==pdTRUE) {}
    gpio_set_level(GPIO_NUM_4,0);esp_rom_delay_us(1100);
    rmt_receive_config_t cfg={.signal_range_min_ns=1000,.signal_range_max_ns=120000};
    if(rmt_receive(rx,symbols,64*sizeof(*symbols),&cfg)!=ESP_OK) { gpio_set_level(GPIO_NUM_4,1);return false; }
    /* OD high releases the line; RMT captures timings without masking interrupts. */
    gpio_set_level(GPIO_NUM_4,1);
    size_t n=0;
    if(xQueueReceive(queue,&n,pdMS_TO_TICKS(30))!=pdTRUE) { rmt_disable(rx);rmt_enable(rx);return false; }
    uint8_t b[5]={0};unsigned bits=0;bool response=false;
    /* Flatten level/duration pairs: first long ~80 us high is the sensor's
     * response. The following 40 highs encode 26-28 us zero / ~70 us one. */
    for(size_t i=0;i<n&&bits<40;i++) for(unsigned half=0;half<2&&bits<40;half++) {
        unsigned level=half?symbols[i].level1:symbols[i].level0;
        unsigned duration=half?symbols[i].duration1:symbols[i].duration0;
        if(!level||!duration) continue;
        if(!response) { if(duration>=60&&duration<=110) response=true;continue; }
        if(duration<15||duration>100) return false;
        b[bits/8]=(uint8_t)((b[bits/8]<<1)|(duration>48));bits++;
    }
    return bits==40&&ec_dht_decode(b,t,h);
}
static float heat_index(float t,float rh) {
    /* NOAA/Rothfusz; only applicable in warm humid conditions. */
    if(t<26.7f||rh<40) return NAN;
    double f=t*1.8+32;
    double hi=-42.379+2.04901523*f+10.14333127*rh-.22475541*f*rh-.00683783*f*f
       -.05481717*rh*rh+.00122874*f*f*rh+.00085282*f*rh*rh-.00000199*f*f*rh*rh;
    return (float)((hi-32)/1.8);
}
static void climate_task(void *arg) {
    (void)arg;
    QueueHandle_t queue=xQueueCreate(1,sizeof(size_t));rmt_channel_handle_t rx=NULL;
    rmt_symbol_word_t symbols[64];
    rmt_rx_channel_config_t cfg={.gpio_num=GPIO_NUM_4,.clk_src=RMT_CLK_SRC_DEFAULT,.resolution_hz=1000000,
        .mem_block_symbols=64,.flags.with_dma=false};
    while(!queue||rmt_new_rx_channel(&cfg,&rx)!=ESP_OK) {
        ESP_LOGE(TAG,"DHT22 RMT init failed; retrying");vTaskDelay(pdMS_TO_TICKS(5000));
        if(!queue) queue=xQueueCreate(1,sizeof(size_t));
    }
    rmt_rx_event_callbacks_t cb={.on_recv_done=dht_done};
    if(rmt_rx_register_event_callbacks(rx,&cb,queue)!=ESP_OK||rmt_enable(rx)!=ESP_OK) {
        ESP_LOGE(TAG,"DHT22 RMT callback/enable failed");vTaskDelete(NULL);return;
    }
    gpio_config_t gpio={.pin_bit_mask=1ULL<<4,.mode=GPIO_MODE_INPUT_OUTPUT_OD,
        .pull_up_en=GPIO_PULLUP_ENABLE,.pull_down_en=GPIO_PULLDOWN_DISABLE};
    gpio_config(&gpio);gpio_set_level(GPIO_NUM_4,1);
    float prev_t=NAN,prev_h=NAN,prev_ah=NAN;uint64_t prev_us=0;
    vTaskDelay(pdMS_TO_TICKS(2000));
    TickType_t next=xTaskGetTickCount();
    for(;;) {
        float t=NAN,h=NAN;bool ok=dht_receive(rx,queue,symbols,&t,&h);uint64_t now=esp_timer_get_time();
        float ah=ok?ec_absolute_humidity(t,h):NAN;
        xSemaphoreTake(state_lock,portMAX_DELAY);
        if(ok) {
            atmos.temperature_c=t;atmos.humidity_rh=h;atmos.climate_us=now;atmos.climate_reads++;
            atmos.dew_point_c=ec_dew_point(t,h);atmos.absolute_humidity_gm3=ah;atmos.vpd_kpa=ec_vpd(t,h);
            atmos.heat_index_c=heat_index(t,h);
            float minutes=prev_us?(now-prev_us)/60000000.0f:0;
            atmos.temperature_slope_cmin=minutes?(t-prev_t)/minutes:NAN;
            atmos.humidity_slope_rhmin=minutes?(h-prev_h)/minutes:NAN;
            atmos.ah_slope_gm3min=minutes?(ah-prev_ah)/minutes:NAN;
            prev_t=t;prev_h=h;prev_ah=ah;prev_us=now;
        } else atmos.climate_errors++;
        publish_locked();ec_update_atmos(&atmos);xSemaphoreGive(state_lock);
        xTaskDelayUntil(&next,pdMS_TO_TICKS(2500));
    }
}
void ec_environment_start(void) {
    state_lock=xSemaphoreCreateMutex();
    if(!state_lock) { ESP_LOGE(TAG,"Cannot allocate atmosphere mutex");return; }
    memset(&atmos,0,sizeof(atmos));
    atmos.temperature_c=atmos.humidity_rh=atmos.bmp_temperature_c=atmos.pressure_pa=NAN;
    atmos.dew_point_c=atmos.absolute_humidity_gm3=atmos.vpd_kpa=atmos.heat_index_c=NAN;
    atmos.pressure_residual_pa=atmos.pressure_slope_pas=atmos.relative_height_m=NAN;
    atmos.pressure_noise_pa=atmos.temperature_slope_cmin=atmos.humidity_slope_rhmin=atmos.ah_slope_gm3min=NAN;
    for(unsigned i=0;i<4;i++) atmos.pressure_psd[i]=NAN;
    if(xTaskCreatePinnedToCore(pressure_task,"ec_pressure",6144,NULL,8,NULL,0)!=pdPASS)
        ESP_LOGE(TAG,"Cannot create pressure task");
    if(xTaskCreatePinnedToCore(climate_task,"ec_climate",4096,NULL,4,NULL,0)!=pdPASS)
        ESP_LOGE(TAG,"Cannot create climate task");
}
