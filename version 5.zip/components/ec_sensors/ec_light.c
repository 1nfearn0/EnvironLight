#include "ec.h"
#include "ec_math.h"
#include "ec_sensor_math.h"
#include "driver/i2c_master.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <math.h>
#include <string.h>

static const char *TAG="light";
/* SMUX routing values cross-checked against Adafruit's BSD-licensed AS7341
 * driver, Copyright 2020 Bryan Siepert for Adafruit Industries. Register
 * control is implemented natively here. See AS7341-SMUX-NOTICE.txt. */
static const uint8_t smux[2][20]={
    {0x30,0x01,0,0,0,0x42,0,0,0x50,0,0,0,0x20,0x04,0,0x30,0x01,0x50,0,0x06},
    {0,0,0,0x40,0x02,0,0x10,0x03,0x50,0x10,0x03,0,0,0,0x24,0,0,0x50,0,0x06}
};
static esp_err_t rd(i2c_master_dev_handle_t dev,uint8_t reg,void *data,size_t n) {
    return i2c_master_transmit_receive(dev,&reg,1,data,n,30);
}
static esp_err_t wr(i2c_master_dev_handle_t dev,uint8_t reg,uint8_t value) {
    uint8_t b[2]={reg,value};return i2c_master_transmit(dev,b,2,30);
}
static bool configure(i2c_master_dev_handle_t dev,unsigned gain,unsigned time) {
    uint8_t agc=0,config=0;
    if(wr(dev,0x80,1)!=ESP_OK||wr(dev,0xa9,0)!=ESP_OK) return false;
    vTaskDelay(pdMS_TO_TICKS(3));
    if(rd(dev,0xb1,&agc,1)!=ESP_OK||wr(dev,0xb1,agc&~4u)!=ESP_OK) return false;
    /* Explicitly select spectral measurement mode, not GPIO synchronisation. */
    if(wr(dev,0xa9,0x10)!=ESP_OK||rd(dev,0x70,&config,1)!=ESP_OK||
       wr(dev,0x70,config&~3u)!=ESP_OK||wr(dev,0xa9,0)!=ESP_OK) return false;
    uint16_t step=ec_light_astep(time);uint8_t integration[3]={0xca,(uint8_t)step,(uint8_t)(step>>8)};
    return wr(dev,0x81,EC_LIGHT_ATIME)==ESP_OK&&i2c_master_transmit(dev,integration,3,30)==ESP_OK&&
        wr(dev,0xaa,(uint8_t)(gain+1))==ESP_OK&&wr(dev,0xd6,1)==ESP_OK;
}
static bool phase(i2c_master_dev_handle_t dev,unsigned phase_index,float integration_ms,
                  uint16_t values[6],bool *saturated) {
    /* Disable integration before a route/settings change. Both phases retain
     * one immutable exposure. Polling yields to other workers between short
     * I2C transactions; there is no long global sensor loop. */
    if(wr(dev,0x80,1)!=ESP_OK||wr(dev,0xaf,0x10)!=ESP_OK) return false;
    uint8_t command[21]={0};memcpy(command+1,smux[phase_index],20);
    if(i2c_master_transmit(dev,command,sizeof(command),30)!=ESP_OK||wr(dev,0x80,0x11)!=ESP_OK) return false;
    uint64_t deadline=esp_timer_get_time()+50000;
    uint8_t enable=0x10;
    while(enable&0x10) {
        if(rd(dev,0x80,&enable,1)!=ESP_OK) return false;
        if((uint64_t)esp_timer_get_time()>deadline) return false;
        if(enable&0x10) vTaskDelay(1);
    }
    if(wr(dev,0x80,3)!=ESP_OK) return false;
    deadline=esp_timer_get_time()+(uint64_t)(integration_ms*1000)+50000;
    /* Wait until near expected completion, then inspect the actual AVALID bit. */
    unsigned wait_ms=(unsigned)integration_ms;
    if(wait_ms>2) vTaskDelay(pdMS_TO_TICKS(wait_ms-1));
    uint8_t status=0;
    do {
        if(rd(dev,0xa3,&status,1)!=ESP_OK) return false;
        if(status&0x40) break;
        if((uint64_t)esp_timer_get_time()>deadline) return false;
        vTaskDelay(1);
    } while(true);
    uint8_t raw[13];
    if(rd(dev,0x94,raw,sizeof(raw))!=ESP_OK) return false;
    *saturated|=(status&0x18)!=0||(raw[0]&0x80)!=0;
    for(unsigned i=0;i<6;i++) values[i]=(uint16_t)raw[1+2*i]|(uint16_t)raw[2+2*i]<<8;
    return wr(dev,0x80,1)==ESP_OK;
}
static void metrics(ec_light_t *out,float previous[8]) {
    static const float nm[8]={415,445,480,515,555,590,630,680};
    /* Coarse centre-sampled CIE proxies; no sensor responsivity calibration is
     * implied. They are withheld unless the spectral response is broad and
     * approximately white. Saturated and dark scenes always return null. */
    static const float cx[8]={.01431f,.34828f,.09564f,.02910f,.51205f,1.02630f,.64240f,.04677f};
    static const float cy[8]={.000396f,.02980f,.13902f,.60820f,1,.75700f,.26500f,.01700f};
    static const float cz[8]={.06785f,1.78260f,.81295f,.13070f,.00575f,.00110f,0,0};
    float sum=0,max=0,weighted=0;
    for(unsigned i=0;i<8;i++) {
        out->basic[i]=out->raw[i]/(out->gain*out->integration_ms);
        sum+=out->basic[i];weighted+=out->basic[i]*nm[i];if(out->basic[i]>max) max=out->basic[i];
    }
    out->centroid_nm=out->red_blue_ratio=out->entropy_pct=out->flux=NAN;
    out->cie_x=out->cie_y=out->cct_k=NAN;
    if(sum<=0||max<=0) { memset(out->profile,0,sizeof(out->profile));return; }
    out->centroid_nm=weighted/sum;
    double entropy=0,flux=0,X=0,Y=0,Z=0;
    for(unsigned i=0;i<8;i++) {
        out->profile[i]=out->basic[i]/max*100;
        float p=out->basic[i]/sum;if(p>0) entropy-=p*log(p);
        float delta=out->profile[i]-previous[i];flux+=delta*delta;previous[i]=out->profile[i];
        X+=out->basic[i]*cx[i];Y+=out->basic[i]*cy[i];Z+=out->basic[i]*cz[i];
    }
    out->entropy_pct=(float)(entropy/log(8)*100);out->flux=(float)sqrt(flux/8)/100;
    float blue=out->basic[0]+out->basic[1]+out->basic[2],red=out->basic[5]+out->basic[6]+out->basic[7];
    out->red_blue_ratio=blue>0?red/blue:NAN;
    if(X+Y+Z>0&&out->entropy_pct>=85&&!(out->flags&(EC_QUALITY_LOW|EC_QUALITY_CLIPPED|EC_QUALITY_SETTLING))) {
        float x=(float)(X/(X+Y+Z)),y=(float)(Y/(X+Y+Z));
        if(x>=.25f&&x<=.55f&&y>=.25f&&y<=.45f) {
            out->cie_x=x;out->cie_y=y;
            float n=(x-.3320f)/(y-.1858f);
            float kelvin=-449*n*n*n+3525*n*n-6823.3f*n+5520.33f;
            if(kelvin>=1500&&kelvin<=15000) out->cct_k=kelvin;
        }
    }
}
static void light_task(void *arg) {
    (void)arg;i2c_master_bus_handle_t bus=NULL;
    i2c_master_bus_config_t cfg={.i2c_port=I2C_NUM_1,.sda_io_num=GPIO_NUM_8,.scl_io_num=GPIO_NUM_9,
        .clk_source=I2C_CLK_SRC_DEFAULT,.glitch_ignore_cnt=7,.flags.enable_internal_pullup=true};
    while(i2c_new_master_bus(&cfg,&bus)!=ESP_OK) {
        ESP_LOGE(TAG,"AS7341 I2C bus init failed; retrying");vTaskDelay(pdMS_TO_TICKS(5000));
    }
    ec_light_t out={0};float previous[8]={0};unsigned gain=4,time=1,low_frames=0;
    bool was_found=false;
    for(;;) {
        i2c_master_dev_handle_t dev=NULL;
        i2c_device_config_t device={.dev_addr_length=I2C_ADDR_BIT_LEN_7,.device_address=0x39,.scl_speed_hz=100000};
        uint8_t id=0;
        bool ok=i2c_master_bus_add_device(bus,&device,&dev)==ESP_OK;
        if(ok) ok=rd(dev,0x92,&id,1)==ESP_OK&&(id&0xfc)==0x24&&configure(dev,gain,time);
        if(!ok) {
            out.errors++;out.flags=EC_QUALITY_STALE;ec_update_light(&out);
            if(dev) i2c_master_bus_rm_device(dev);
            vTaskDelay(pdMS_TO_TICKS(5000));continue;
        }
        if(was_found) out.recoveries++;
        was_found=true;ESP_LOGI(TAG,"AS7341 found, two-phase complete spectra, automatic exposure");
        bool settling=true;unsigned failures=0;uint64_t last=0,last_event=0;
        for(;;) {
            uint16_t lower[6],upper[6];bool saturated=false;
            float integration=ec_light_integration_ms(time);
            ok=phase(dev,0,integration,lower,&saturated)&&phase(dev,1,integration,upper,&saturated);
            if(!ok) {
                out.errors++;out.flags=EC_QUALITY_STALE;ec_update_light(&out);
                if(++failures>=3) { ec_event("sensor_fault","AS7341 phase read failed; retrying independently",1,2);break; }
                wr(dev,0x80,1);vTaskDelay(pdMS_TO_TICKS(20));continue;
            }
            failures=0;uint64_t now=esp_timer_get_time();
            out.t_us=now;out.seq++;out.reads++;out.flags=EC_QUALITY_ESTIMATED;
            out.gain=(float)(1u<<gain);out.integration_ms=integration;
            out.actual_hz=last?1000000.0f/(now-last):NAN;last=now;
            uint16_t peak=0;
            for(unsigned i=0;i<4;i++) { out.raw[i]=lower[i];out.raw[i+4]=upper[i]; }
            out.clear_raw=upper[4];out.nir_raw=upper[5];
            for(unsigned i=0;i<6;i++) { if(lower[i]>peak) peak=lower[i];if(upper[i]>peak) peak=upper[i]; }
            out.adc_used_pct=100.0f*peak/ec_light_full_scale(time);
            out.headroom_pct=fmaxf(0,100-out.adc_used_pct);
            if(out.adc_used_pct<8||peak<=4||out.adc_used_pct>70) out.flags|=EC_QUALITY_LOW;
            if(saturated||peak>=ec_light_full_scale(time)) out.flags|=EC_QUALITY_CLIPPED;
            if(settling) out.flags|=EC_QUALITY_SETTLING;
            metrics(&out,previous);
            if(!settling&&!(out.flags&EC_QUALITY_CLIPPED)&&isfinite(out.flux)&&out.flux>.12f&&now-last_event>3000000) {
                ec_event("light_candidate","Measured spectral shape changed",.5f,2);last_event=now;
            }
            ec_update_light(&out);
            if(out.adc_used_pct<20) low_frames++;else low_frames=0;
            int action=saturated?-1:ec_exposure_action(out.adc_used_pct,low_frames);
            unsigned old_gain=gain,old_time=time;
            ec_light_exposure_step(&gain,&time,action);
            settling=gain!=old_gain||time!=old_time;
            if(settling) {
                low_frames=0;
                if(!configure(dev,gain,time)) { out.errors++;break; }
            }
            /* At minimum exposure, bound complete-frame updates near 20 Hz.
             * Larger integrations naturally lower cadence and actual_hz says so. */
            uint64_t elapsed=esp_timer_get_time()-now;
            if(integration<20&&elapsed<10000) vTaskDelay(pdMS_TO_TICKS(10));
        }
        wr(dev,0x80,1);i2c_master_bus_rm_device(dev);i2c_master_bus_reset(bus);vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
void ec_light_start(void) {
    if(xTaskCreatePinnedToCore(light_task,"ec_light",6144,NULL,7,NULL,0)!=pdPASS)
        ESP_LOGE(TAG,"Cannot create spectral light task");
}
