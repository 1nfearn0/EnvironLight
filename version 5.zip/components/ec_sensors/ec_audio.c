#include "ec_sensors.h"
#include "ec.h"
#include "ec_math.h"
#include "ec_sensor_math.h"
#include "sdkconfig.h"
#include "driver/i2s_std.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include <math.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#if CONFIG_EC_USE_ESP_DSP
#include "esp_dsp.h"
#endif

#ifndef CONFIG_EC_MIC_SPL_OFFSET
#define CONFIG_EC_MIC_SPL_OFFSET 120
#endif
#define PI 3.14159265358979323846f
#define CAPTURE_BYTES (128u*1024u)
#define ENERGY_POINTS 5800u
static const char *TAG="audio";
typedef struct { int32_t samples[EC_HOP_N]; uint64_t end_us, sample_index; uint32_t generation; } audio_block_t;
typedef struct { uint64_t end_us; float energy_a; uint32_t samples; } energy_point_t;
static QueueHandle_t blocks;
static atomic_uint capture_overruns, dsp_drops, dma_generation;
static atomic_bool audio_ready;
static uint8_t *capture_data;
static portMUX_TYPE capture_lock=portMUX_INITIALIZER_UNLOCKED;
static uint32_t capture_head,capture_tail,capture_samples,capture_target,capture_lost;
static unsigned capture_duration;
static bool capturing,capture_owned,reader_started;
static uint64_t arm_deadline_us;

/* Called with capture_lock held. An abandoned reservation records no audio. */
static void expire_arm(void) {
    if(capture_owned&&!reader_started&&(uint64_t)esp_timer_get_time()>arm_deadline_us) {
        capturing=false;capture_owned=false;capture_duration=0;
    }
}

esp_err_t ec_capture_arm(unsigned seconds) {
    if (seconds!=5&&seconds!=10&&seconds!=30) return ESP_ERR_INVALID_ARG;
    if (!capture_data||!atomic_load(&audio_ready)) return ESP_ERR_INVALID_STATE;
    esp_err_t result=ESP_OK;
    portENTER_CRITICAL(&capture_lock);
    expire_arm();
    if (capture_owned||capturing||capture_head!=capture_tail) result=ESP_ERR_INVALID_STATE;
    else {
        capture_head=capture_tail=capture_samples=capture_lost=0;
        capture_target=seconds*EC_SAMPLE_RATE;capture_duration=seconds;capturing=true;capture_owned=true;
        reader_started=false;arm_deadline_us=esp_timer_get_time()+30000000;
    }
    portEXIT_CRITICAL(&capture_lock);
    if (result==ESP_OK) ec_event("capture","Manual PCM capture armed; waiting for download",1.0f,1);
    return result;
}
bool ec_capture_active(void) {
    portENTER_CRITICAL(&capture_lock);expire_arm();bool value=capturing;portEXIT_CRITICAL(&capture_lock);return value;
}
bool ec_capture_pending(void) {
    portENTER_CRITICAL(&capture_lock);expire_arm();bool value=capture_owned;portEXIT_CRITICAL(&capture_lock);return value;
}
bool ec_capture_recording(void) {
    portENTER_CRITICAL(&capture_lock);expire_arm();bool value=capturing&&reader_started;portEXIT_CRITICAL(&capture_lock);return value;
}
unsigned ec_capture_seconds(void) {
    portENTER_CRITICAL(&capture_lock);expire_arm();unsigned value=capture_duration;portEXIT_CRITICAL(&capture_lock);return value;
}
uint32_t ec_capture_dropped(void) {
    portENTER_CRITICAL(&capture_lock);uint32_t value=capture_lost;portEXIT_CRITICAL(&capture_lock);return value;
}
void ec_capture_cancel(void) {
    portENTER_CRITICAL(&capture_lock);
    capturing=false;capture_owned=false;reader_started=false;capture_duration=0;capture_head=capture_tail=0;
    portEXIT_CRITICAL(&capture_lock);
}
size_t ec_capture_read(void *dst,size_t capacity,uint32_t timeout_ms) {
    if (!dst||capacity<4) return 0;
    capacity=(capacity>4096?4096:capacity)&~3u;
    uint64_t deadline=esp_timer_get_time()+(uint64_t)timeout_ms*1000;
    do {
        portENTER_CRITICAL(&capture_lock);
        expire_arm();
        if(capturing&&!reader_started) reader_started=true;
        size_t n=capture_head-capture_tail;
        if(n>capacity) n=capacity;
        if(n) {
            size_t offset=capture_tail%CAPTURE_BYTES, first=CAPTURE_BYTES-offset;
            if(first>n) first=n;
            memcpy(dst,capture_data+offset,first);
            if(n>first) memcpy((uint8_t*)dst+first,capture_data,n-first);
            capture_tail+=(uint32_t)n;
        }
        bool running=capturing;
        portEXIT_CRITICAL(&capture_lock);
        if(n||!running||!timeout_ms) return n;
        vTaskDelay(1);
    } while((uint64_t)esp_timer_get_time()<deadline);
    return 0;
}
static void capture_push(const int32_t *src,size_t samples) {
    portENTER_CRITICAL(&capture_lock);
    expire_arm();
    if(capturing&&reader_started) {
        size_t remain=capture_target-capture_samples;
        if(samples>remain) samples=remain;
        size_t n=samples*4;
        if(n>CAPTURE_BYTES-(capture_head-capture_tail)) {
            capture_lost+=(uint32_t)samples;capturing=false;
        } else {
            size_t off=capture_head%CAPTURE_BYTES, first=CAPTURE_BYTES-off;
            if(first>n) first=n;
            memcpy(capture_data+off,src,first);
            if(n>first) memcpy(capture_data,(const uint8_t*)src+first,n-first);
            capture_head+=(uint32_t)n;capture_samples+=(uint32_t)samples;
            if(capture_samples>=capture_target) capturing=false;
        }
    }
    portEXIT_CRITICAL(&capture_lock);
}
static void capture_gap(uint32_t samples) {
    portENTER_CRITICAL(&capture_lock);
    if(capturing) { capture_lost+=samples;capturing=false; }
    portEXIT_CRITICAL(&capture_lock);
}
static bool IRAM_ATTR on_rx_overflow(i2s_chan_handle_t channel,i2s_event_data_t *event,void *ctx) {
    (void)channel;(void)event;(void)ctx;
    atomic_fetch_add_explicit(&capture_overruns,1,memory_order_relaxed);
    atomic_fetch_add_explicit(&dma_generation,1,memory_order_relaxed);
    return false;
}
static void audio_capture_task(void *arg) {
    (void)arg;
    i2s_chan_handle_t rx=NULL;
    uint64_t sample_index=0;
    audio_block_t block;
    for(;;) {
        i2s_chan_config_t cfg=I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_AUTO,I2S_ROLE_MASTER);
        cfg.dma_desc_num=8;cfg.dma_frame_num=EC_HOP_N;
        esp_err_t err=i2s_new_channel(&cfg,NULL,&rx);
        if(err==ESP_OK) {
            i2s_std_config_t std={
                .clk_cfg=I2S_STD_CLK_DEFAULT_CONFIG(EC_SAMPLE_RATE),
                .slot_cfg=I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT,I2S_SLOT_MODE_MONO),
                .gpio_cfg={.mclk=I2S_GPIO_UNUSED,.bclk=GPIO_NUM_16,.ws=GPIO_NUM_17,
                    .dout=I2S_GPIO_UNUSED,.din=GPIO_NUM_15,.invert_flags={0}}
            };
            std.slot_cfg.slot_mask=I2S_STD_SLOT_LEFT;
            err=i2s_channel_init_std_mode(rx,&std);
        }
        if(err==ESP_OK) {
            i2s_event_callbacks_t cb={.on_recv_q_ovf=on_rx_overflow};
            err=i2s_channel_register_event_callback(rx,&cb,NULL);
        }
        if(err==ESP_OK) err=i2s_channel_enable(rx);
        if(err!=ESP_OK) {
            ESP_LOGE(TAG,"I2S init: %s; retrying",esp_err_to_name(err));
            if(rx) { i2s_del_channel(rx);rx=NULL; }
            vTaskDelay(pdMS_TO_TICKS(5000));continue;
        }
        ESP_LOGI(TAG,"ICS43434 continuous 48000 Hz, Philips I2S, left, 32-bit slots");
        atomic_store(&audio_ready,true);
        uint32_t last_generation=atomic_load(&dma_generation);
        unsigned failures=0,zero_blocks=0;
        for(;;) {
            size_t received=0;
            err=i2s_channel_read(rx,block.samples,sizeof(block.samples),&received,250);
            if(err!=ESP_OK||received!=sizeof(block.samples)) {
                capture_gap(EC_HOP_N);atomic_fetch_add(&capture_overruns,1);
                atomic_fetch_add(&dma_generation,1);
                sample_index+=EC_HOP_N;
                if(++failures>=5) break;
                continue;
            }
            failures=0;
            block.generation=atomic_load(&dma_generation);
            if(block.generation!=last_generation) { capture_gap(EC_HOP_N);last_generation=block.generation; }
            /* ICS43434 uses bits31:8. Canonicalise the otherwise unused low byte
             * so a 32-bit PCM WAV preserves exactly the useful native content. */
            bool any_signal=false;
            for(unsigned i=0;i<EC_HOP_N;i++) {
                block.samples[i]=(int32_t)((uint32_t)block.samples[i]&0xffffff00u);
                any_signal|=block.samples[i]!=0;
            }
            if(any_signal) { zero_blocks=0;atomic_store(&audio_ready,true); }
            else if(++zero_blocks>=94) {
                atomic_store(&audio_ready,false);
                if(zero_blocks==94) {
                    capture_gap(EC_HOP_N);
                    ec_event("sensor_fault","I2S contains only zero samples; check microphone wiring",1,1);
                }
            }
            block.sample_index=sample_index;sample_index+=EC_HOP_N;
            block.end_us=esp_timer_get_time();
            capture_push(block.samples,EC_HOP_N);
            if(xQueueSend(blocks,&block,0)!=pdTRUE) atomic_fetch_add(&dsp_drops,1);
        }
        atomic_store(&audio_ready,false);
        i2s_channel_disable(rx);i2s_del_channel(rx);rx=NULL;
        ec_event("sensor_fault","Microphone DMA read failed; restarting",1,1);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
static float db_power(double value) { return value>1e-12?(float)(10*log10(value)):-120.0f; }
static uint8_t quantise(float db) {
    if(db<-120) db=-120;
    if(db>0) db=0;
    return (uint8_t)lrintf((db+120)*255/120);
}
static void *psram(size_t n) { return heap_caps_calloc(1,n,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT); }

static void audio_dsp_task(void *arg) {
    (void)arg;
    float *samples=psram(EC_FFT_N*sizeof(float));
    float *real=psram(EC_FFT_N*sizeof(float)),*imag=psram(EC_FFT_N*sizeof(float));
    float *window=psram(EC_FFT_N*sizeof(float)),*powers=psram((EC_FFT_N/2+1)*sizeof(float));
    float *previous=psram((EC_FFT_N/2+1)*sizeof(float)),*scratch=psram(ENERGY_POINTS*sizeof(float));
    energy_point_t *energy=psram(ENERGY_POINTS*sizeof(*energy));
#if CONFIG_EC_USE_ESP_DSP
    float *work=heap_caps_aligned_alloc(16,2*EC_FFT_N*sizeof(float),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    bool dsp_ready=work&&dsps_fft2r_init_fc32(NULL,EC_FFT_N)==ESP_OK;
#else
    bool dsp_ready=false;
#endif
    if(!samples||!real||!imag||!window||!powers||!previous||!scratch||!energy) {
        ESP_LOGE(TAG,"DSP allocation failed; raw capture remains available");
        ec_event("sensor_fault","Audio DSP could not allocate PSRAM",1,1);
        free(samples);free(real);free(imag);free(window);free(powers);free(previous);free(scratch);free(energy);
#if CONFIG_EC_USE_ESP_DSP
        free(work);
#endif
        vTaskDelete(NULL);return;
    }
    ESP_LOGI(TAG,"FFT backend: %s",dsp_ready?"ESP-DSP":"tested reference");
    double window_sum=0;
    for(unsigned i=0;i<EC_FFT_N;i++) { window[i]=.5f-.5f*cosf(2*PI*i/EC_FFT_N);window_sum+=window[i]; }
    ec_weighting_t weighting;ec_weighting_reset(&weighting);
    ec_audio_t out={.flags=EC_QUALITY_ESTIMATED};
    out.leq_1s=out.leq_10s=out.leq_60s=out.l10=out.l50=out.l90=NAN;
    audio_block_t block;unsigned fill=0,head=0,count=0;
    uint64_t expected=0,started=0,last_publish=0,last_stats=0,last_event=0;
    uint32_t generation=0;
    uint8_t spectrum_peak[EC_BINS]={0};
    float frame_peak=-120;
    for(;;) {
        if(xQueueReceive(blocks,&block,portMAX_DELAY)!=pdTRUE) continue;
        uint64_t processing_start=esp_timer_get_time();
        if(!started) started=block.end_us;
        if(fill&&(block.sample_index!=expected||block.generation!=generation)) {
            fill=0;ec_weighting_reset(&weighting);memset(previous,0,(EC_FFT_N/2+1)*sizeof(float));
            out.flags|=EC_QUALITY_LOW;
        }
        expected=block.sample_index+EC_HOP_N;generation=block.generation;
        if(fill==EC_FFT_N) { memmove(samples,samples+EC_HOP_N,(EC_FFT_N-EC_HOP_N)*sizeof(float));fill-=EC_HOP_N; }
        double energy_a=0,energy_c=0;
        for(unsigned i=0;i<EC_HOP_N;i++) {
            float x=(float)(block.samples[i]>>8)/8388608.0f,a,c;
            samples[fill++]=x;ec_weighting_sample(&weighting,x,&a,&c);
            energy_a+=(double)a*a;energy_c+=(double)c*c;
        }
        energy[head]=(energy_point_t){block.end_us,(float)energy_a,EC_HOP_N};
        head=(head+1)%ENERGY_POINTS;if(count<ENERGY_POINTS) count++;
        out.dba_est=db_power(energy_a/EC_HOP_N)+CONFIG_EC_MIC_SPL_OFFSET;
        out.dbc_est=db_power(energy_c/EC_HOP_N)+CONFIG_EC_MIC_SPL_OFFSET;
        if(fill<EC_FFT_N) continue;
        double mean=0,sum=0;float peak=0;
        unsigned crossings=0;
        for(unsigned i=0;i<EC_FFT_N;i++) mean+=samples[i];
        mean/=EC_FFT_N;
        for(unsigned i=0;i<EC_FFT_N;i++) {
            float x=samples[i]-(float)mean;sum+=(double)x*x;
            if(fabsf(x)>peak) peak=fabsf(x);
            if(i&&((samples[i]>(float)mean)!=(samples[i-1]>(float)mean))) crossings++;
            real[i]=x*window[i];imag[i]=0;
        }
#if CONFIG_EC_USE_ESP_DSP
        if(dsp_ready) {
            for(unsigned i=0;i<EC_FFT_N;i++) { work[2*i]=real[i];work[2*i+1]=0; }
            dsps_fft2r_fc32(work,EC_FFT_N);dsps_bit_rev_fc32(work,EC_FFT_N);
            for(unsigned i=0;i<EC_FFT_N;i++) { real[i]=work[2*i];imag[i]=work[2*i+1]; }
        } else
#endif
        ec_fft(real,imag,EC_FFT_N);
        out.dbfs=db_power(sum/EC_FFT_N);out.peak_dbfs=peak>1e-6f?20*log10f(peak):-120;
        out.spl_est=out.dbfs+CONFIG_EC_MIC_SPL_OFFSET;
        if(!atomic_load(&audio_ready)) out.flags|=EC_QUALITY_STALE;
        out.crest_db=out.peak_dbfs-out.dbfs;out.zero_crossing_rate=(float)crossings/(EC_FFT_N-1);
        if(out.peak_dbfs>frame_peak) frame_peak=out.peak_dbfs;
        if(peak>=.999f) out.flags|=EC_QUALITY_CLIPPED;
        const float band_edge[9]={20,63,125,250,500,1000,2000,4000,20000};
        double total=0,weighted=0,logsum=0,flux=0;float maxpow=0;unsigned maxbin=0,nb=0;
        memset(out.bands,0,sizeof(out.bands));
        for(unsigned k=1;k<EC_FFT_N/2;k++) {
            float f=(float)k*EC_SAMPLE_RATE/EC_FFT_N;
            /* Coherent-gain amplitude normalisation: a full-scale bin-centred
             * sine is 0 dBFS, independent of the Hann window's 0.5 gain. */
            float p=4*(real[k]*real[k]+imag[k]*imag[k])/(float)(window_sum*window_sum);
            powers[k]=p;
            if(f>20000) continue;
            total+=p;weighted+=f*p;logsum+=log(fmax(p,1e-20));nb++;
            if(p>maxpow) { maxpow=p;maxbin=k; }
            float rise=sqrtf(p)-previous[k];if(rise>0) flux+=rise*rise;
            previous[k]=sqrtf(p);
            for(unsigned b=0;b<8;b++) if(f>=band_edge[b]&&f<band_edge[b+1]) { out.bands[b]+=p;break; }
            if(f>=20) {
                int b=(int)(logf(f/20)/logf(1000)*EC_BINS);
                if(b>=0&&b<EC_BINS) { uint8_t q=quantise(db_power(p));if(q>spectrum_peak[b]) spectrum_peak[b]=q; }
            }
        }
        out.centroid_hz=total>0?(float)(weighted/total):NAN;
        out.dominant_hz=maxbin?(float)maxbin*EC_SAMPLE_RATE/EC_FFT_N:NAN;
        double spread=0,cumulative=0;out.rolloff_hz=NAN;
        for(unsigned k=1;k<EC_FFT_N/2;k++) {
            float f=(float)k*EC_SAMPLE_RATE/EC_FFT_N;if(f>20000) break;
            spread+=(f-out.centroid_hz)*(f-out.centroid_hz)*powers[k];cumulative+=powers[k];
            if(!isfinite(out.rolloff_hz)&&total>0&&cumulative>=.85*total) out.rolloff_hz=f;
        }
        out.bandwidth_hz=total>0?(float)sqrt(spread/total):NAN;
        out.flatness=total>0&&nb?(float)(exp(logsum/nb)/(total/nb)):NAN;
        out.flux=(float)sqrt(flux);
        for(unsigned b=0;b<8;b++) out.bands[b]=total>0?(float)(100*out.bands[b]/total):0;
        for(unsigned b=0;b<EC_ENVELOPE;b++) {
            float lo=1,hi=-1;
            for(unsigned i=b*(EC_FFT_N/EC_ENVELOPE);i<(b+1)*(EC_FFT_N/EC_ENVELOPE);i++) {
                if(samples[i]<lo) lo=samples[i];
                if(samples[i]>hi) hi=samples[i];
            }
            out.wave_min[b]=(int16_t)lrintf(fmaxf(-1,lo)*32767);
            out.wave_max[b]=(int16_t)lrintf(fminf(1,hi)*32767);
        }
        out.processing_us=(uint32_t)(esp_timer_get_time()-processing_start);
        if(block.end_us-last_publish<50000) continue;
        double e1=0,e10=0,e60=0;uint32_t n1=0,n10=0,n60=0;size_t qn=0;
        for(unsigned i=0;i<count;i++) {
            energy_point_t *e=&energy[(head+ENERGY_POINTS-1-i)%ENERGY_POINTS];
            uint64_t age=block.end_us-e->end_us;
            if(age>=60000000) break;
            e60+=e->energy_a;n60+=e->samples;
            if(age<10000000) { e10+=e->energy_a;n10+=e->samples; }
            if(age<1000000) { e1+=e->energy_a;n1+=e->samples; }
            if(block.end_us-last_stats>=1000000) scratch[qn++]=db_power(e->energy_a/e->samples)+CONFIG_EC_MIC_SPL_OFFSET;
        }
        double span=fmin(60.0,(block.end_us-started)/1e6+EC_HOP_N/(double)EC_SAMPLE_RATE);
        out.coverage=span>0?fminf(1,(float)(n60/(span*EC_SAMPLE_RATE))):0;
        out.leq_1s=n1?db_power(e1/n1)+CONFIG_EC_MIC_SPL_OFFSET:NAN;
        out.leq_10s=n10?db_power(e10/n10)+CONFIG_EC_MIC_SPL_OFFSET:NAN;
        out.leq_60s=n60?db_power(e60/n60)+CONFIG_EC_MIC_SPL_OFFSET:NAN;
        if(block.end_us-last_stats>=1000000) {
            if(qn>=938&&out.coverage>=.9f) {
                out.l10=ec_percentile(scratch,qn,.90f);
                out.l50=ec_percentile(scratch,qn,.50f);
                out.l90=ec_percentile(scratch,qn,.10f);
            } else out.l10=out.l50=out.l90=NAN;
            last_stats=block.end_us;
        }
        if(isfinite(out.l90)&&out.dba_est>out.l90+8&&block.end_us-last_event>3000000) {
            ec_event("acoustic_candidate","Sound rose above the measured room floor",.6f,1);last_event=block.end_us;
        }
        out.t_us=block.end_us;out.seq++;
        out.capture_overruns=atomic_load(&capture_overruns);out.dsp_drops=atomic_load(&dsp_drops);
        if(out.coverage<.95f) out.flags|=EC_QUALITY_LOW;
        out.peak_dbfs=frame_peak;memcpy(out.spectrum,spectrum_peak,sizeof(spectrum_peak));
        ec_update_audio(&out);
        memset(spectrum_peak,0,sizeof(spectrum_peak));frame_peak=-120;
        out.flags=EC_QUALITY_ESTIMATED;last_publish=block.end_us;
    }
}
void ec_audio_start(void) {
    capture_data=heap_caps_malloc(CAPTURE_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    blocks=xQueueCreate(8,sizeof(audio_block_t));
    if(!blocks) { ESP_LOGE(TAG,"Cannot allocate I2S processing queue");return; }
    if(!capture_data) ESP_LOGE(TAG,"Capture PSRAM unavailable; sensing will continue");
    if(xTaskCreatePinnedToCore(audio_dsp_task,"ec_dsp",8192,NULL,10,NULL,1)!=pdPASS)
        ESP_LOGE(TAG,"Cannot create audio DSP task");
    if(xTaskCreatePinnedToCore(audio_capture_task,"ec_i2s",6144,NULL,20,NULL,1)!=pdPASS)
        ESP_LOGE(TAG,"Cannot create I2S capture task");
}
