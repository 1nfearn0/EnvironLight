#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

/* Starts the independent microphone, light, pressure and climate workers.
 * Safe to call once only; RadioScout intentionally does not call this API. */
void ec_sensors_start(void);

/* One explicitly armed, RAM-only capture. PCM is 48 kHz mono signed 32-bit LE;
 * the microphone's 24 significant bits occupy bits 31:8 (lossless alignment).
 * No samples are padded. A nonzero dropped count invalidates the capture.
 * The reader must drain while recording: the bounded ring holds ~0.68 s.
 * Arm accepts exactly 5, 10 or 30 s. Recording starts when the reader first
 * calls read(), so phone download setup cannot consume the small ring before
 * the reader exists. An unread arm expires after 30 s. Cancel releases data. */
esp_err_t ec_capture_arm(unsigned seconds);
bool ec_capture_active(void);
bool ec_capture_pending(void);
bool ec_capture_recording(void);
unsigned ec_capture_seconds(void);
size_t ec_capture_read(void *dst, size_t capacity, uint32_t timeout_ms);
void ec_capture_cancel(void);
uint32_t ec_capture_dropped(void);
