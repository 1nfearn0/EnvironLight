#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint16_t t1; int16_t t2, t3;
    uint16_t p1; int16_t p2, p3, p4, p5, p6, p7, p8, p9;
} ec_bmp_cal_t;
void ec_bmp_decode_cal(const uint8_t raw[24], ec_bmp_cal_t *out);
bool ec_bmp_compensate(const ec_bmp_cal_t *cal, int32_t adc_t, int32_t adc_p,
                       float *temperature_c, float *pressure_pa);
bool ec_dht_decode(const uint8_t raw[5], float *temperature_c, float *humidity_rh);
/* Complete exposure ladder: gain changes first; after 128x, extend integration.
 * A decrease from an extended integration shortens integration first. */
void ec_light_exposure_step(unsigned *gain_index, unsigned *time_index, int action);
#define EC_LIGHT_ATIME 29u
float ec_light_integration_ms(unsigned time_index);
uint16_t ec_light_astep(unsigned time_index);
uint32_t ec_light_full_scale(unsigned time_index);

typedef struct { double a[3][2], c[2][2]; } ec_weighting_t;
void ec_weighting_reset(ec_weighting_t *state);
void ec_weighting_sample(ec_weighting_t *state, float sample, float *a, float *c);
