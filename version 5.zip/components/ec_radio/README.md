# Native radio component

Targets ESP-IDF 5.5. Three trusted networks default to empty. Set them in
`idf.py menuconfig` or provision NVS through the authenticated network command.
With no credentials, sensors and BLE observation continue; this component never
creates an access point or captive portal. It never prints credentials or raw
radio addresses. Runtime credentials persist in NVS; enable ESP-IDF NVS/flash
encryption if the device's physical threat model requires encryption at rest.

## Build dependencies

Built-in components: `esp_wifi`, `esp_event`, `esp_netif`, `esp_timer`, `bt`,
`nvs_flash`, `mbedtls`, `lwip`, `json`, plus `ec_core`. Managed dependency:
`espressif/mdns ~1.8.2`. Set these in the app defaults:

```
CONFIG_BT_ENABLED=y
CONFIG_BT_NIMBLE_ENABLED=y
CONFIG_BT_NIMBLE_ROLE_OBSERVER=y
CONFIG_BT_NIMBLE_ROLE_CENTRAL=n
CONFIG_BT_NIMBLE_ROLE_PERIPHERAL=n
CONFIG_BT_NIMBLE_ROLE_BROADCASTER=n
CONFIG_ESP_COEX_SW_COEXIST_ENABLE=y
```

NVS must be initialized by the application before `ec_radio_start()`. The
application owns initialization and any deliberate reset of a damaged partition;
the radio component never automatically erases it. Call start once.

## API and commands

`ec_radio_start()`, `ec_wifi_connected()`, `ec_radio_json()` and
`ec_radio_command(op, body, response)` are declared in `include/ec_radio.h`.
The caller must delete returned cJSON objects. Mutating commands require the
HTTP component's administrator authentication and origin/CSRF controls.

| Operation | Body | Result |
|---|---|---|
| `network` or `provision` | `{"slot":1,"ssid":"...","password":"...","site":"..."}` | Saves one of slots 1–3; switches asynchronously. Password is never returned. |
| `scan` | `{}` | Requests a passive AP survey when stable; bounded by minimum interval and audio health. |
| `ssids` | `{"show":true}` | Explicitly enables nearby AP SSID display for this boot. |
| `enrollment` or `enroll` without `id` | `{"seconds":60}` | Marks a temporary enrolment browsing session; 0–120 seconds. |
| `enroll` | `{"id":"o...","name":"Ollie phone"}` | Explicit selection enrols a current rotating candidate during the open window. The server rejects stale or closed-window requests. |
| `rename` | `{"id":"b...","name":"New name"}` | Renames a saved record. |
| `archive` | `{"id":"b...","enabled":false}` | Retains the name, stops presence evidence; `true` re-enables. |

There is no delete command. The observation window holds at most 64 AP/BLE devices for
120 seconds; known records hold at most 24 explicitly chosen devices. Internal IDs
are domain-separated HMAC-SHA256 tokens, truncated to 64 bits and keyed per
installation. Normal responses expose only anonymous counts and coarse RSSI
bins. An authorised enrolment window briefly exposes a separate candidate token
that rotates every observation window; advertised names are returned only in
that deliberate window and service lists are not returned. Raw BLE addresses
are used transiently only to compute tokens and are never written to flash.
BLE private-address rotation can still produce a new internal ID; the
firmware does not claim to defeat that or identify a person.

Presence is device evidence: `present` ≤30 seconds, `probable` ≤120 seconds,
`away` beyond that, `unknown` after reboot until a new observation, and `archived`
when disabled. Smoothed RSSI uses an exponential average with α=0.25. Registry
names/IDs and explicit state changes survive reboot. Changed last-seen summaries
checkpoint at most every 15 minutes, and explicit registry edits save immediately;
the live last-seen value is monotonic. A power loss can therefore lose up to
15 minutes of the last-seen summary, while the retained name is unaffected.

BLE passive scanning uses 100 ms intervals / 20 ms windows (20% duty) and 10 s
scan periods. Load reduces windows to 5 ms (5% duty). Surveys pause BLE scanning.
Wi-Fi passive surveys use 120 ms channel dwell (covering the common 100 TU
beacon period), with 30 ms returns to the home channel, and run every 90 s by
default, returning the strongest
24 APs. Channel bars count this bounded AP sample, **not** airtime utilisation.
The microphone's capture-overrun and DSP-drop counters postpone surveys for
30 seconds and reduce BLE duty. Actual coexistence performance needs hardware
validation with concurrent DSP, streaming and Wi-Fi reconnects.

The output JSON includes `connected`, `ssid`, `site`, `ip`, `rssi`, `channel`,
`disconnects`, `scan_age_ms`, `ble_duty_pct`, `ble_advertisements`,
`anonymous_count`, three `anonymous_rssi_bins`, `aps`, temporary enrolment
`ble` candidates, `known`, and `channels` (14 entries, index 0 = channel 1).
Each `last_seen_ms` is **age**, not epoch time. A never-seen registry
entry reports null age/RSSI after reboot. Time zone is Europe/London, with
SNTP and automatic GMT/BST transitions; sensing does not depend on wall time.

## RadioScout limits

The same connected-observer component can run on the later WROOM RadioScout
app. `CONFIG_EC_SCOUT_METADATA` defaults off and is ignored for EnvironLight.
When deliberately enabled on RadioScout it counts management/control/data frame
types on the current channel only. The callback does not inspect, copy or retain
frame bodies, payloads or addresses. Channel-hopping, CSI and burst combined
modes are planned experiments and are not implemented or claimed validated.

## Source checks and portable test

Checked against the ESP-IDF 5.5 Wi-Fi scan, ESP-NETIF/SNTP and NimBLE APIs and
the ESP Component Registry entry for `espressif/mdns` 1.8.2. NimBLE controller/HCI
initialization is owned by `nimble_port_init()` in modern ESP-IDF, without the
removed Arduino or `esp_nimble_hci_and_controller_init()` APIs.

```
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined \
  -Icomponents/ec_radio/include tests/test_radio_registry.c \
  components/ec_radio/ec_radio_registry.c -o build-host/test-radio
./build-host/test-radio
```

The portable test exercises bounded eviction, explicit enrolment, registry-full
handling, anonymous expiration, persistent-name retention, presence age states,
RSSI smoothing and restart semantics. It does not substitute for an ESP-IDF
target compile or physical radio/coexistence validation.
