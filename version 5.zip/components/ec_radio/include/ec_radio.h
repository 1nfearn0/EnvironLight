#pragma once
#include <stdbool.h>
#include "esp_err.h"
#include "cJSON.h"

/* Start once after ec_state_init(). Empty trusted slots keep sensing offline.
 * JSON ownership transfers to caller. Commands must be protected by the web
 * component's administrator authorization and same-origin checks. */
esp_err_t ec_radio_start(void);
cJSON *ec_radio_json(void);
esp_err_t ec_radio_command(const char *op, const cJSON *body, cJSON **response);
bool ec_wifi_connected(void);
/* Accept only device-owned HTTP Host authorities (current IPv4 or mDNS name).
 * Used to stop browser DNS-rebinding origins reaching the live stream. */
bool ec_radio_host_allowed(const char *host);
