#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define EC_RADIO_ID_LEN 18
#define EC_RADIO_NAME_LEN 40
#define EC_RADIO_SERVICES_LEN 72
#define EC_RADIO_OBSERVATIONS 64
#define EC_RADIO_KNOWN 24
#define EC_RADIO_ANONYMOUS_TTL_MS 120000u

typedef struct {
    /* id is the stable installation-private token used only for matching a
     * deliberately enrolled record. public_id rotates every anonymous window
     * and is exposed only while an authorised enrolment window is open. */
    char id[EC_RADIO_ID_LEN], public_id[EC_RADIO_ID_LEN], name[EC_RADIO_NAME_LEN];
    char services[EC_RADIO_SERVICES_LEN];
    uint64_t seen_ms;
    float rssi;
    uint32_t advertisements;
    bool used;
} ec_radio_observation_t;

typedef struct {
    char id[EC_RADIO_ID_LEN], name[EC_RADIO_NAME_LEN], uuid[33];
    uint64_t seen_ms, first_epoch_s, last_epoch_s;
    float rssi;
    bool used, enabled, seen_this_boot;
} ec_radio_known_t;

typedef struct {
    ec_radio_observation_t observed[EC_RADIO_OBSERVATIONS];
    ec_radio_known_t known[EC_RADIO_KNOWN];
    uint32_t advertisements, observation_evictions;
} ec_radio_registry_t;

void ec_radio_registry_observe(ec_radio_registry_t *r, const char *id,
                               const char *name, const char *services,
                               int rssi, uint64_t now_ms, uint64_t epoch_s);
void ec_radio_registry_expire(ec_radio_registry_t *r, uint64_t now_ms);
/* 0 success, -1 observation missing, -2 registry full, -3 invalid name/id. */
int ec_radio_registry_enroll(ec_radio_registry_t *r, const char *id,
                             const char *name, const char *uuid,
                             uint64_t now_ms, uint64_t epoch_s);
ec_radio_known_t *ec_radio_registry_find(ec_radio_registry_t *r, const char *id);
const char *ec_radio_presence(const ec_radio_known_t *k, uint64_t now_ms);
size_t ec_radio_anonymous_count(const ec_radio_registry_t *r, uint64_t now_ms);
