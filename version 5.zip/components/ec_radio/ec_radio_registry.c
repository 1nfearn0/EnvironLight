#include "ec_radio_registry.h"
#include <stdio.h>
#include <string.h>

static uint64_t age_ms(uint64_t now, uint64_t then) { return now >= then ? now - then : UINT64_MAX; }
static void copy(char *to, size_t cap, const char *from) { snprintf(to, cap, "%s", from ? from : ""); }

ec_radio_known_t *ec_radio_registry_find(ec_radio_registry_t *r, const char *id)
{
    if (!r || !id) return NULL;
    for (size_t i = 0; i < EC_RADIO_KNOWN; ++i)
        if (r->known[i].used && !strcmp(r->known[i].id, id)) return &r->known[i];
    return NULL;
}

void ec_radio_registry_expire(ec_radio_registry_t *r, uint64_t now_ms)
{
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i)
        if (r->observed[i].used && age_ms(now_ms, r->observed[i].seen_ms) > EC_RADIO_ANONYMOUS_TTL_MS)
            memset(&r->observed[i], 0, sizeof(r->observed[i]));
}

void ec_radio_registry_observe(ec_radio_registry_t *r, const char *id,
                               const char *name, const char *services,
                               int rssi, uint64_t now_ms, uint64_t epoch_s)
{
    if (!r || !id || !*id || strlen(id) >= EC_RADIO_ID_LEN) return;
    ++r->advertisements;
    ec_radio_known_t *known = ec_radio_registry_find(r, id);
    if (known && known->enabled) {
        known->rssi = known->seen_this_boot ? known->rssi * .75f + rssi * .25f : (float)rssi;
        known->seen_ms = now_ms;
        known->seen_this_boot = true;
        if (epoch_s) known->last_epoch_s = epoch_s;
    }
    ec_radio_observation_t *slot = NULL, *oldest = &r->observed[0];
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i) {
        ec_radio_observation_t *o = &r->observed[i];
        if (o->used && !strcmp(o->id, id)) { slot = o; break; }
        if (!o->used && !slot) slot = o;
        if (o->seen_ms < oldest->seen_ms) oldest = o;
    }
    if (!slot) { slot = oldest; ++r->observation_evictions; }
    bool existing = slot->used && !strcmp(slot->id, id);
    if (!existing) memset(slot, 0, sizeof(*slot));
    copy(slot->id, sizeof(slot->id), id);
    if (name && *name) copy(slot->name, sizeof(slot->name), name);
    if (services && *services) copy(slot->services, sizeof(slot->services), services);
    slot->rssi = existing ? slot->rssi * .75f + rssi * .25f : (float)rssi;
    slot->seen_ms = now_ms;
    slot->used = true;
    ++slot->advertisements;
}

int ec_radio_registry_enroll(ec_radio_registry_t *r, const char *id,
                             const char *name, const char *uuid,
                             uint64_t now_ms, uint64_t epoch_s)
{
    if (!r || !id || !*id || strlen(id) >= EC_RADIO_ID_LEN || !name || !*name || strlen(name) >= EC_RADIO_NAME_LEN)
        return -3;
    ec_radio_observation_t *o = NULL;
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i)
        if (r->observed[i].used && !strcmp(r->observed[i].id, id) &&
            age_ms(now_ms, r->observed[i].seen_ms) <= EC_RADIO_ANONYMOUS_TTL_MS) { o = &r->observed[i]; break; }
    if (!o) return -1;
    ec_radio_known_t *k = ec_radio_registry_find(r, id);
    if (!k) for (size_t i = 0; i < EC_RADIO_KNOWN; ++i) if (!r->known[i].used) { k = &r->known[i]; break; }
    if (!k) return -2;
    if (!k->used) {
        memset(k, 0, sizeof(*k));
        copy(k->uuid, sizeof(k->uuid), uuid);
        k->first_epoch_s = epoch_s;
    }
    copy(k->id, sizeof(k->id), id);
    copy(k->name, sizeof(k->name), name);
    k->seen_ms = o->seen_ms;
    k->rssi = o->rssi;
    k->last_epoch_s = epoch_s;
    k->used = k->enabled = k->seen_this_boot = true;
    return 0;
}

const char *ec_radio_presence(const ec_radio_known_t *k, uint64_t now_ms)
{
    if (!k->enabled) return "archived";
    if (!k->seen_this_boot) return "unknown";
    uint64_t age = age_ms(now_ms, k->seen_ms);
    if (age <= 30000) return "present";
    if (age <= 120000) return "probable";
    return "away";
}

size_t ec_radio_anonymous_count(const ec_radio_registry_t *r, uint64_t now_ms)
{
    size_t n = 0;
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i) {
        const ec_radio_observation_t *o = &r->observed[i];
        if (!o->used || o->id[0] != 'b' || age_ms(now_ms, o->seen_ms) > EC_RADIO_ANONYMOUS_TTL_MS) continue;
        bool known = false;
        for (size_t j = 0; j < EC_RADIO_KNOWN; ++j)
            if (r->known[j].used && !strcmp(r->known[j].id, o->id)) { known = true; break; }
        if (!known) ++n;
    }
    return n;
}
