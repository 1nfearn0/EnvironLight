/* Native ESP-IDF 5.5 observer. Driver callbacks only copy bounded metadata to
 * queues; the low-priority worker owns crypto, NVS, surveys and reconnection. */
#include "ec_radio.h"
#include "ec_radio_registry.h"
#include "ec.h"
#include "sdkconfig.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_netif_sntp.h"
#include "esp_random.h"
#include "esp_wifi.h"
#include "nvs.h"
#include "mdns.h"
#include "mbedtls/md.h"
#if CONFIG_BT_NIMBLE_ENABLED && CONFIG_BT_NIMBLE_ROLE_OBSERVER
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/util/util.h"
#endif

#define AP_CAP 24
#define WIFI_SLOTS 3
#define BLE_QUEUE_CAP 48
#define RADIO_QUEUE_CAP 12
#define MS() (ec_now_us() / 1000ULL)
static const char *TAG = "ec_radio";

typedef struct { char ssid[33], password[65], site[32]; } trusted_t;
typedef struct { char id[EC_RADIO_ID_LEN], ssid[33]; int rssi, channel, auth; } ap_t;
typedef struct {
    uint8_t addr[6], addr_type, length;
    int8_t rssi;
    uint8_t data[31];
    uint64_t at_ms;
} advertisement_t;
typedef enum { R_STARTED, R_DISCONNECTED, R_GOT_IP, R_SCAN_DONE, R_BLE_DONE, R_PROVISIONED } radio_event_type_t;
typedef struct { radio_event_type_t type; int reason; uint32_t ip; } radio_event_t;
typedef struct {
    ec_radio_registry_t registry;
    trusted_t trusted[WIFI_SLOTS];
    ap_t aps[AP_CAP];
    size_t ap_count;
    unsigned channel_counts[14];
    int slot, rssi, channel, reason;
    char ssid[33], site[32], ip[16], bssid[EC_RADIO_ID_LEN];
    bool connected, connecting, survey_active, ble_ready, ble_scanning;
    bool throttle, show_ssids, registry_dirty;
    uint32_t disconnects, scan_errors, ble_errors, retries, ble_advertisements;
    uint64_t scan_ms, survey_started_ms, connect_deadline_ms, reconnect_ms, next_scan_ms, quiet_until_ms;
    uint64_t enrollment_until_ms;
    unsigned ble_duty;
    esp_err_t ble_init_error;
} radio_state_t;

static radio_state_t s;
static SemaphoreHandle_t lock;
static QueueHandle_t radio_queue, ble_queue;
static esp_netif_t *sta;
static uint8_t local_key[32];
static bool initialized, mdns_ready, sntp_started;
static volatile uint32_t ble_queue_drops, radio_queue_drops;
#if CONFIG_EC_SCOUT_METADATA
static volatile uint32_t metadata_frames[4];
static bool metadata_active;
#endif

static void str_copy(char *to, size_t n, const char *from) { snprintf(to, n, "%s", from ? from : ""); }
static uint64_t epoch(void) { time_t t = time(NULL); return t > 1700000000 ? (uint64_t)t : 0; }
static void post(radio_event_type_t type, int reason, uint32_t ip)
{
    radio_event_t e = { .type = type, .reason = reason, .ip = ip };
    if (xQueueSend(radio_queue, &e, 0) != pdTRUE) ++radio_queue_drops;
}

static void token(char prefix, const uint8_t *bytes, size_t n, char out[EC_RADIO_ID_LEN])
{
    /* Domains separate BLE addresses from AP BSSIDs. No raw addresses leave
     * this component. A generated key is persisted once per installation. */
    uint8_t input[16] = { (uint8_t)prefix }, digest[32];
    if (n > sizeof(input) - 1) n = sizeof(input) - 1;
    memcpy(input + 1, bytes, n);
    int rc = mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),
                             local_key, sizeof(local_key), input, n + 1, digest);
    if (rc != 0) { out[0] = 0; return; }
    out[0] = prefix;
    for (unsigned i = 0; i < 8; ++i) snprintf(out + 1 + i * 2, 3, "%02x", digest[i]);
    out[17] = 0;
}

static ec_radio_observation_t *observation_by_id(const char *id, bool public_id)
{
    if (!id) return NULL;
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i) {
        ec_radio_observation_t *o = &s.registry.observed[i];
        const char *candidate = public_id ? o->public_id : o->id;
        if (o->used && !strcmp(candidate, id)) return o;
    }
    return NULL;
}

static void anonymous_token(const advertisement_t *a, char out[EC_RADIO_ID_LEN])
{
    uint8_t input[15];
    memcpy(input, a->addr, 6);
    input[6] = a->addr_type;
    uint64_t window = a->at_ms / EC_RADIO_ANONYMOUS_TTL_MS;
    for (unsigned i = 0; i < 8; ++i) input[7 + i] = (uint8_t)(window >> (i * 8));
    token('o', input, sizeof(input), out);
}

/* Use a versioned compact JSON blob for portability across compiler/IDF builds.
 * Only explicitly enrolled records persist; anonymous observations never do. */
static esp_err_t save_registry(void)
{
    cJSON *a = cJSON_CreateArray();
    if (!a) return ESP_ERR_NO_MEM;
    for (size_t i = 0; i < EC_RADIO_KNOWN; ++i) {
        const ec_radio_known_t *k = &s.registry.known[i];
        if (!k->used) continue;
        cJSON *o = cJSON_CreateObject();
        if (!o) { cJSON_Delete(a); return ESP_ERR_NO_MEM; }
        cJSON_AddStringToObject(o, "id", k->id);
        cJSON_AddStringToObject(o, "uuid", k->uuid);
        cJSON_AddStringToObject(o, "name", k->name);
        cJSON_AddBoolToObject(o, "enabled", k->enabled);
        cJSON_AddNumberToObject(o, "first", (double)k->first_epoch_s);
        cJSON_AddNumberToObject(o, "last", (double)k->last_epoch_s);
        cJSON_AddItemToArray(a, o);
    }
    char *json = cJSON_PrintUnformatted(a);
    cJSON_Delete(a);
    if (!json) return ESP_ERR_NO_MEM;
    nvs_handle_t h;
    esp_err_t e = nvs_open("ec_radio", NVS_READWRITE, &h);
    if (e == ESP_OK) {
        e = nvs_set_str(h, "registry_v1", json);
        if (e == ESP_OK) e = nvs_commit(h);
        nvs_close(h);
    }
    free(json);
    if (e == ESP_OK) s.registry_dirty = false;
    return e;
}

static const char *json_string(const cJSON *o, const char *name)
{
    const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, name);
    return cJSON_IsString(v) ? v->valuestring : NULL;
}

static void load_config(void)
{
    const trusted_t defaults[WIFI_SLOTS] = {
        { CONFIG_EC_WIFI_SSID_1, CONFIG_EC_WIFI_PASSWORD_1, CONFIG_EC_WIFI_SITE_1 },
        { CONFIG_EC_WIFI_SSID_2, CONFIG_EC_WIFI_PASSWORD_2, CONFIG_EC_WIFI_SITE_2 },
        { CONFIG_EC_WIFI_SSID_3, CONFIG_EC_WIFI_PASSWORD_3, CONFIG_EC_WIFI_SITE_3 }
    };
    memcpy(s.trusted, defaults, sizeof(defaults));
    nvs_handle_t h;
    esp_err_t err = nvs_open("ec_radio", NVS_READWRITE, &h);
    if (err != ESP_OK) return;
    size_t key_size = sizeof(local_key);
    err = nvs_get_blob(h, "identity_key", local_key, &key_size);
    if (err != ESP_OK || key_size != sizeof(local_key)) {
        esp_fill_random(local_key, sizeof(local_key));
        err = nvs_set_blob(h, "identity_key", local_key, sizeof(local_key));
        if (err == ESP_OK) err = nvs_commit(h);
        if (err != ESP_OK) ESP_LOGW(TAG, "Pseudonym key persistence unavailable; identifiers will change on restart");
    }
    for (int i = 0; i < WIFI_SLOTS; ++i) {
        char k[12];
        snprintf(k, sizeof(k), "wifi%d", i);
        size_t len = 0;
        if (nvs_get_str(h, k, NULL, &len) != ESP_OK || len > 512 || !len) continue;
        char *b = malloc(len);
        if (!b) continue;
        if (nvs_get_str(h, k, b, &len) == ESP_OK) {
            cJSON *o = cJSON_Parse(b);
            if (o) {
                const char *v = json_string(o, "ssid");
                if (v && strlen(v) <= 32) {
                    str_copy(s.trusted[i].ssid, sizeof(s.trusted[i].ssid), v);
                    str_copy(s.trusted[i].password, sizeof(s.trusted[i].password), json_string(o, "password"));
                    str_copy(s.trusted[i].site, sizeof(s.trusted[i].site), json_string(o, "site"));
                }
                cJSON_Delete(o);
            }
        }
        memset(b, 0, len);
        free(b);
    }
    size_t len = 0;
    if (nvs_get_str(h, "registry_v1", NULL, &len) == ESP_OK && len && len <= 16384) {
        char *b = malloc(len);
        if (b && nvs_get_str(h, "registry_v1", b, &len) == ESP_OK) {
            cJSON *a = cJSON_Parse(b), *o;
            size_t i = 0;
            cJSON_ArrayForEach(o, a) {
                if (i >= EC_RADIO_KNOWN) break;
                const char *id = json_string(o, "id"), *name = json_string(o, "name");
                if (!id || strlen(id) != EC_RADIO_ID_LEN - 1 || !name || !*name || strlen(name) >= EC_RADIO_NAME_LEN) continue;
                ec_radio_known_t *k = &s.registry.known[i++];
                str_copy(k->id, sizeof(k->id), id);
                str_copy(k->name, sizeof(k->name), name);
                str_copy(k->uuid, sizeof(k->uuid), json_string(o, "uuid"));
                k->enabled = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(o, "enabled"));
                const cJSON *first = cJSON_GetObjectItemCaseSensitive(o, "first");
                const cJSON *last = cJSON_GetObjectItemCaseSensitive(o, "last");
                k->first_epoch_s = cJSON_IsNumber(first) && first->valuedouble > 0 ? (uint64_t)first->valuedouble : 0;
                k->last_epoch_s = cJSON_IsNumber(last) && last->valuedouble > 0 ? (uint64_t)last->valuedouble : 0;
                k->used = true;
            }
            cJSON_Delete(a);
        }
        free(b);
    }
    nvs_close(h);
}

static void wifi_event(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) post(R_STARTED, 0, 0);
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        const wifi_event_sta_disconnected_t *d = data;
        post(R_DISCONNECTED, d->reason, 0);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_SCAN_DONE) post(R_SCAN_DONE, 0, 0);
    else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        const ip_event_got_ip_t *d = data;
        post(R_GOT_IP, 0, d->ip_info.ip.addr);
    }
}

static int next_slot(int after)
{
    for (int n = 1; n <= WIFI_SLOTS; ++n) {
        int i = (after + n) % WIFI_SLOTS;
        if (s.trusted[i].ssid[0]) return i;
    }
    return -1;
}

static void connect_locked(uint64_t now)
{
    if (s.slot < 0 || !s.trusted[s.slot].ssid[0]) s.slot = next_slot(-1);
    if (s.slot < 0) { s.reconnect_ms = now + 30000; return; }
    wifi_config_t cfg = {0};
    memcpy(cfg.sta.ssid, s.trusted[s.slot].ssid, strlen(s.trusted[s.slot].ssid));
    memcpy(cfg.sta.password, s.trusted[s.slot].password, strlen(s.trusted[s.slot].password));
    cfg.sta.threshold.authmode = WIFI_AUTH_OPEN;
    cfg.sta.pmf_cfg.capable = true;
    cfg.sta.pmf_cfg.required = false;
    cfg.sta.scan_method = WIFI_ALL_CHANNEL_SCAN;
    cfg.sta.sort_method = WIFI_CONNECT_AP_BY_SIGNAL;
    esp_err_t err = esp_wifi_set_config(WIFI_IF_STA, &cfg);
    memset(&cfg, 0, sizeof(cfg));
    if (err == ESP_OK) err = esp_wifi_connect();
    s.connecting = err == ESP_OK;
    s.connect_deadline_ms = now + 20000;
    s.reconnect_ms = now + 30000;
    if (err != ESP_OK) ++s.retries;
}

#if CONFIG_BT_NIMBLE_ENABLED && CONFIG_BT_NIMBLE_ROLE_OBSERVER
static uint8_t own_addr_type;
static int ble_event(struct ble_gap_event *event, void *arg)
{
    (void)arg;
    if (event->type == BLE_GAP_EVENT_DISC) {
        const struct ble_gap_disc_desc *d = &event->disc;
        advertisement_t a = { .rssi = d->rssi, .addr_type = d->addr.type, .at_ms = MS() };
        memcpy(a.addr, d->addr.val, sizeof(a.addr));
        a.length = d->length_data < sizeof(a.data) ? d->length_data : sizeof(a.data);
        memcpy(a.data, d->data, a.length);
        if (xQueueSend(ble_queue, &a, 0) != pdTRUE) ++ble_queue_drops;
    } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) post(R_BLE_DONE, event->disc_complete.reason, 0);
    return 0;
}
static void ble_sync(void)
{
    int rc = ble_hs_util_ensure_addr(0);
    if (rc == 0) rc = ble_hs_id_infer_auto(0, &own_addr_type);
    if (rc == 0) {
        /* This callback only signals; scanning starts in the worker. */
        post(R_BLE_DONE, 0, 0);
    }
}
static void ble_reset(int reason) { post(R_BLE_DONE, reason, 0); }
static void ble_host(void *arg) { (void)arg; nimble_port_run(); nimble_port_freertos_deinit(); }
static bool ble_start_scan(unsigned duty)
{
    if (!ble_hs_synced()) return false;
    struct ble_gap_disc_params p = {0};
    p.passive = 1;
    p.itvl = 160;                       /* 100 ms, units of 0.625 ms */
    p.window = duty >= 20 ? 32 : 8;     /* 20% normal; 5% under load */
    p.filter_duplicates = 0;            /* Report rate honestly; queue is bounded. */
    p.limited = 0;
    int rc = ble_gap_disc(own_addr_type, 10000, &p, ble_event, NULL);
    return rc == 0 || rc == BLE_HS_EALREADY;
}
static void ble_stop_scan(void) { if (ble_gap_disc_active()) (void)ble_gap_disc_cancel(); }
#else
static bool ble_start_scan(unsigned duty) { (void)duty; return false; }
static void ble_stop_scan(void) { }
#endif

static void parse_advertisement(const advertisement_t *a, char *name, size_t nn, char *services, size_t ns)
{
    name[0] = services[0] = 0;
    size_t used = 0;
    for (size_t p = 0; p < a->length;) {
        uint8_t length = a->data[p++];
        if (!length || p + length > a->length) break;
        uint8_t type = a->data[p];
        const uint8_t *value = &a->data[p + 1];
        size_t n = length - 1;
        if ((type == 0x08 || type == 0x09) && n) {
            size_t m = n < nn - 1 ? n : nn - 1;
            for (size_t j = 0; j < m; ++j) name[j] = value[j] >= 32 && value[j] <= 126 ? (char)value[j] : '?';
            name[m] = 0;
        } else if (type == 0x02 || type == 0x03) {
            for (size_t j = 0; j + 1 < n && used + 6 < ns; j += 2)
                used += (size_t)snprintf(services + used, ns - used, "%s%04x", used ? "," : "", value[j] | ((unsigned)value[j + 1] << 8));
        }
        p += length;
    }
}

static void collect_scan_locked(uint64_t now)
{
    wifi_ap_record_t records[AP_CAP];
    uint16_t n = AP_CAP;
    esp_err_t e = esp_wifi_scan_get_ap_records(&n, records);
    s.survey_active = false;
    if (e != ESP_OK) { ++s.scan_errors; esp_wifi_clear_ap_list(); return; }
    s.ap_count = n;
    memset(s.channel_counts, 0, sizeof(s.channel_counts));
    for (size_t i = 0; i < n; ++i) {
        ap_t *a = &s.aps[i];
        memset(a, 0, sizeof(*a));
        token('a', records[i].bssid, 6, a->id);
        memcpy(a->ssid, records[i].ssid, sizeof(records[i].ssid));
        a->ssid[32] = 0;
        a->rssi = records[i].rssi;
        a->channel = records[i].primary;
        a->auth = records[i].authmode;
        if (a->channel >= 1 && a->channel <= 14) ++s.channel_counts[a->channel - 1];
        /* APs can also be explicitly named. The registry source follows the
         * domain prefix; AP observations do not count as BLE density. */
        ec_radio_registry_observe(&s.registry, a->id, "", "wifi_ap", a->rssi, now, epoch());
        const ec_radio_known_t *known = ec_radio_registry_find(&s.registry, a->id);
        if (known && known->enabled) s.registry_dirty = true;
    }
    s.scan_ms = now;
    /* get_ap_records releases the entire driver's scan list, including entries
     * beyond our top 24. Channel counts are explicitly a bounded sample. */
}

#if CONFIG_EC_SCOUT_METADATA
static void metadata_callback(void *buffer, wifi_promiscuous_pkt_type_t type)
{
    (void)buffer;
    if ((unsigned)type < 4) ++metadata_frames[(unsigned)type];
}
#endif

static void got_ip_locked(uint32_t ip, uint64_t now)
{
    s.connected = true;
    s.connecting = false;
    s.retries = 0;
    esp_ip4_addr_t addr = { .addr = ip };
    snprintf(s.ip, sizeof(s.ip), IPSTR, IP2STR(&addr));
    str_copy(s.ssid, sizeof(s.ssid), s.slot >= 0 ? s.trusted[s.slot].ssid : "");
    str_copy(s.site, sizeof(s.site), s.slot >= 0 ? s.trusted[s.slot].site : "");
    s.next_scan_ms = now + 15000;
    if (!mdns_ready && mdns_init() == ESP_OK) {
        mdns_ready = true;
        mdns_hostname_set(ec_hostname());
        mdns_instance_name_set(ec_device_name());
        mdns_service_add(NULL, "_http", "_tcp", 80, NULL, 0);
    }
    if (!sntp_started) {
        esp_sntp_config_t cfg = ESP_NETIF_SNTP_DEFAULT_CONFIG("pool.ntp.org");
        if (esp_netif_sntp_init(&cfg) == ESP_OK) sntp_started = true;
    }
    ec_event("network", "Trusted Wi-Fi connected", 1, 0);
}

static void radio_worker(void *arg)
{
    (void)arg;
    uint32_t last_overruns = 0, last_drops = 0;
    uint64_t last_link_ms = 0, last_registry_save_ms = 0;
    uint32_t present_mask = 0;
    for (;;) {
        uint64_t now = MS();
        ec_snapshot_t snapshot;
        ec_get_snapshot(&snapshot);
        xSemaphoreTake(lock, portMAX_DELAY);
        if (snapshot.audio.capture_overruns != last_overruns || snapshot.audio.dsp_drops != last_drops) {
            s.quiet_until_ms = now + 30000;
            last_overruns = snapshot.audio.capture_overruns;
            last_drops = snapshot.audio.dsp_drops;
        }
        s.throttle = now < s.quiet_until_ms;
        radio_event_t e;
        while (xQueueReceive(radio_queue, &e, 0) == pdTRUE) {
            if (e.type == R_STARTED) s.reconnect_ms = now;
            else if (e.type == R_GOT_IP) got_ip_locked(e.ip, now);
            else if (e.type == R_DISCONNECTED) {
                bool was_connected = s.connected;
                s.connected = s.connecting = false;
                s.ip[0] = 0;
                s.reason = e.reason;
                ++s.disconnects;
                ++s.retries;
                if (s.retries % 3 == 0) s.slot = next_slot(s.slot);
                unsigned exponent = s.retries > 5 ? 5 : s.retries;
                s.reconnect_ms = now + (1000ULL << exponent) + (esp_random() % 300);
                s.quiet_until_ms = now + 30000;
                if (was_connected) ec_event("network", "Wi-Fi disconnected; autonomous reconnect active", 1, 0);
            } else if (e.type == R_SCAN_DONE) collect_scan_locked(now);
            else if (e.type == R_BLE_DONE) { s.ble_scanning = false; if (e.reason) ++s.ble_errors; }
            else if (e.type == R_PROVISIONED) {
                bool had_link = s.connected || s.connecting;
                s.slot = e.reason;
                s.retries = 0;
                s.reconnect_ms = now + 1000;
                s.connected = s.connecting = false;
                s.ip[0] = 0;
                if (s.survey_active) { esp_wifi_scan_stop(); s.survey_active = false; }
                if (had_link) esp_wifi_disconnect();
            }
        }
        advertisement_t a;
        for (unsigned n = 0; n < BLE_QUEUE_CAP && xQueueReceive(ble_queue, &a, 0) == pdTRUE; ++n) {
            uint8_t id_bytes[7];
            memcpy(id_bytes, a.addr, 6);
            id_bytes[6] = a.addr_type;
            char id[EC_RADIO_ID_LEN], public_id[EC_RADIO_ID_LEN], name[EC_RADIO_NAME_LEN], services[EC_RADIO_SERVICES_LEN];
            token('b', id_bytes, sizeof(id_bytes), id);
            anonymous_token(&a, public_id);
            parse_advertisement(&a, name, sizeof(name), services, sizeof(services));
            ++s.ble_advertisements;
            ec_radio_known_t *known = ec_radio_registry_find(&s.registry, id);
            bool arrival = known && known->enabled && (!known->seen_this_boot || now - known->seen_ms > 120000);
            ec_radio_registry_observe(&s.registry, id, name, services, a.rssi, a.at_ms, epoch());
            ec_radio_observation_t *observation = observation_by_id(id, false);
            if (observation) str_copy(observation->public_id, sizeof(observation->public_id), public_id);
            if (known && known->enabled) s.registry_dirty = true;
            if (arrival) {
                char label[80]; snprintf(label, sizeof(label), "%s: device advertisement observed", known->name);
                ec_event("radio", label, .8f, 8);
            }
        }
        ec_radio_registry_expire(&s.registry, now);
        for (unsigned i = 0; i < EC_RADIO_KNOWN; ++i) {
            const ec_radio_known_t *k = &s.registry.known[i];
            bool present = k->used && k->enabled && k->seen_this_boot && now - k->seen_ms <= 120000;
            if (!present && k->used && k->enabled && (present_mask & (1u << i))) {
                char label[80]; snprintf(label, sizeof(label), "%.30s: device evidence expired; absence uncertain", k->name);
                ec_event("radio", label, .5f, 8);
            }
            if (present) present_mask |= 1u << i; else present_mask &= ~(1u << i);
        }
        if (s.registry_dirty && now - last_registry_save_ms >= 900000) {
            (void)save_registry();
            last_registry_save_ms = now;
        }
        if (s.survey_active && now - s.survey_started_ms > 5000) {
            esp_wifi_scan_stop();
            esp_wifi_clear_ap_list();
            s.survey_active = false;
            ++s.scan_errors;
        }
        if (s.connecting && now > s.connect_deadline_ms) {
            s.connecting = false;
            esp_wifi_disconnect();
            s.reconnect_ms = now + 2000;
            ++s.retries;
            s.slot = next_slot(s.slot);
        }
        if (!s.connected && !s.connecting && !s.survey_active && now >= s.reconnect_ms) connect_locked(now);
        if (s.connected && now - last_link_ms > 5000) {
            wifi_ap_record_t ap;
            if (esp_wifi_sta_get_ap_info(&ap) == ESP_OK) {
                s.rssi = ap.rssi; s.channel = ap.primary;
                token('a', ap.bssid, 6, s.bssid);
            }
            last_link_ms = now;
        }
        if (s.connected && !s.connecting && !s.survey_active && !s.throttle && now >= s.next_scan_ms) {
            ble_stop_scan(); s.ble_scanning = false;
            wifi_scan_config_t cfg = {0};
            cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
            cfg.scan_time.passive = 120; /* Covers the common 100 TU beacon period. */
            cfg.home_chan_dwell_time = 30;
            cfg.coex_background_scan = true;
            esp_err_t err = esp_wifi_scan_start(&cfg, false);
            if (err == ESP_OK) { s.survey_active = true; s.survey_started_ms = now; }
            else ++s.scan_errors;
            s.next_scan_ms = now + (uint64_t)CONFIG_EC_RADIO_SURVEY_INTERVAL_S * 1000;
        }
        unsigned duty = s.throttle ? 5 : 20;
        if (s.ble_scanning && (s.survey_active || duty != s.ble_duty)) {
            ble_stop_scan(); s.ble_scanning = false;
        }
        if (s.ble_ready && !s.ble_scanning && !s.survey_active) {
            s.ble_scanning = ble_start_scan(duty);
            s.ble_duty = s.ble_scanning ? duty : 0;
        } else if (s.survey_active) s.ble_duty = 0;
        xSemaphoreGive(lock);
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

esp_err_t ec_radio_start(void)
{
    if (initialized) return ESP_OK;
    memset(&s, 0, sizeof(s));
    s.slot = -1;
#ifdef CONFIG_EC_RADIO_SHOW_SSIDS
    s.show_ssids = true;
#endif
    esp_fill_random(local_key, sizeof(local_key));
    load_config();
    lock = xSemaphoreCreateMutex();
    radio_queue = xQueueCreate(RADIO_QUEUE_CAP, sizeof(radio_event_t));
    ble_queue = xQueueCreate(BLE_QUEUE_CAP, sizeof(advertisement_t));
    if (!lock || !radio_queue || !ble_queue) return ESP_ERR_NO_MEM;
    esp_err_t err = esp_netif_init();
    if (err != ESP_OK) return err;
    err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) return err;
    sta = esp_netif_create_default_wifi_sta();
    if (!sta) return ESP_ERR_NO_MEM;
    esp_netif_set_hostname(sta, ec_hostname());
    wifi_init_config_t init = WIFI_INIT_CONFIG_DEFAULT();
    err = esp_wifi_init(&init);
    if (err != ESP_OK) return err;
    esp_wifi_set_storage(WIFI_STORAGE_RAM);
    esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_event, NULL);
    esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_event, NULL);
    esp_wifi_set_mode(WIFI_MODE_STA);
    wifi_country_t uk = { .cc = "GB", .schan = 1, .nchan = 13, .policy = WIFI_COUNTRY_POLICY_AUTO };
    esp_wifi_set_country(&uk);
    setenv("TZ", "GMT0BST,M3.5.0/1,M10.5.0", 1);
    tzset();
#if CONFIG_BT_NIMBLE_ENABLED && CONFIG_BT_NIMBLE_ROLE_OBSERVER
    s.ble_init_error = nimble_port_init();
    if (s.ble_init_error == ESP_OK) {
        ble_hs_cfg.sync_cb = ble_sync;
        ble_hs_cfg.reset_cb = ble_reset;
        s.ble_ready = true;
        nimble_port_freertos_init(ble_host);
    } else ESP_LOGW(TAG, "BLE observer unavailable: %s", esp_err_to_name(s.ble_init_error));
#else
    s.ble_init_error = ESP_ERR_NOT_SUPPORTED;
#endif
    err = esp_wifi_start();
    if (err != ESP_OK) return err;
    /* Driver buffers stay in internal RAM. No modem sleep avoids bursty latency
     * on the live LAN telemetry; BLE still shares the same physical radio. */
    esp_wifi_set_ps(WIFI_PS_NONE);
#if CONFIG_EC_SCOUT_METADATA
    if (ec_is_scout()) {
        wifi_promiscuous_filter_t filter = { .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_CTRL | WIFI_PROMIS_FILTER_MASK_DATA };
        esp_wifi_set_promiscuous_filter(&filter);
        esp_wifi_set_promiscuous_rx_cb(metadata_callback);
        metadata_active = esp_wifi_set_promiscuous(true) == ESP_OK;
    }
#endif
    initialized = true;
    if (xTaskCreate(radio_worker, "ec_radio", 8192, NULL, 3, NULL) != pdPASS) { initialized = false; return ESP_ERR_NO_MEM; }
    ESP_LOGI(TAG, "Native station and passive observer started; no access point or credentials logged");
    return ESP_OK;
}

bool ec_wifi_connected(void)
{
    if (!initialized || !lock) return false;
    if (xSemaphoreTake(lock, pdMS_TO_TICKS(20)) != pdTRUE) return false;
    bool connected = s.connected;
    xSemaphoreGive(lock);
    return connected;
}

bool ec_radio_host_allowed(const char *host)
{
    if (!host || !*host || strlen(host) >= 96) return false;
    char authority[96], mdns[80], mdns_dot[81];
    str_copy(authority, sizeof(authority), host);
    char *port = strrchr(authority, ':');
    if (port) *port = 0; /* EnvironCore currently serves IPv4 only. */
    snprintf(mdns, sizeof(mdns), "%s.local", ec_hostname());
    snprintf(mdns_dot, sizeof(mdns_dot), "%s.", mdns);
    if (!strcasecmp(authority, ec_hostname()) || !strcasecmp(authority, mdns) || !strcasecmp(authority, mdns_dot)) return true;
    if (!initialized || !lock || xSemaphoreTake(lock, pdMS_TO_TICKS(20)) != pdTRUE) return false;
    bool allowed = s.ip[0] && !strcmp(authority, s.ip);
    xSemaphoreGive(lock);
    return allowed;
}

static const char *auth_name(int auth)
{
    switch (auth) {
    case WIFI_AUTH_OPEN: return "open";
    case WIFI_AUTH_WEP: return "WEP";
    case WIFI_AUTH_WPA_PSK: return "WPA";
    case WIFI_AUTH_WPA2_PSK: return "WPA2";
    case WIFI_AUTH_WPA_WPA2_PSK: return "WPA/WPA2";
    case WIFI_AUTH_WPA2_ENTERPRISE: return "enterprise";
    case WIFI_AUTH_WPA3_PSK: return "WPA3";
    case WIFI_AUTH_WPA2_WPA3_PSK: return "WPA2/WPA3";
    default: return "other";
    }
}

cJSON *ec_radio_json(void)
{
    cJSON *root = cJSON_CreateObject();
    if (!root) return NULL;
    if (!initialized || xSemaphoreTake(lock, pdMS_TO_TICKS(100)) != pdTRUE) {
        cJSON_AddBoolToObject(root, "connected", false);
        cJSON_AddStringToObject(root, "status", initialized ? "busy" : "disabled");
        return root;
    }
    uint64_t now = MS();
    cJSON_AddBoolToObject(root, "connected", s.connected);
    cJSON_AddBoolToObject(root, "connecting", s.connecting);
    cJSON_AddStringToObject(root, "ssid", s.ssid);
    cJSON_AddStringToObject(root, "site", s.site);
    cJSON_AddStringToObject(root, "ip", s.ip);
    cJSON_AddStringToObject(root, "bssid", s.bssid);
    cJSON_AddNumberToObject(root, "rssi", s.rssi);
    cJSON_AddNumberToObject(root, "channel", s.channel);
    cJSON_AddNumberToObject(root, "disconnects", s.disconnects);
    cJSON_AddNumberToObject(root, "disconnect_reason", s.reason);
    if (s.scan_ms) cJSON_AddNumberToObject(root, "scan_age_ms", (double)(now - s.scan_ms));
    else cJSON_AddNullToObject(root, "scan_age_ms");
    cJSON_AddBoolToObject(root, "survey_active", s.survey_active);
    cJSON_AddNumberToObject(root, "survey_errors", s.scan_errors);
    cJSON_AddStringToObject(root, "channel_measure", "AP counts in strongest 24 scan results; not airtime utilization");
    cJSON_AddBoolToObject(root, "ble_enabled", s.ble_ready);
    cJSON_AddStringToObject(root, "ble_init_result", esp_err_to_name(s.ble_init_error));
    cJSON_AddNumberToObject(root, "ble_errors", s.ble_errors);
    cJSON_AddNumberToObject(root, "ble_duty_pct", s.ble_duty);
    cJSON_AddNumberToObject(root, "ble_advertisements", s.ble_advertisements);
    cJSON_AddNumberToObject(root, "ble_queue_drops", ble_queue_drops);
    cJSON_AddNumberToObject(root, "radio_queue_drops", radio_queue_drops);
    cJSON_AddNumberToObject(root, "observation_evictions", s.registry.observation_evictions);
    cJSON_AddNumberToObject(root, "anonymous_count", (double)ec_radio_anonymous_count(&s.registry, now));
    cJSON_AddNumberToObject(root, "anonymous_window_s", EC_RADIO_ANONYMOUS_TTL_MS / 1000);
    cJSON_AddBoolToObject(root, "throttled", s.throttle);
    cJSON_AddBoolToObject(root, "time_synced", epoch() != 0);
    cJSON_AddStringToObject(root, "timezone", "Europe/London");
    cJSON_AddStringToObject(root, "presence_limit", "Device advertisements are evidence of a device, not proof of a person; private addresses can rotate");
    cJSON_AddNumberToObject(root, "enrollment_remaining_s", s.enrollment_until_ms > now ? (double)(s.enrollment_until_ms - now) / 1000 : 0);
    cJSON *aps = cJSON_AddArrayToObject(root, "aps"), *ble = cJSON_AddArrayToObject(root, "ble"), *known = cJSON_AddArrayToObject(root, "known"), *channels = cJSON_AddArrayToObject(root, "channels");
    if (!aps || !ble || !known || !channels) { xSemaphoreGive(lock); cJSON_Delete(root); return NULL; }
    for (size_t i = 0; i < s.ap_count; ++i) {
        const ap_t *a = &s.aps[i]; cJSON *o = cJSON_CreateObject();
        if (!o) break;
        cJSON_AddStringToObject(o, "ssid", s.show_ssids ? a->ssid : "hidden");
        cJSON_AddNumberToObject(o, "channel", a->channel);
        cJSON_AddNumberToObject(o, "rssi", a->rssi);
        cJSON_AddStringToObject(o, "auth", auth_name(a->auth));
        cJSON_AddItemToArray(aps, o);
    }
    unsigned anonymous_rssi[3] = {0};
    bool enrollment_open = s.enrollment_until_ms > now;
    for (size_t i = 0; i < EC_RADIO_OBSERVATIONS; ++i) {
        const ec_radio_observation_t *a = &s.registry.observed[i];
        if (!a->used || a->id[0] != 'b' || now - a->seen_ms > EC_RADIO_ANONYMOUS_TTL_MS) continue;
        if (ec_radio_registry_find(&s.registry, a->id)) continue;
        ++anonymous_rssi[a->rssi >= -60 ? 0 : a->rssi >= -80 ? 1 : 2];
        if (!enrollment_open || !a->public_id[0]) continue;
        cJSON *o = cJSON_CreateObject();
        if (!o) break;
        cJSON_AddStringToObject(o, "id", a->public_id);
        cJSON_AddStringToObject(o, "name", a->name);
        cJSON_AddNumberToObject(o, "rssi", a->rssi);
        cJSON_AddNumberToObject(o, "last_seen_ms", (double)(now - a->seen_ms));
        cJSON_AddItemToArray(ble, o);
    }
    cJSON *rssi_bins = cJSON_AddArrayToObject(root, "anonymous_rssi_bins");
    if (rssi_bins) for (unsigned i = 0; i < 3; ++i) cJSON_AddItemToArray(rssi_bins, cJSON_CreateNumber(anonymous_rssi[i]));
    cJSON_AddStringToObject(root, "anonymous_detail", enrollment_open ? "temporary_candidates" : "aggregate_only");
    for (size_t i = 0; i < EC_RADIO_KNOWN; ++i) {
        const ec_radio_known_t *a = &s.registry.known[i]; if (!a->used) continue;
        cJSON *o = cJSON_CreateObject();
        if (!o) break;
        cJSON_AddStringToObject(o, "id", a->id);
        cJSON_AddStringToObject(o, "uuid", a->uuid);
        cJSON_AddStringToObject(o, "name", a->name);
        cJSON_AddStringToObject(o, "state", ec_radio_presence(a, now));
        if (a->seen_this_boot) {
            cJSON_AddNumberToObject(o, "rssi", a->rssi);
            cJSON_AddNumberToObject(o, "last_seen_ms", (double)(now - a->seen_ms));
        } else { cJSON_AddNullToObject(o, "rssi"); cJSON_AddNullToObject(o, "last_seen_ms"); }
        cJSON_AddBoolToObject(o, "enabled", a->enabled);
        cJSON_AddNumberToObject(o, "first_seen_epoch_s", (double)a->first_epoch_s);
        cJSON_AddNumberToObject(o, "last_seen_epoch_s", (double)a->last_epoch_s);
        cJSON_AddStringToObject(o, "source", a->id[0] == 'a' ? "wifi_ap" : "ble_advertisement");
        cJSON_AddItemToArray(known, o);
    }
    for (unsigned i = 0; i < 14; ++i) cJSON_AddItemToArray(channels, cJSON_CreateNumber(s.channel_counts[i]));
#if CONFIG_EC_SCOUT_METADATA
    cJSON_AddBoolToObject(root, "scout_metadata_active", metadata_active);
    cJSON *frames = cJSON_AddArrayToObject(root, "frame_type_counts");
    for (unsigned i = 0; i < 4; ++i) cJSON_AddItemToArray(frames, cJSON_CreateNumber(metadata_frames[i]));
#else
    cJSON_AddBoolToObject(root, "scout_metadata_active", false);
#endif
    xSemaphoreGive(lock);
    return root;
}

static bool valid_password(const char *p)
{
    size_t n = strlen(p);
    if (n == 0 || (n >= 8 && n <= 63)) return true;
    if (n != 64) return false;
    for (size_t i = 0; i < n; ++i) if (!isxdigit((unsigned char)p[i])) return false;
    return true;
}

esp_err_t ec_radio_command(const char *op, const cJSON *body, cJSON **response)
{
    if (response) *response = NULL;
    if (!initialized) return ESP_ERR_INVALID_STATE;
    if (!op || !cJSON_IsObject(body)) return ESP_ERR_INVALID_ARG;
    if (xSemaphoreTake(lock, pdMS_TO_TICKS(300)) != pdTRUE) return ESP_ERR_TIMEOUT;
    esp_err_t err = ESP_OK;
    uint64_t now = MS();
    const char *id = json_string(body, "id"), *name = json_string(body, "name");
    if (!strcmp(op, "enroll") && !id) {
        const cJSON *v = cJSON_GetObjectItemCaseSensitive(body, "seconds");
        int seconds = cJSON_IsNumber(v) ? v->valueint : 60;
        if (seconds < 0 || seconds > 120) err = ESP_ERR_INVALID_ARG;
        else s.enrollment_until_ms = now + (uint64_t)seconds * 1000;
    } else if (!strcmp(op, "enroll")) {
        ec_radio_observation_t *observation = observation_by_id(id, true);
        if (now >= s.enrollment_until_ms) err = ESP_ERR_INVALID_STATE;
        else if (!observation || now - observation->seen_ms > EC_RADIO_ANONYMOUS_TTL_MS) err = ESP_ERR_NOT_FOUND;
        if (err != ESP_OK) goto command_done;
        const char *stable_id = observation->id;
        uint8_t random[16]; char uuid[33]; esp_fill_random(random, sizeof(random));
        for (unsigned i = 0; i < 16; ++i) snprintf(uuid + i * 2, 3, "%02x", random[i]);
        ec_radio_known_t *target = ec_radio_registry_find(&s.registry, stable_id);
        if (!target) for (size_t i = 0; i < EC_RADIO_KNOWN; ++i) if (!s.registry.known[i].used) { target = &s.registry.known[i]; break; }
        ec_radio_known_t previous = {0};
        if (target) previous = *target;
        int rc = ec_radio_registry_enroll(&s.registry, stable_id, name, uuid, now, epoch());
        err = rc == -1 ? ESP_ERR_NOT_FOUND : rc == -2 ? ESP_ERR_NO_MEM : rc ? ESP_ERR_INVALID_ARG : save_registry();
        if (rc == 0 && err != ESP_OK && target) *target = previous;
        if (err == ESP_OK) s.enrollment_until_ms = 0;
    } else if (!strcmp(op, "rename") || !strcmp(op, "archive")) {
        ec_radio_known_t *k = ec_radio_registry_find(&s.registry, id);
        if (!k) err = ESP_ERR_NOT_FOUND;
        else if (!strcmp(op, "rename")) {
            if (!name || !*name || strlen(name) >= sizeof(k->name)) err = ESP_ERR_INVALID_ARG;
            else {
                ec_radio_known_t previous = *k;
                str_copy(k->name, sizeof(k->name), name); err = save_registry();
                if (err != ESP_OK) *k = previous;
            }
        } else {
            const cJSON *v = cJSON_GetObjectItemCaseSensitive(body, "enabled");
            if (v && !cJSON_IsBool(v)) err = ESP_ERR_INVALID_ARG;
            else {
                bool previous = k->enabled;
                k->enabled = cJSON_IsTrue(v); err = save_registry();
                if (err != ESP_OK) k->enabled = previous;
            }
        }
    } else if (!strcmp(op, "enrollment")) {
        const cJSON *v = cJSON_GetObjectItemCaseSensitive(body, "seconds");
        int seconds = cJSON_IsNumber(v) ? v->valueint : 60;
        if (seconds < 0 || seconds > 120) err = ESP_ERR_INVALID_ARG;
        else s.enrollment_until_ms = now + (uint64_t)seconds * 1000;
    } else if (!strcmp(op, "scan")) {
        if (!s.connected || s.connecting || s.survey_active || s.throttle) err = ESP_ERR_INVALID_STATE;
        else if (s.scan_ms && now - s.scan_ms < 10000) err = ESP_ERR_INVALID_STATE;
        else s.next_scan_ms = now;
    } else if (!strcmp(op, "ssids")) {
        const cJSON *v = cJSON_GetObjectItemCaseSensitive(body, "show");
        if (!cJSON_IsBool(v)) err = ESP_ERR_INVALID_ARG; else s.show_ssids = cJSON_IsTrue(v);
    } else if (!strcmp(op, "network") || !strcmp(op, "provision")) {
        const cJSON *v = cJSON_GetObjectItemCaseSensitive(body, "slot");
        int slot = cJSON_IsNumber(v) ? v->valueint - 1 : 0;
        const char *ssid = json_string(body, "ssid"), *pass = json_string(body, "password"), *site = json_string(body, "site");
        if (slot < 0 || slot >= WIFI_SLOTS || !ssid || !*ssid || strlen(ssid) > 32 || !pass || !valid_password(pass) || (site && strlen(site) > 31)) err = ESP_ERR_INVALID_ARG;
        else {
            cJSON *o = cJSON_CreateObject();
            if (!o) err = ESP_ERR_NO_MEM;
            else {
                cJSON_AddStringToObject(o, "ssid", ssid);
                cJSON_AddStringToObject(o, "password", pass);
                cJSON_AddStringToObject(o, "site", site ? site : "");
                char *text = cJSON_PrintUnformatted(o); cJSON_Delete(o);
                if (!text) err = ESP_ERR_NO_MEM;
                else {
                    nvs_handle_t h; err = nvs_open("ec_radio", NVS_READWRITE, &h);
                    if (err == ESP_OK) {
                        static const char *const keys[WIFI_SLOTS] = {"wifi0", "wifi1", "wifi2"};
                        const char *key = keys[slot];
                        err = nvs_set_str(h, key, text);
                        if (err == ESP_OK) err = nvs_commit(h);
                        nvs_close(h);
                    }
                    memset(text, 0, strlen(text)); free(text);
                    if (err == ESP_OK) {
                        str_copy(s.trusted[slot].ssid, sizeof(s.trusted[slot].ssid), ssid);
                        str_copy(s.trusted[slot].password, sizeof(s.trusted[slot].password), pass);
                        str_copy(s.trusted[slot].site, sizeof(s.trusted[slot].site), site);
                        post(R_PROVISIONED, slot, 0);
                    }
                }
            }
        }
    } else err = ESP_ERR_NOT_SUPPORTED; /* Deliberately no delete operation. */
command_done:
    xSemaphoreGive(lock);
    if (response) {
        *response = cJSON_CreateObject();
        if (*response) { cJSON_AddBoolToObject(*response, "ok", err == ESP_OK); cJSON_AddStringToObject(*response, "result", esp_err_to_name(err)); }
    }
    return err;
}
