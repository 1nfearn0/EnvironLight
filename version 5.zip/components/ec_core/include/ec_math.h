#pragma once
#include <stddef.h>
#include <stdint.h>
typedef struct { double energy, duration_s; float maximum; uint32_t count; } ec_energy_t;
void ec_energy_add(ec_energy_t *e, float db, double duration_s);
float ec_energy_db(const ec_energy_t *e);
float ec_dew_point(float temperature_c, float humidity_rh);
float ec_absolute_humidity(float temperature_c, float humidity_rh);
float ec_vpd(float temperature_c, float humidity_rh);
float ec_relative_height(float pressure_pa, float reference_pa);
int ec_exposure_action(float used_pct, unsigned low_frames);
uint32_t ec_crc32(const void *bytes, size_t length);
void ec_fft(float *real, float *imag, size_t n);
float ec_a_weight_db(float hz);
float ec_c_weight_db(float hz);
float ec_percentile(float *scratch, size_t n, float fraction);
