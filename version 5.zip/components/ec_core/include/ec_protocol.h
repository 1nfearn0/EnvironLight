#pragma once
#include "ec.h"
#define EC_AUDIO_PACKET_SIZE 660
#define EC_PRESSURE_PACKET_SIZE 76
size_t ec_encode_audio(const ec_audio_t *audio,uint8_t *out,size_t capacity);
size_t ec_encode_pressure(const ec_atmos_t *atmos,uint8_t *out,size_t capacity);
void ec_wav_header(uint8_t out[44],uint32_t frames);
