#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define EC_VERSION "0.5.0-dev1"
#define EC_SCHEMA 3
#define EC_FFT_N 2048
#define EC_HOP_N 512
#define EC_SAMPLE_RATE 48000
#define EC_BINS 256
#define EC_ENVELOPE 64
#define EC_EVENTS 256
#define EC_QUALITY_STALE 1u
#define EC_QUALITY_LOW 2u
#define EC_QUALITY_CLIPPED 4u
#define EC_QUALITY_SETTLING 8u
#define EC_QUALITY_ESTIMATED 16u

typedef enum { EC_ENVIRONLIGHT, EC_RADIOSCOUT } ec_profile_id_t;
typedef struct {
    uint64_t t_us;
    uint32_t seq, flags;
    float dbfs, peak_dbfs, spl_est, dba_est, dbc_est;
    float leq_1s, leq_10s, leq_60s, l10, l50, l90;
    float centroid_hz, bandwidth_hz, rolloff_hz, flatness, flux;
    float dominant_hz, crest_db, zero_crossing_rate, coverage;
    float bands[8];
    uint8_t spectrum[EC_BINS];
    int16_t wave_min[EC_ENVELOPE], wave_max[EC_ENVELOPE];
    uint32_t capture_overruns, dsp_drops, processing_us;
} ec_audio_t;
typedef struct {
    uint64_t t_us;
    uint32_t seq, flags;
    uint16_t raw[8], clear_raw, nir_raw;
    float basic[8], profile[8];
    float gain, integration_ms, adc_used_pct, headroom_pct, actual_hz;
    float centroid_nm, red_blue_ratio, entropy_pct, flux, cct_k, cie_x, cie_y;
    uint32_t reads, errors, recoveries;
} ec_light_t;
typedef struct {
    uint64_t t_us, climate_us, pressure_us;
    uint32_t seq, flags;
    float temperature_c, humidity_rh, bmp_temperature_c, pressure_pa;
    float dew_point_c, absolute_humidity_gm3, vpd_kpa, heat_index_c;
    float pressure_residual_pa, pressure_slope_pas, relative_height_m;
    float pressure_psd[4], pressure_noise_pa, pressure_hz;
    float temperature_slope_cmin, humidity_slope_rhmin, ah_slope_gm3min;
    uint32_t climate_reads, climate_errors, pressure_reads, pressure_errors;
} ec_atmos_t;
typedef struct {
    uint64_t t_us, epoch_s;
    uint32_t seq, evidence;
    float confidence;
    char kind[32], label[80];
} ec_event_t;
typedef struct {
    ec_profile_id_t profile;
    uint32_t boot_id;
    uint64_t uptime_us, epoch_s;
    ec_audio_t audio;
    ec_light_t light;
    ec_atmos_t atmos;
} ec_snapshot_t;

void ec_state_init(ec_profile_id_t profile);
void ec_get_snapshot(ec_snapshot_t *out);
void ec_update_audio(const ec_audio_t *value);
void ec_update_light(const ec_light_t *value);
void ec_update_atmos(const ec_atmos_t *value);
void ec_event(const char *kind, const char *label, float confidence, uint32_t evidence);
size_t ec_events_copy(ec_event_t *out, size_t capacity, uint32_t after_seq);
uint64_t ec_now_us(void);
const char *ec_device_id(void);
const char *ec_device_name(void);
const char *ec_hostname(void);
bool ec_is_scout(void);
