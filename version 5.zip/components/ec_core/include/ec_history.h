#pragma once
#include <stdint.h>
#include "esp_err.h"
#include "cJSON.h"

/* The service mounts the existing `spiffs` partition as LittleFS at /data.
 * Mount failure NEVER formats it. Call tick once per second in a low-priority
 * task. Sensor producers never call the filesystem. */
esp_err_t ec_history_init(void);
void ec_history_tick(void);
/* Newest `limit` records preceding before_seq, returned in chronological order.
 * before_seq=0 means latest. resolution_s is 1, 10 or 60; limit is capped at
 * 1000. The response's next_before_seq continues backwards without duplicates. */
cJSON *ec_history_json(unsigned resolution_s, unsigned limit, uint32_t before_seq);
cJSON *ec_history_events_json(unsigned limit, uint32_t before_seq);
cJSON *ec_history_status_json(void);
cJSON *ec_history_legacy_json(void);
cJSON *ec_scenes_json(void);
/* Requires at least 300 valid seconds for one sensor (audio is weighted by
 * actual coverage). Other sensor means stay null until they independently
 * have 300 valid seconds. The caller
 * should map ESP_ERR_INVALID_STATE to HTTP 409. Up to eight named scenes. */
esp_err_t ec_scene_capture(const char *name);
