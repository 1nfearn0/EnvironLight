#include "ec.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "esp_heap_caps.h"
#include "esp_mac.h"
#include "esp_random.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static SemaphoreHandle_t lock;
static ec_snapshot_t state;
static ec_event_t *events;
static size_t event_head,event_count;
static uint32_t event_seq;
static char device_id[48],hostname[48];
static uint64_t last_audio_event,last_light_event,last_pressure_event,last_fusion;

uint64_t ec_now_us(void) { return (uint64_t)esp_timer_get_time(); }
bool ec_is_scout(void) { return state.profile == EC_RADIOSCOUT; }
const char *ec_device_name(void) { return ec_is_scout() ? "RadioScout" : "EnvironLight"; }
const char *ec_device_id(void) { return device_id; }
const char *ec_hostname(void) { return hostname; }

void ec_state_init(ec_profile_id_t profile){
    memset(&state, 0, sizeof(state));
    state.profile = profile;
    state.boot_id = esp_random();
    uint8_t mac[6] = {0};
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(device_id,sizeof(device_id),"%s-%02x%02x%02x",profile==EC_RADIOSCOUT?"radioscout":"environlight",mac[3],mac[4],mac[5]);
    snprintf(hostname,sizeof(hostname),"%s",profile==EC_RADIOSCOUT?"radioscout":"environlight");
    lock = xSemaphoreCreateMutex();
    configASSERT(lock);
    events = heap_caps_calloc(EC_EVENTS, sizeof(*events), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!events) {
        events = heap_caps_calloc(EC_EVENTS, sizeof(*events), MALLOC_CAP_8BIT);
    }
    ec_audio_t *a=&state.audio;
    a->dbfs=a->peak_dbfs=a->spl_est=a->dba_est=a->dbc_est=NAN;
    a->leq_1s=a->leq_10s=a->leq_60s=a->l10=a->l50=a->l90=NAN;
    a->centroid_hz=a->bandwidth_hz=a->rolloff_hz=a->flatness=a->flux=NAN;
    a->dominant_hz=a->crest_db=a->zero_crossing_rate=NAN;
    a->flags=EC_QUALITY_STALE;
    ec_light_t *l=&state.light;
    l->cct_k=l->centroid_nm=l->red_blue_ratio=l->entropy_pct=l->flux=NAN;
    l->cie_x=l->cie_y=l->gain=l->integration_ms=l->headroom_pct=l->adc_used_pct=NAN;
    l->flags=EC_QUALITY_STALE;
    for (size_t i=0; i<8; i++) {
        l->basic[i]=l->profile[i]=NAN;
        a->bands[i]=NAN;
    }
    ec_atmos_t *t=&state.atmos;
    t->temperature_c=t->humidity_rh=t->bmp_temperature_c=t->pressure_pa=NAN;
    t->dew_point_c=t->absolute_humidity_gm3=t->vpd_kpa=t->heat_index_c=NAN;
    t->pressure_residual_pa=t->pressure_slope_pas=t->relative_height_m=t->pressure_noise_pa=NAN;
    t->temperature_slope_cmin=t->humidity_slope_rhmin=t->ah_slope_gm3min=NAN;
    for (int i=0; i<4; i++) {
        t->pressure_psd[i]=NAN;
    }
    t->flags=EC_QUALITY_STALE;
    ec_event("boot","Instrument started",1,0);
}
void ec_get_snapshot(ec_snapshot_t *out){
    if (!out) return;
    xSemaphoreTake(lock,portMAX_DELAY);
    *out=state;
    xSemaphoreGive(lock);
    out->uptime_us=ec_now_us();
    time_t now=time(NULL);
    out->epoch_s=now>1700000000?(uint64_t)now:0;
    if(!out->audio.t_us||out->uptime_us-out->audio.t_us>2000000)out->audio.flags|=EC_QUALITY_STALE;
    if(!out->light.t_us||out->uptime_us-out->light.t_us>3000000)out->light.flags|=EC_QUALITY_STALE;
    if(!out->atmos.climate_us||out->uptime_us-out->atmos.climate_us>10000000)out->atmos.flags|=EC_QUALITY_STALE;
}
void ec_event(const char *kind,const char *label,float confidence,uint32_t evidence){
    if (!events) return;
    ec_event_t e={0};
    e.t_us=ec_now_us();
    time_t now=time(NULL);
    e.epoch_s=now>1700000000?(uint64_t)now:0;
    e.confidence=isfinite(confidence)?fminf(1,fmaxf(0,confidence)):0;e.evidence=evidence;
    snprintf(e.kind,sizeof(e.kind),"%s",kind?kind:"unknown");snprintf(e.label,sizeof(e.label),"%s",label?label:"");
    xSemaphoreTake(lock,portMAX_DELAY);
    e.seq=++event_seq;
    events[event_head]=e;
    event_head=(event_head+1)%EC_EVENTS;
    if(event_count<EC_EVENTS) event_count++;
    xSemaphoreGive(lock);
}
size_t ec_events_copy(ec_event_t *out,size_t cap,uint32_t after){
    if (!out || !events) return 0;
    size_t n=0;
    xSemaphoreTake(lock,portMAX_DELAY);
    for(size_t i=0;i<event_count&&n<cap;i++){size_t pos=(event_head+EC_EVENTS-event_count+i)%EC_EVENTS;if(events[pos].seq>after)out[n++]=events[pos];}
    xSemaphoreGive(lock);
    return n;
}
/* Called with the state lock held. Returns an evidence mask when a new fused
 * event is due; the caller emits the event after releasing the lock. */
static uint32_t maybe_fuse_locked(uint64_t now){
    uint32_t mask=0;
    if(last_audio_event&&now-last_audio_event<3000000)mask|=1;
    if(last_light_event&&now-last_light_event<3000000)mask|=2;
    if(last_pressure_event&&now-last_pressure_event<3000000)mask|=4;
    if ((mask & (mask-1)) && now-last_fusion>5000000) {
        last_fusion=now;
        return mask;
    }
    return 0;
}
static void emit_fusion(uint32_t mask) {
    if (!mask) return;
    ec_event("multimodal_candidate",
             (mask&4)?"Pressure and coincident room change":"Acoustic and spectral-light change",
             .6f,mask);
}
void ec_update_audio(const ec_audio_t *v){
    if (!v) return;
    bool candidate=false;
    uint32_t fusion=0;
    xSemaphoreTake(lock,portMAX_DELAY);
    state.audio=*v;
    if (isfinite(v->dbfs)&&isfinite(v->crest_db)&&v->crest_db>13&&v->dbfs>-55&&v->t_us-last_audio_event>3000000) {
        last_audio_event=v->t_us;
        candidate=true;
        fusion=maybe_fuse_locked(v->t_us);
    }
    xSemaphoreGive(lock);
    if (candidate) ec_event("acoustic_transient","Acoustic transient candidate",.55f,1);
    emit_fusion(fusion);
}
void ec_update_light(const ec_light_t *v){
    if (!v) return;
    bool candidate=false;
    uint32_t fusion=0;
    xSemaphoreTake(lock,portMAX_DELAY);
    state.light=*v;
    if (!(v->flags&(EC_QUALITY_LOW|EC_QUALITY_SETTLING|EC_QUALITY_STALE))&&isfinite(v->flux)&&v->flux>.15f&&v->t_us-last_light_event>2000000) {
        last_light_event=v->t_us;
        candidate=true;
        fusion=maybe_fuse_locked(v->t_us);
    }
    xSemaphoreGive(lock);
    if (candidate) ec_event("light_shift","Spectral-light change",.75f,2);
    emit_fusion(fusion);
}
void ec_update_atmos(const ec_atmos_t *v){
    if (!v) return;
    float threshold=isfinite(v->pressure_noise_pa)?fmaxf(3,v->pressure_noise_pa*4):5;
    bool candidate=false;
    uint32_t fusion=0;
    xSemaphoreTake(lock,portMAX_DELAY);
    state.atmos=*v;
    if (isfinite(v->pressure_residual_pa)&&fabsf(v->pressure_residual_pa)>threshold&&v->pressure_us-last_pressure_event>5000000) {
        last_pressure_event=v->pressure_us;
        candidate=true;
        fusion=maybe_fuse_locked(v->pressure_us);
    }
    xSemaphoreGive(lock);
    if (candidate) ec_event("pressure_pulse","Pressure disturbance candidate",.5f,4);
    emit_fusion(fusion);
}
