#ifndef EC_HISTORY_HOST_TEST
#include "ec_history.h"
#include "esp_heap_caps.h"
#include "esp_littlefs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "nvs.h"
#endif
#include "ec.h"
#include "ec_math.h"
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#define EC_HISTORY_MAGIC UINT32_C(0x35484345)
#define EC_EVENT_MAGIC UINT32_C(0x35454345)
#define EC_FILE_MAGIC UINT32_C(0x35464345)
#define EC_SCENE_MAGIC UINT32_C(0x35534345)
#define EC_HISTORY_VERSION 1u
#define RAM_CAPACITY 3600u
#define TEN_CAPACITY 8640u
#define MINUTE_CAPACITY 40320u
#define EVENT_CAPACITY 512u
#define SCENE_CAPACITY 8u
#define SCENE_MIN_SECONDS 300u
#define FS_RESERVE (256u * 1024u)
#define AUDIO_VALID 1u
#define LIGHT_VALID 2u
#define CLIMATE_VALID 4u
#define PRESSURE_VALID 8u
#define INT16_MISSING INT16_MIN
#define UINT16_MISSING UINT16_MAX

/* Versioned little-endian IEEE-754 record, used only on ESP32. Quantities with
 * physical units keep explicit scale factors; profile entries sum to ~65535.
 * A CRC covers all fields preceding crc. Structs are zero-filled before use. */
typedef struct {
    uint64_t epoch_s;
    uint32_t magic, seq, boot_id, uptime_s, flags;
    uint16_t light_profile[8];
    float light_intensity;
    uint32_t pressure_cpa;
    int16_t dbfs_cdb, dba_cdb, peak_cdb, temperature_cc;
    uint16_t humidity_crh, centroid_dnm;
    uint16_t span_s, observed_s, audio_n, light_n, climate_n, pressure_n;
    uint16_t audio_ms, reserved;
    uint32_t crc;
} history_record_t;

typedef struct {
    uint32_t magic, version, record_bytes, capacity, resolution_s;
    uint32_t reserved[2], crc;
} file_header_t;

typedef struct {
    uint32_t magic, log_seq, boot_id;
    ec_event_t value;
    uint32_t crc;
} event_record_t;

typedef struct {
    char name[48];
    uint32_t boot_id, seq, window_s;
    uint64_t epoch_s;
    uint16_t audio_n, light_n, climate_n, pressure_n;
    float dbfs, dba_est, temperature_c, humidity_rh, pressure_pa;
    float light_intensity, light_centroid_nm, light_profile[8];
} scene_t;

typedef struct {
    uint32_t magic, version, count;
    scene_t values[SCENE_CAPACITY];
    uint32_t crc;
} scenes_blob_t;

typedef struct {
    FILE *file;
    const char *path;
    uint32_t capacity, head, slots, newest_seq;
    unsigned resolution_s, record_bytes;
    uint32_t crc_errors, io_errors;
    bool writable;
} disk_ring_t;

typedef struct {
    ec_energy_t dbfs, dba;
    double temperature, humidity, pressure, intensity, centroid, profile[8];
    float peak;
    uint32_t count, audio_n, light_n, climate_n, pressure_n;
    uint32_t audio_ms, quality, first_boot, first_uptime, last_seq;
    uint64_t first_epoch;
} aggregate_t;

static SemaphoreHandle_t lock;
static history_record_t *ram;
static unsigned ram_head, ram_count, ram_capacity=RAM_CAPACITY;
static uint32_t next_seq = 1, next_event_seq = 1, last_source_event;
static uint32_t last_boot;
static uint64_t last_tick_us;
static bool mounted, ram_external;
static disk_ring_t ten = {.path="/data/ec5_10s.bin", .resolution_s=10, .record_bytes=sizeof(history_record_t)};
static disk_ring_t minute = {.path="/data/ec5_60s.bin", .resolution_s=60, .record_bytes=sizeof(history_record_t)};
static disk_ring_t events = {.path="/data/ec5_events.bin", .record_bytes=sizeof(event_record_t)};
static aggregate_t agg10, agg60;
static scenes_blob_t scenes;
static uint32_t scene_crc_errors, skipped_ticks;

static void number(cJSON *o, const char *key, double value)
{
    if (isfinite(value)) cJSON_AddNumberToObject(o, key, value);
    else cJSON_AddNullToObject(o, key);
}

static bool newer(uint32_t a, uint32_t b) { return (int32_t)(a - b) > 0; }
static bool prior(uint32_t a, uint32_t before) { return before == 0 || (int32_t)(a - before) < 0; }
static bool fresh(uint64_t now, uint64_t sample, uint64_t age)
{ return sample && now >= sample && now - sample <= age; }

static int16_t signed_scaled(float value, float scale)
{
    if (!isfinite(value)) return INT16_MISSING;
    double v = round((double)value * scale);
    if (v < INT16_MIN + 1) v = INT16_MIN + 1;
    if (v > INT16_MAX) v = INT16_MAX;
    return (int16_t)v;
}

static float signed_value(int16_t value, float scale)
{ return value == INT16_MISSING ? NAN : (float)value / scale; }

static size_t file_bytes(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0 && st.st_size > 0 ? (size_t)st.st_size : 0;
}

static bool record_valid(const void *p, unsigned bytes, uint32_t magic)
{
    uint32_t stored = 0, actual_magic = 0;
    memcpy(&actual_magic, p, sizeof(actual_magic));
    /* History magic follows its leading epoch, event magic starts the record. */
    if (magic == EC_HISTORY_MAGIC) memcpy(&actual_magic, (const char *)p + offsetof(history_record_t, magic), 4);
    size_t crc_offset = magic == EC_HISTORY_MAGIC ? offsetof(history_record_t, crc) : offsetof(event_record_t, crc);
    if (bytes < crc_offset + 4 || actual_magic != magic) return false;
    memcpy(&stored, (const char *)p + crc_offset, 4);
    return ec_crc32(p, crc_offset) == stored;
}

static bool disk_read(disk_ring_t *d, uint32_t index, void *out)
{
    if (!d->file || index >= d->slots) return false;
    long position = (long)sizeof(file_header_t) + (long)index * d->record_bytes;
    if (fseek(d->file, position, SEEK_SET) != 0 || fread(out, d->record_bytes, 1, d->file) != 1) {
        clearerr(d->file); d->io_errors++; return false;
    }
    return record_valid(out, d->record_bytes, d == &events ? EC_EVENT_MAGIC : EC_HISTORY_MAGIC);
}

static void disk_open(disk_ring_t *d, uint32_t requested)
{
    file_header_t h = {0};
    size_t size = file_bytes(d->path);
    if (size) {
        d->file = fopen(d->path, "r+b");
        if (!d->file || fread(&h, sizeof(h), 1, d->file) != 1 ||
            h.magic != EC_FILE_MAGIC || h.version != EC_HISTORY_VERSION ||
            h.record_bytes != d->record_bytes || h.resolution_s != d->resolution_s ||
            h.capacity == 0 || h.capacity > 100000u ||
            h.crc != ec_crc32(&h, offsetof(file_header_t, crc))) {
            d->io_errors++;
            if (d->file) fclose(d->file);
            d->file = NULL; return; /* Preserve unsupported/damaged files. */
        }
        d->capacity = h.capacity;
        d->slots = (uint32_t)((size - sizeof(h)) / d->record_bytes);
        if (d->slots > d->capacity) d->slots = d->capacity;
        unsigned char buffer[sizeof(event_record_t) > sizeof(history_record_t) ? sizeof(event_record_t) : sizeof(history_record_t)];
        for (uint32_t i = 0; i < d->slots; ++i) {
            if (!disk_read(d, i, buffer)) { d->crc_errors++; continue; }
            uint32_t seq;
            memcpy(&seq, buffer + (d == &events ? offsetof(event_record_t, log_seq) : offsetof(history_record_t, seq)), 4);
            if (!d->newest_seq || newer(seq, d->newest_seq)) {
                d->newest_seq = seq; d->head = (i + 1) % d->capacity;
            }
        }
        if (size > sizeof(h) && (size - sizeof(h)) % d->record_bytes) d->crc_errors++;
        if (!d->newest_seq) d->head = 0;
        d->writable = true;
        return;
    }
    if (requested == 0) return;
    d->file = fopen(d->path, "w+b");
    if (!d->file) { d->io_errors++; return; }
    h.magic = EC_FILE_MAGIC; h.version = EC_HISTORY_VERSION;
    h.record_bytes = d->record_bytes; h.capacity = requested; h.resolution_s = d->resolution_s;
    h.crc = ec_crc32(&h, offsetof(file_header_t, crc));
    if (fwrite(&h, sizeof(h), 1, d->file) != 1 || fflush(d->file) != 0) {
        d->io_errors++; fclose(d->file); d->file = NULL; return;
    }
    d->capacity = requested; d->writable = true;
}

static bool disk_append(disk_ring_t *d, const void *record, uint32_t seq)
{
    if (!d->file || !d->writable) return false;
    size_t total = 0, used = 0;
    if (esp_littlefs_info("spiffs", &total, &used) != ESP_OK || used > total || total - used < 48u * 1024u ||
        (d->head >= d->slots && total - used < FS_RESERVE)) {
        d->io_errors++; return false;
    }
    long offset = (long)sizeof(file_header_t) + (long)d->head * d->record_bytes;
    if (fseek(d->file, offset, SEEK_SET) != 0 || fwrite(record, d->record_bytes, 1, d->file) != 1 || fflush(d->file) != 0) {
        clearerr(d->file); d->io_errors++; return false;
    }
    if (d->head >= d->slots) d->slots = d->head + 1;
    d->head = (d->head + 1) % d->capacity;
    d->newest_seq = seq;
    return true;
}

/* Files are ordered circularly by sequence. Locate a page boundary with a
 * binary search, reading O(log capacity) records instead of rescanning weeks
 * of flash for each backwards page. Invalid/torn records are skipped locally. */
static uint32_t sequence_back(const disk_ring_t *d, uint32_t back)
{
    if (!d) return ram[(ram_head+ram_capacity-1-back)%ram_capacity].seq;
    unsigned char bytes[sizeof(event_record_t)>sizeof(history_record_t)?sizeof(event_record_t):sizeof(history_record_t)];
    uint32_t slot=(d->head+d->capacity-1-back)%d->capacity;
    if (!disk_read((disk_ring_t *)d,slot,bytes)) return 0;
    uint32_t seq;
    memcpy(&seq,bytes+(d==&events?offsetof(event_record_t,log_seq):offsetof(history_record_t,seq)),4);
    return seq;
}

static uint32_t page_start(const disk_ring_t *d,uint32_t count,uint32_t before)
{
    if (!before) return 0;
    uint32_t lo=0,hi=count;
    while (lo<hi) {
        uint32_t mid=lo+(hi-lo)/2,probe=mid,seq=0;
        while (probe<hi && !(seq=sequence_back(d,probe))) probe++;
        if (probe==hi) hi=mid;
        else if (prior(seq,before)) hi=probe;
        else lo=probe+1;
    }
    return lo;
}

static void aggregate_add(aggregate_t *a, const history_record_t *r)
{
    if (!a->count) { a->first_epoch = r->epoch_s; a->first_boot = r->boot_id; a->first_uptime = r->uptime_s; a->peak = -INFINITY; }
    a->count += r->span_s; a->last_seq = r->seq; a->quality |= r->flags;
    if (r->audio_n) {
        double duration = r->audio_ms / 1000.0;
        ec_energy_add(&a->dbfs, signed_value(r->dbfs_cdb, 100), duration);
        ec_energy_add(&a->dba, signed_value(r->dba_cdb, 100), duration);
        float peak = signed_value(r->peak_cdb, 100);
        if (isfinite(peak) && peak > a->peak) a->peak = peak;
        a->audio_n += r->audio_n; a->audio_ms += r->audio_ms;
    }
    if (r->light_n) {
        a->intensity += r->light_intensity * r->light_n;
        a->centroid += r->centroid_dnm / 10.0 * r->light_n;
        for (unsigned i=0; i<8; ++i) a->profile[i] += r->light_profile[i] / 65535.0 * r->light_n;
        a->light_n += r->light_n;
    }
    if (r->climate_n) {
        a->temperature += signed_value(r->temperature_cc, 100) * r->climate_n;
        a->humidity += r->humidity_crh / 100.0 * r->climate_n;
        a->climate_n += r->climate_n;
    }
    if (r->pressure_n) { a->pressure += r->pressure_cpa / 100.0 * r->pressure_n; a->pressure_n += r->pressure_n; }
}

static history_record_t aggregate_finish(const aggregate_t *a, unsigned span)
{
    history_record_t r = {0};
    r.magic = EC_HISTORY_MAGIC; r.seq = a->last_seq; r.boot_id = a->first_boot;
    r.epoch_s = a->first_epoch; r.uptime_s = a->first_uptime;
    r.flags = a->quality; r.span_s = span; r.observed_s = a->count;
    r.audio_n = a->audio_n; r.light_n = a->light_n; r.climate_n = a->climate_n; r.pressure_n = a->pressure_n;
    r.audio_ms = a->audio_ms > UINT16_MAX ? UINT16_MAX : a->audio_ms;
    r.dbfs_cdb = signed_scaled(ec_energy_db(&a->dbfs), 100);
    r.dba_cdb = signed_scaled(ec_energy_db(&a->dba), 100);
    r.peak_cdb = signed_scaled(a->peak, 100);
    r.temperature_cc = signed_scaled(a->climate_n ? a->temperature/a->climate_n : NAN, 100);
    r.humidity_crh = a->climate_n ? (uint16_t)lround(a->humidity/a->climate_n*100) : UINT16_MISSING;
    r.pressure_cpa = a->pressure_n ? (uint32_t)llround(a->pressure/a->pressure_n*100) : 0;
    r.light_intensity = a->light_n ? (float)(a->intensity/a->light_n) : NAN;
    r.centroid_dnm = a->light_n ? (uint16_t)lround(a->centroid/a->light_n*10) : UINT16_MISSING;
    for (unsigned i=0; i<8; ++i) r.light_profile[i] = a->light_n ? (uint16_t)lround(a->profile[i]/a->light_n*65535) : 0;
    r.crc = ec_crc32(&r, offsetof(history_record_t, crc));
    return r;
}

static history_record_t sample_record(const ec_snapshot_t *s)
{
    history_record_t r = {0};
    r.magic = EC_HISTORY_MAGIC; r.seq = next_seq++; if (!next_seq) next_seq=1;
    r.boot_id = s->boot_id; r.epoch_s = s->epoch_s;
    r.uptime_s = (uint32_t)(s->uptime_us/1000000u); r.span_s=1; r.observed_s=1;
    r.dbfs_cdb = r.dba_cdb = r.peak_cdb = r.temperature_cc = INT16_MISSING;
    r.humidity_crh = r.centroid_dnm = UINT16_MISSING; r.light_intensity=NAN;
    uint64_t now=s->uptime_us;
    if (fresh(now,s->audio.t_us,2000000) && isfinite(s->audio.dbfs) && s->audio.coverage>0) {
        r.flags |= AUDIO_VALID; r.audio_n=1;
        r.audio_ms=(uint16_t)lroundf(fminf(1,s->audio.coverage)*1000);
        r.dbfs_cdb=signed_scaled(s->audio.dbfs,100);
        r.dba_cdb=signed_scaled(isfinite(s->audio.leq_1s)?s->audio.leq_1s:s->audio.dba_est,100);
        r.peak_cdb=signed_scaled(s->audio.peak_dbfs,100);
    }
    float profile_sum=0;
    for (unsigned i=0; i<8; ++i) if (isfinite(s->light.profile[i]) && s->light.profile[i]>=0) profile_sum+=s->light.profile[i];
    if (fresh(now,s->light.t_us,4000000) && isfinite(s->light.centroid_nm) && profile_sum>0) {
        r.flags |= LIGHT_VALID; r.light_n=1;
        r.light_intensity=0;
        for (unsigned i=0; i<8; ++i) {
            r.light_profile[i]=(uint16_t)lroundf(fmaxf(0,s->light.profile[i])/profile_sum*65535);
            if (isfinite(s->light.basic[i])) r.light_intensity+=s->light.basic[i];
        }
        r.centroid_dnm=(uint16_t)lroundf(s->light.centroid_nm*10);
    }
    if (fresh(now,s->atmos.climate_us,6000000) && isfinite(s->atmos.temperature_c) && isfinite(s->atmos.humidity_rh)) {
        r.flags |= CLIMATE_VALID; r.climate_n=1;
        r.temperature_cc=signed_scaled(s->atmos.temperature_c,100);
        r.humidity_crh=(uint16_t)lroundf(fmaxf(0,fminf(100,s->atmos.humidity_rh))*100);
    }
    if (fresh(now,s->atmos.pressure_us,2000000) && isfinite(s->atmos.pressure_pa) && s->atmos.pressure_pa>0) {
        r.flags |= PRESSURE_VALID; r.pressure_n=1; r.pressure_cpa=(uint32_t)llround((double)s->atmos.pressure_pa*100);
    }
    r.flags |= (s->audio.flags & 0xffu) << 8;
    r.flags |= (s->light.flags & 0xffu) << 16;
    r.flags |= (s->atmos.flags & 0xffu) << 24;
    r.crc=ec_crc32(&r,offsetof(history_record_t,crc));
    return r;
}

esp_err_t ec_history_init(void)
{
    if (lock) return ESP_ERR_INVALID_STATE;
    lock=xSemaphoreCreateMutex();
    if (!lock) return ESP_ERR_NO_MEM;
    ram=heap_caps_calloc(RAM_CAPACITY,sizeof(*ram),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    ram_external=ram!=NULL;
    if (!ram) {
        /* Non-PSRAM scouts retain a smaller, explicitly reported RAM ring. */
        ram_capacity=360;
        ram=heap_caps_calloc(ram_capacity,sizeof(*ram),MALLOC_CAP_8BIT);
    }
    if (!ram) return ESP_ERR_NO_MEM;
    esp_vfs_littlefs_conf_t conf={.base_path="/data",.partition_label="spiffs",.format_if_mount_failed=false,.dont_mount=false};
    esp_err_t result=esp_vfs_littlefs_register(&conf);
    mounted=result==ESP_OK || (result==ESP_ERR_INVALID_STATE && esp_littlefs_mounted("spiffs"));
    if (mounted) {
        size_t total=0,used=0;
        esp_littlefs_info("spiffs",&total,&used);
        size_t existing=file_bytes(ten.path)+file_bytes(minute.path)+file_bytes(events.path);
        size_t budget=total>used?total-used:0;
        if (budget<=SIZE_MAX-existing) budget+=existing;
        budget=budget>FS_RESERVE?budget-FS_RESERVE:0;
        size_t wanted=(TEN_CAPACITY+MINUTE_CAPACITY)*sizeof(history_record_t)+EVENT_CAPACITY*sizeof(event_record_t)+3*sizeof(file_header_t);
        double scale=budget<wanted?(double)budget/wanted:1;
        disk_open(&ten,(uint32_t)(TEN_CAPACITY*scale));
        disk_open(&minute,(uint32_t)(MINUTE_CAPACITY*scale));
        disk_open(&events,(uint32_t)(EVENT_CAPACITY*scale));
        if (ten.newest_seq && newer(ten.newest_seq,next_seq-1)) next_seq=ten.newest_seq+1;
        if (minute.newest_seq && newer(minute.newest_seq,next_seq-1)) next_seq=minute.newest_seq+1;
        if (!next_seq) next_seq=1;
        next_event_seq=events.newest_seq+1; if (!next_event_seq) next_event_seq=1;
    }
    nvs_handle_t handle;
    if (nvs_open("ec_scenes",NVS_READONLY,&handle)==ESP_OK) {
        size_t length=sizeof(scenes);
        if (nvs_get_blob(handle,"v1",&scenes,&length)!=ESP_OK || length!=sizeof(scenes) ||
            scenes.magic!=EC_SCENE_MAGIC || scenes.version!=1 || scenes.count>SCENE_CAPACITY ||
            scenes.crc!=ec_crc32(&scenes,offsetof(scenes_blob_t,crc))) {
            memset(&scenes,0,sizeof(scenes)); scene_crc_errors++;
        }
        nvs_close(handle);
    }
    /* RAM operation is intentionally successful even if existing flash cannot
     * mount. Status exposes that fault; no destructive recovery is attempted. */
    return ESP_OK;
}

void ec_history_tick(void)
{
    if (!lock || !ram || xSemaphoreTake(lock,0)!=pdTRUE) { skipped_ticks++; return; }
    ec_snapshot_t snapshot; ec_get_snapshot(&snapshot);
    if (last_tick_us && snapshot.uptime_us>=last_tick_us && snapshot.uptime_us-last_tick_us<800000) {
        xSemaphoreGive(lock); return;
    }
    if (last_boot && last_boot!=snapshot.boot_id) { memset(&agg10,0,sizeof(agg10)); memset(&agg60,0,sizeof(agg60)); last_source_event=0; }
    if (last_tick_us && snapshot.uptime_us>last_tick_us+1800000) {
        /* Never extend valid measurements across a scheduling gap. Flush a
         * partial block with its true observed/expected coverage. */
        if (agg10.count) { history_record_t r=aggregate_finish(&agg10,10); disk_append(&ten,&r,r.seq); }
        if (agg60.count) { history_record_t r=aggregate_finish(&agg60,60); disk_append(&minute,&r,r.seq); }
        memset(&agg10,0,sizeof(agg10)); memset(&agg60,0,sizeof(agg60)); skipped_ticks++;
    }
    last_tick_us=snapshot.uptime_us; last_boot=snapshot.boot_id;
    history_record_t record=sample_record(&snapshot);
    ram[ram_head]=record; ram_head=(ram_head+1)%ram_capacity; if (ram_count<ram_capacity) ram_count++;
    aggregate_add(&agg10,&record); aggregate_add(&agg60,&record);
    if (agg10.count>=10) { history_record_t r=aggregate_finish(&agg10,10); disk_append(&ten,&r,r.seq); memset(&agg10,0,sizeof(agg10)); }
    if (agg60.count>=60) { history_record_t r=aggregate_finish(&agg60,60); disk_append(&minute,&r,r.seq); memset(&agg60,0,sizeof(agg60)); }
    ec_event_t pending[16];
    size_t count=ec_events_copy(pending,16,last_source_event);
    for (size_t i=0;i<count;++i) {
        event_record_t e={0}; e.magic=EC_EVENT_MAGIC; e.log_seq=next_event_seq;
        e.boot_id=snapshot.boot_id; e.value=pending[i]; e.crc=ec_crc32(&e,offsetof(event_record_t,crc));
        if (!disk_append(&events,&e,e.log_seq)) break;
        next_event_seq++; if (!next_event_seq) next_event_seq=1;
        last_source_event=pending[i].seq;
    }
    xSemaphoreGive(lock);
}

static cJSON *record_json(const history_record_t *r)
{
    cJSON *o=cJSON_CreateObject();
    if (!o) return NULL;
    cJSON_AddNumberToObject(o,"seq",r->seq); cJSON_AddNumberToObject(o,"boot_id",r->boot_id);
    cJSON_AddNumberToObject(o,"epoch_s",r->epoch_s); cJSON_AddNumberToObject(o,"t_us",(double)r->uptime_s*1000000);
    cJSON_AddNumberToObject(o,"span_s",r->span_s);
    cJSON_AddNumberToObject(o,"quality",((r->flags>>8)|(r->flags>>16)|(r->flags>>24))&0xffu);
    cJSON *sensor_quality=cJSON_AddObjectToObject(o,"sensor_quality");
    cJSON_AddNumberToObject(sensor_quality,"audio",(r->flags>>8)&0xffu);
    cJSON_AddNumberToObject(sensor_quality,"light",(r->flags>>16)&0xffu);
    cJSON_AddNumberToObject(sensor_quality,"atmosphere",(r->flags>>24)&0xffu);
    cJSON_AddNumberToObject(o,"coverage",r->span_s?(double)r->observed_s/r->span_s:0);
    number(o,"dbfs",signed_value(r->dbfs_cdb,100)); number(o,"dba_est",signed_value(r->dba_cdb,100));
    number(o,"peak_dbfs",signed_value(r->peak_cdb,100)); number(o,"temperature_c",signed_value(r->temperature_cc,100));
    number(o,"humidity_rh",r->climate_n?r->humidity_crh/100.0:NAN);
    number(o,"pressure_pa",r->pressure_n?r->pressure_cpa/100.0:NAN);
    number(o,"light_centroid_nm",r->light_n?r->centroid_dnm/10.0:NAN);
    number(o,"light_intensity",r->light_n?r->light_intensity:NAN);
    cJSON *profile=cJSON_AddArrayToObject(o,"light_profile");
    for(unsigned i=0;i<8;++i) cJSON_AddItemToArray(profile,r->light_n?cJSON_CreateNumber(r->light_profile[i]/65535.0):cJSON_CreateNull());
    cJSON *valid=cJSON_AddObjectToObject(o,"valid_counts");
    cJSON_AddNumberToObject(valid,"audio",r->audio_n); cJSON_AddNumberToObject(valid,"light",r->light_n);
    cJSON_AddNumberToObject(valid,"climate",r->climate_n); cJSON_AddNumberToObject(valid,"pressure",r->pressure_n);
    cJSON_AddNumberToObject(o,"audio_coverage",r->span_s?(double)r->audio_ms/(r->span_s*1000.0):0);
    return o;
}

cJSON *ec_history_json(unsigned resolution_s,unsigned limit,uint32_t before_seq)
{
    cJSON *o=cJSON_CreateObject(),*array=cJSON_AddArrayToObject(o,"records");
    if (!o) return NULL;
    if (limit==0) limit=360;
    if (limit>1000) limit=1000;
    if (resolution_s!=1 && resolution_s!=10 && resolution_s!=60 && resolution_s!=300 && resolution_s!=3600) {
        cJSON_AddStringToObject(o,"error","resolution_s must be 1, 10, 60, 300 or 3600"); return o;
    }
    cJSON_AddNumberToObject(o,"resolution_s",resolution_s);
    cJSON_AddStringToObject(o,"order","ascending");
    cJSON_AddStringToObject(o,"valid_count_unit","accepted one-second observations, not independent sensor conversions");
    cJSON_AddStringToObject(o,"light_intensity_unit","gain/integration-normalised channel sum (relative)");
    if (!lock || xSemaphoreTake(lock,pdMS_TO_TICKS(2000))!=pdTRUE) { cJSON_AddBoolToObject(o,"busy",true); return o; }
    bool derived=resolution_s>60;
    uint32_t count=resolution_s==1?ram_count:(resolution_s==10?ten.slots:minute.slots);
    disk_ring_t *d=resolution_s==10?&ten:&minute;
    unsigned found=0; uint32_t oldest=0;
    uint32_t start=page_start(resolution_s==1?NULL:d,count,before_seq);
    if (derived) {
        const unsigned group=resolution_s/60;
        history_record_t records[60];
        uint32_t back=start;
        while(back<count && found<limit) {
            unsigned n=0;
            while(back<count && n<group) {
                uint32_t slot=(d->head+d->capacity-1-back++)%d->capacity;
                history_record_t r;
                if(!disk_read(d,slot,&r) || !prior(r.seq,before_seq)) continue;
                records[n++]=r;
            }
            if(!n) continue;
            aggregate_t aggregate={0};
            for(unsigned i=n;i>0;--i) aggregate_add(&aggregate,&records[i-1]);
            history_record_t r=aggregate_finish(&aggregate,resolution_s);
            cJSON *entry=record_json(&r);
            if(!entry) break;
            cJSON_ReplaceItemInObject(entry,"audio_coverage",cJSON_CreateNumber((double)aggregate.audio_ms/(resolution_s*1000.0)));
            cJSON_InsertItemInArray(array,0,entry);
            oldest=records[n-1].seq;
            found++;
        }
        cJSON_AddBoolToObject(o,"derived_from_one_minute_records",true);
        cJSON_AddNumberToObject(o,"available_records",(count+group-1)/group);
    } else for(uint32_t back=start;back<count && found<limit;++back) {
        history_record_t r;
        if(resolution_s==1) r=ram[(ram_head+ram_capacity-1-back)%ram_capacity];
        else { uint32_t slot=(d->head+d->capacity-1-back)%d->capacity; if(!disk_read(d,slot,&r)) continue; }
        if(!prior(r.seq,before_seq)) continue;
        cJSON *entry=record_json(&r); if(!entry) break;
        cJSON_InsertItemInArray(array,0,entry); oldest=r.seq; found++;
    }
    cJSON_AddNumberToObject(o,"next_before_seq",found?oldest:0);
    cJSON_AddNumberToObject(o,"count",found);
    if(!derived)cJSON_AddNumberToObject(o,"available_records",count);
    xSemaphoreGive(lock); return o;
}

cJSON *ec_history_events_json(unsigned limit,uint32_t before_seq)
{
    cJSON *o=cJSON_CreateObject(),*array=cJSON_AddArrayToObject(o,"events");
    if (!o) return NULL;
    if (!limit) limit=100;
    if(limit>256) limit=256;
    if (!lock || xSemaphoreTake(lock,pdMS_TO_TICKS(2000))!=pdTRUE) return o;
    unsigned found=0; uint32_t oldest=0;
    uint32_t start=page_start(&events,events.slots,before_seq);
    for(uint32_t back=start;back<events.slots && found<limit;++back) {
        event_record_t r; uint32_t index=(events.head+events.capacity-1-back)%events.capacity;
        if(!disk_read(&events,index,&r) || !prior(r.log_seq,before_seq)) continue;
        r.value.kind[sizeof(r.value.kind)-1]=0; r.value.label[sizeof(r.value.label)-1]=0;
        cJSON *e=cJSON_CreateObject(); cJSON_AddNumberToObject(e,"seq",r.log_seq); cJSON_AddNumberToObject(e,"source_seq",r.value.seq);
        cJSON_AddNumberToObject(e,"boot_id",r.boot_id); cJSON_AddNumberToObject(e,"t_us",r.value.t_us);
        cJSON_AddNumberToObject(e,"epoch_s",r.value.epoch_s); cJSON_AddStringToObject(e,"kind",r.value.kind); cJSON_AddStringToObject(e,"label",r.value.label);
        number(e,"confidence",r.value.confidence); cJSON_AddNumberToObject(e,"evidence",r.value.evidence);
        cJSON_InsertItemInArray(array,0,e); found++; oldest=r.log_seq;
    }
    cJSON_AddNumberToObject(o,"next_before_seq",found?oldest:0); xSemaphoreGive(lock); return o;
}

static void disk_status(cJSON *o,const char *name,const disk_ring_t *d)
{
    cJSON *s=cJSON_AddObjectToObject(o,name);
    cJSON_AddBoolToObject(s,"ready",d->file && d->writable);
    cJSON_AddNumberToObject(s,"capacity_records",d->capacity); cJSON_AddNumberToObject(s,"stored_slots",d->slots);
    cJSON_AddNumberToObject(s,"capacity_s",(double)d->capacity*d->resolution_s);
    cJSON_AddNumberToObject(s,"record_bytes",d->record_bytes);
    cJSON_AddNumberToObject(s,"crc_errors",d->crc_errors); cJSON_AddNumberToObject(s,"io_errors",d->io_errors);
}

cJSON *ec_history_status_json(void)
{
    cJSON *o=cJSON_CreateObject(); if(!o) return NULL;
    if (!lock || xSemaphoreTake(lock,pdMS_TO_TICKS(2000))!=pdTRUE) { cJSON_AddBoolToObject(o,"ready",false); return o; }
    size_t total=0,used=0; if(mounted) esp_littlefs_info("spiffs",&total,&used);
    cJSON_AddBoolToObject(o,"ready",ram!=NULL); cJSON_AddBoolToObject(o,"mounted",mounted);
    cJSON_AddBoolToObject(o,"autoformat",false); cJSON_AddNumberToObject(o,"total_bytes",total); cJSON_AddNumberToObject(o,"used_bytes",used);
    cJSON_AddNumberToObject(o,"reserve_bytes",FS_RESERVE); cJSON_AddNumberToObject(o,"ram_records",ram_count);
    cJSON_AddNumberToObject(o,"ram_capacity_s",ram_capacity); cJSON_AddBoolToObject(o,"ram_in_psram",ram_external);
    cJSON_AddNumberToObject(o,"skipped_ticks",skipped_ticks); cJSON_AddNumberToObject(o,"scene_crc_errors",scene_crc_errors);
    disk_status(o,"ten_second",&ten); disk_status(o,"one_minute",&minute); disk_status(o,"events",&events);
    xSemaphoreGive(lock); return o;
}

cJSON *ec_history_legacy_json(void)
{
    static const char *names[]={"history.csv","history_prev.csv","environlight_v2.csv","environlight_v2_prev.csv"};
    cJSON *o=cJSON_CreateObject(),*a=cJSON_AddArrayToObject(o,"archives"); if(!o) return NULL;
    cJSON_AddBoolToObject(o,"read_only",true);
    for(unsigned i=0;i<4;++i) {
        char path[96]; snprintf(path,sizeof(path),"/data/%s",names[i]); size_t bytes=file_bytes(path);
        if(!bytes) continue;
        cJSON *f=cJSON_CreateObject(); cJSON_AddStringToObject(f,"name",names[i]); cJSON_AddNumberToObject(f,"bytes",bytes); cJSON_AddItemToArray(a,f);
    }
    return o;
}

static cJSON *scene_json(const scene_t *s)
{
    cJSON *o=cJSON_CreateObject(); if(!o) return NULL;
    cJSON_AddStringToObject(o,"name",s->name); cJSON_AddNumberToObject(o,"boot_id",s->boot_id);
    cJSON_AddNumberToObject(o,"seq",s->seq); cJSON_AddNumberToObject(o,"epoch_s",s->epoch_s);
    cJSON_AddNumberToObject(o,"window_s",s->window_s);
    cJSON_AddStringToObject(o,"valid_count_unit","accepted one-second observations, not independent sensor conversions");
    cJSON_AddStringToObject(o,"aggregation","energy mean for audio; arithmetic mean for physical scalars; per-sensor validity");
    number(o,"dbfs",s->dbfs); number(o,"dba_est",s->dba_est); number(o,"temperature_c",s->temperature_c); number(o,"humidity_rh",s->humidity_rh);
    number(o,"pressure_pa",s->pressure_pa); number(o,"light_intensity",s->light_intensity); number(o,"light_centroid_nm",s->light_centroid_nm);
    cJSON *p=cJSON_AddArrayToObject(o,"light_profile"); for(unsigned i=0;i<8;++i) cJSON_AddItemToArray(p,isfinite(s->light_profile[i])?cJSON_CreateNumber(s->light_profile[i]):cJSON_CreateNull());
    cJSON *v=cJSON_AddObjectToObject(o,"valid_counts"); cJSON_AddNumberToObject(v,"audio",s->audio_n); cJSON_AddNumberToObject(v,"light",s->light_n);
    cJSON_AddNumberToObject(v,"climate",s->climate_n); cJSON_AddNumberToObject(v,"pressure",s->pressure_n); return o;
}

cJSON *ec_scenes_json(void)
{
    cJSON *o=cJSON_CreateObject(),*a=cJSON_AddArrayToObject(o,"scenes"); if(!o) return NULL;
    cJSON_AddNumberToObject(o,"minimum_valid_seconds",SCENE_MIN_SECONDS); cJSON_AddNumberToObject(o,"capacity",SCENE_CAPACITY);
    if (!lock || xSemaphoreTake(lock,pdMS_TO_TICKS(2000))!=pdTRUE) return o;
    for(unsigned i=0;i<scenes.count;++i) cJSON_AddItemToArray(a,scene_json(&scenes.values[i]));
    xSemaphoreGive(lock); return o;
}

esp_err_t ec_scene_capture(const char *name)
{
    if(!name || !name[0] || strlen(name)>=sizeof(scenes.values[0].name)) return ESP_ERR_INVALID_ARG;
    for(const unsigned char *p=(const unsigned char *)name;*p;++p) if(*p<32 || *p==127) return ESP_ERR_INVALID_ARG;
    if(!lock || xSemaphoreTake(lock,pdMS_TO_TICKS(2000))!=pdTRUE) return ESP_ERR_INVALID_STATE;
    aggregate_t a={0}; unsigned included=0;
    /* Use the most recent window needed to collect 300 valid seconds, up to
     * ten minutes. A partially covered audio second contributes its actual
     * duration; it never counts as a full second of acoustic evidence. */
    const history_record_t *latest=ram_count?&ram[(ram_head+ram_capacity-1)%ram_capacity]:NULL;
    for(unsigned back=0;back<ram_count && included<600;++back) {
        history_record_t *r=&ram[(ram_head+ram_capacity-1-back)%ram_capacity];
        if(r->boot_id!=last_boot) break;
        if(last_tick_us/1000000 > (uint64_t)r->uptime_s+600) break;
        history_record_t eligible=*r;
        if ((r->flags>>8)&(EC_QUALITY_STALE|EC_QUALITY_CLIPPED|EC_QUALITY_SETTLING)) eligible.audio_n=0;
        if ((r->flags>>16)&(EC_QUALITY_STALE|EC_QUALITY_CLIPPED|EC_QUALITY_SETTLING|EC_QUALITY_LOW)) eligible.light_n=0;
        aggregate_add(&a,&eligible); included++;
        if (included>=SCENE_MIN_SECONDS &&
            (!latest->audio_n || a.audio_ms>=SCENE_MIN_SECONDS*1000u) &&
            (!latest->light_n || a.light_n>=SCENE_MIN_SECONDS) &&
            (!latest->climate_n || a.climate_n>=SCENE_MIN_SECONDS) &&
            (!latest->pressure_n || a.pressure_n>=SCENE_MIN_SECONDS)) break;
    }
    if(a.audio_ms<SCENE_MIN_SECONDS*1000u && a.light_n<SCENE_MIN_SECONDS && a.climate_n<SCENE_MIN_SECONDS && a.pressure_n<SCENE_MIN_SECONDS) {
        xSemaphoreGive(lock); return ESP_ERR_INVALID_STATE;
    }
    unsigned index=scenes.count;
    for(unsigned i=0;i<scenes.count;++i) if(strcmp(scenes.values[i].name,name)==0) { index=i; break; }
    if(index>=SCENE_CAPACITY) { xSemaphoreGive(lock); return ESP_ERR_NO_MEM; }
    scenes_blob_t updated=scenes; scene_t *s=&updated.values[index]; memset(s,0,sizeof(*s));
    snprintf(s->name,sizeof(s->name),"%s",name); s->boot_id=last_boot; s->seq=next_seq-1; s->window_s=included;
    ec_snapshot_t snapshot; ec_get_snapshot(&snapshot); s->epoch_s=snapshot.epoch_s;
    s->audio_n=a.audio_n; s->light_n=a.light_n; s->climate_n=a.climate_n; s->pressure_n=a.pressure_n;
    s->dbfs=a.audio_ms>=SCENE_MIN_SECONDS*1000u?ec_energy_db(&a.dbfs):NAN;
    s->dba_est=a.audio_ms>=SCENE_MIN_SECONDS*1000u?ec_energy_db(&a.dba):NAN;
    s->temperature_c=a.climate_n>=SCENE_MIN_SECONDS?(float)(a.temperature/a.climate_n):NAN;
    s->humidity_rh=a.climate_n>=SCENE_MIN_SECONDS?(float)(a.humidity/a.climate_n):NAN;
    s->pressure_pa=a.pressure_n>=SCENE_MIN_SECONDS?(float)(a.pressure/a.pressure_n):NAN;
    s->light_intensity=a.light_n>=SCENE_MIN_SECONDS?(float)(a.intensity/a.light_n):NAN;
    s->light_centroid_nm=a.light_n>=SCENE_MIN_SECONDS?(float)(a.centroid/a.light_n):NAN;
    for(unsigned i=0;i<8;++i) s->light_profile[i]=a.light_n>=SCENE_MIN_SECONDS?(float)(a.profile[i]/a.light_n):NAN;
    updated.magic=EC_SCENE_MAGIC; updated.version=1; if(index==updated.count) updated.count++;
    updated.crc=ec_crc32(&updated,offsetof(scenes_blob_t,crc));
    nvs_handle_t handle; esp_err_t result=nvs_open("ec_scenes",NVS_READWRITE,&handle);
    if(result==ESP_OK) {
        result=nvs_set_blob(handle,"v1",&updated,sizeof(updated));
        if(result==ESP_OK) result=nvs_commit(handle);
        nvs_close(handle);
    }
    if(result==ESP_OK) scenes=updated;
    xSemaphoreGive(lock); return result;
}
