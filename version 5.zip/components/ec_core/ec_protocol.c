#include "ec_protocol.h"
#include <string.h>
static void put16(uint8_t *p,uint16_t x){p[0]=(uint8_t)x;p[1]=(uint8_t)(x>>8);}
static void put32(uint8_t *p,uint32_t x){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(x>>(i*8));}
static void put64(uint8_t *p,uint64_t x){for(unsigned i=0;i<8;i++)p[i]=(uint8_t)(x>>(i*8));}
static void putfloat(uint8_t *p,float x){uint32_t bits;memcpy(&bits,&x,4);put32(p,bits);}
static void header(uint8_t *p,uint8_t type,uint32_t seq,uint64_t tus,uint16_t len,uint16_t flags){
    put16(p,0x4345);p[2]=1;p[3]=type;put32(p+4,seq);put64(p+8,tus);put16(p+16,len);put16(p+18,flags);
}
size_t ec_encode_audio(const ec_audio_t *a,uint8_t *p,size_t cap){
    if(!a||!p||cap<EC_AUDIO_PACKET_SIZE)return 0;
    header(p,1,a->seq,a->t_us,EC_AUDIO_PACKET_SIZE-20,(uint16_t)a->flags);
    const float fields[]={a->dbfs,a->peak_dbfs,a->spl_est,a->dba_est,a->dbc_est,a->leq_1s,a->leq_10s,a->leq_60s,a->l10,a->l50,a->l90,a->centroid_hz,a->bandwidth_hz,a->rolloff_hz,a->flatness,a->flux,a->dominant_hz,a->crest_db,a->zero_crossing_rate,a->coverage,(float)a->capture_overruns,(float)a->dsp_drops,(float)a->processing_us,0};
    for(unsigned i=0;i<24;i++)putfloat(p+20+i*4,fields[i]);
    for(unsigned i=0;i<8;i++)putfloat(p+116+i*4,a->bands[i]);
    memcpy(p+148,a->spectrum,EC_BINS);
    for(unsigned i=0;i<EC_ENVELOPE;i++){put16(p+404+i*2,(uint16_t)a->wave_min[i]);put16(p+532+i*2,(uint16_t)a->wave_max[i]);}
    return EC_AUDIO_PACKET_SIZE;
}
size_t ec_encode_pressure(const ec_atmos_t *a,uint8_t *p,size_t cap){
    if(!a||!p||cap<EC_PRESSURE_PACKET_SIZE)return 0;
    header(p,3,a->seq,a->pressure_us,EC_PRESSURE_PACKET_SIZE-20,(uint16_t)a->flags);
    const float f[]={a->pressure_pa,a->bmp_temperature_c,a->pressure_residual_pa,a->pressure_slope_pas,a->relative_height_m,a->pressure_noise_pa,a->pressure_hz,a->pressure_psd[0],a->pressure_psd[1],a->pressure_psd[2],a->pressure_psd[3],(float)a->pressure_reads,(float)a->pressure_errors,0};
    for(unsigned i=0;i<14;i++)putfloat(p+20+i*4,f[i]);
    return EC_PRESSURE_PACKET_SIZE;
}
void ec_wav_header(uint8_t out[44],uint32_t frames){
    memset(out,0,44);memcpy(out,"RIFF",4);put32(out+4,frames*4+36);memcpy(out+8,"WAVEfmt ",8);
    put32(out+16,16);put16(out+20,1);put16(out+22,1);put32(out+24,EC_SAMPLE_RATE);
    put32(out+28,EC_SAMPLE_RATE*4);put16(out+32,4);put16(out+34,32);memcpy(out+36,"data",4);put32(out+40,frames*4);
}
