#include "ec_math.h"
#include <math.h>
#include <stdlib.h>

void ec_energy_add(ec_energy_t *e,float db,double seconds){
    if(!e||!isfinite(db)||!isfinite(seconds)||seconds<=0)return;
    e->energy+=pow(10.0,(double)db/10.0)*seconds;
    e->duration_s+=seconds;
    if(!e->count||db>e->maximum)e->maximum=db;
    e->count++;
}
float ec_energy_db(const ec_energy_t *e){
    return e&&e->duration_s>0&&e->energy>0?(float)(10.0*log10(e->energy/e->duration_s)):NAN;
}
static int valid_climate(float t,float rh){return isfinite(t)&&isfinite(rh)&&t>-100&&t<150&&rh>0&&rh<=100;}
float ec_dew_point(float t,float rh){
    if(!valid_climate(t,rh))return NAN;
    float g=logf(rh/100.f)+17.62f*t/(243.12f+t);
    return 243.12f*g/(17.62f-g);
}
float ec_absolute_humidity(float t,float rh){
    if(!valid_climate(t,rh))return NAN;
    float e=rh*.01f*6.112f*expf(17.62f*t/(243.12f+t));
    return 216.7f*e/(t+273.15f);
}
float ec_vpd(float t,float rh){
    if(!valid_climate(t,rh))return NAN;
    return .6108f*expf(17.27f*t/(t+237.3f))*(1-rh*.01f);
}
float ec_relative_height(float p,float p0){
    if(!isfinite(p)||!isfinite(p0)||p<=0||p0<=0)return NAN;
    return 44330.f*(1-powf(p/p0,.1903f));
}
int ec_exposure_action(float pct,unsigned low){
    if(!isfinite(pct))return 0;
    if(pct>85)return -1;
    if(pct<8||(pct<20&&low>=2))return 1;
    return 0;
}
uint32_t ec_crc32(const void *bytes,size_t n){
    const uint8_t *p=bytes;uint32_t c=0xffffffffu;
    for(size_t i=0;i<n;i++){c^=p[i];for(int b=0;b<8;b++)c=(c>>1)^((0u-(c&1u))&0xedb88320u);}
    return ~c;
}
void ec_fft(float *r,float *im,size_t n){
    if(!r||!im||n<2||(n&(n-1)))return;
    size_t j=0;
    for(size_t i=1;i<n;i++){
        size_t bit=n>>1;while(j&bit){j^=bit;bit>>=1;}j^=bit;
        if(i<j){float t=r[i];r[i]=r[j];r[j]=t;t=im[i];im[i]=im[j];im[j]=t;}
    }
    for(size_t len=2;len<=n;len<<=1){
        float angle=-6.2831853071795864769f/(float)len;
        float wr0=cosf(angle),wi0=sinf(angle);
        for(size_t i=0;i<n;i+=len){
            float wr=1,wi=0;
            for(size_t k=0;k<len/2;k++){
                size_t a=i+k,b=a+len/2;
                float vr=r[b]*wr-im[b]*wi,vi=r[b]*wi+im[b]*wr;
                r[b]=r[a]-vr;im[b]=im[a]-vi;r[a]+=vr;im[a]+=vi;
                float next=wr*wr0-wi*wi0;wi=wr*wi0+wi*wr0;wr=next;
            }
        }
        if(len==n)break;
    }
}
float ec_a_weight_db(float f){
    if(f<=0||!isfinite(f))return -120;
    double x=(double)f*f,c1=20.6*20.6,c2=107.7*107.7,c3=737.9*737.9,c4=12200.*12200.;
    return (float)(20*log10(c4*x*x/((x+c1)*sqrt((x+c2)*(x+c3))*(x+c4)))+2);
}
float ec_c_weight_db(float f){
    if(f<=0||!isfinite(f))return -120;
    double x=(double)f*f,c1=20.6*20.6,c4=12200.*12200.;
    return (float)(20*log10(c4*x/((x+c1)*(x+c4)))+.06);
}
static int compare_float(const void *a,const void *b){float x=*(const float*)a,y=*(const float*)b;return (x>y)-(x<y);}
float ec_percentile(float *v,size_t n,float f){
    if(!v||!n||!isfinite(f)||f<0||f>1)return NAN;
    qsort(v,n,sizeof(*v),compare_float);
    float pos=(n-1)*f;size_t a=(size_t)pos,b=a+1<n?a+1:a;
    return v[a]+(v[b]-v[a])*(pos-a);
}
