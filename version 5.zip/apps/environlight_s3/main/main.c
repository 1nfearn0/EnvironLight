#include <stdlib.h>
#include "ec.h"
#include "ec_history.h"
#include "ec_sensors.h"
#include "ec_radio.h"
#include "ec_web.h"
#include "cJSON.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
static void *json_alloc(size_t n){void *p=heap_caps_malloc(n,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);return p?p:heap_caps_malloc(n,MALLOC_CAP_8BIT);}
static void history_worker(void *arg){(void)arg;TickType_t last=xTaskGetTickCount();for(;;){ec_history_tick();vTaskDelayUntil(&last,pdMS_TO_TICKS(1000));}}
void app_main(void){
    cJSON_Hooks hooks={.malloc_fn=json_alloc,.free_fn=heap_caps_free};cJSON_InitHooks(&hooks);
    ec_state_init(EC_ENVIRONLIGHT);
    esp_err_t err=nvs_flash_init();if(err!=ESP_OK)ESP_LOGE("boot","NVS unavailable (%s); existing data preserved, no automatic erase",esp_err_to_name(err));
    err=ec_history_init();if(err!=ESP_OK)ESP_LOGW("boot","History degraded: %s",esp_err_to_name(err));
    ec_sensors_start();
    err=ec_radio_start();if(err!=ESP_OK)ESP_LOGW("boot","Radio degraded: %s",esp_err_to_name(err));
    err=ec_web_start();if(err!=ESP_OK)ESP_LOGE("boot","Dashboard unavailable: %s",esp_err_to_name(err));
    if(xTaskCreate(history_worker,"history",8192,NULL,2,NULL)!=pdPASS)ec_event("history_fault","Unable to start history worker",1,0);
    ESP_LOGI("boot","EnvironLight %s ready; sensing continues without Wi-Fi or browser",EC_VERSION);
}
