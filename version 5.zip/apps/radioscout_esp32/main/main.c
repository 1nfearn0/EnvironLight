#include "ec.h"
#include "ec_history.h"
#include "ec_radio.h"
#include "ec_web.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
void app_main(void){
    ec_state_init(EC_RADIOSCOUT);esp_err_t e=nvs_flash_init();if(e!=ESP_OK)ESP_LOGE("scout","NVS unavailable, not erased: %s",esp_err_to_name(e));
    ec_history_init();e=ec_radio_start();if(e!=ESP_OK)ESP_LOGW("scout","Radio: %s",esp_err_to_name(e));
    e=ec_web_start();if(e!=ESP_OK)ESP_LOGE("scout","Web: %s",esp_err_to_name(e));
    for(;;){ec_history_tick();vTaskDelay(pdMS_TO_TICKS(1000));}
}
