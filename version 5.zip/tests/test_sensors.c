#include "ec_sensor_math.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#define PI 3.14159265358979323846

static void near(float actual,float expected,float tolerance) {
    if (fabsf(actual-expected)>tolerance) { fprintf(stderr,"actual %f expected %f\n",actual,expected); assert(0); }
}
int main(void) {
    /* Bosch datasheet's worked compensation fixture. */
    ec_bmp_cal_t c={27504,26435,-1000,36477,-10685,3024,2855,140,-7,15500,-14600,6000};
    float t,p;
    assert(ec_bmp_compensate(&c,519888,415148,&t,&p));
    near(t,25.0825f,.001f); near(p,100653.266f,.1f);
    assert(!ec_bmp_compensate(&c,0x80000,415148,&t,&p));
    c.p1=0;assert(!ec_bmp_compensate(&c,519888,415148,&t,&p));
    uint8_t d[5]={2,43,0,243,0};d[4]=(uint8_t)(d[0]+d[1]+d[2]+d[3]);
    assert(ec_dht_decode(d,&t,&p));near(t,24.3f,.001f);near(p,55.5f,.001f);
    d[2]=0x80;d[3]=57;d[4]=(uint8_t)(d[0]+d[1]+d[2]+d[3]);
    assert(ec_dht_decode(d,&t,&p));near(t,-5.7f,.001f);
    d[4]++;assert(!ec_dht_decode(d,&t,&p));
    d[0]=3;d[1]=233;d[2]=0;d[3]=200;d[4]=(uint8_t)(d[0]+d[1]+d[2]+d[3]);
    assert(!ec_dht_decode(d,&t,&p)); /* 100.1% RH cannot become a reading. */
    unsigned g=0,ti=0;
    for(unsigned i=0;i<7;i++) ec_light_exposure_step(&g,&ti,1);
    assert(g==7&&ti==0);ec_light_exposure_step(&g,&ti,1);assert(g==7&&ti==1);
    ec_light_exposure_step(&g,&ti,-1);assert(g==7&&ti==0);
    g=7;ti=3;ec_light_exposure_step(&g,&ti,1);assert(g==7&&ti==3);
    g=0;ti=0;ec_light_exposure_step(&g,&ti,-1);assert(g==0&&ti==0);
    for(unsigned i=0;i<4;i++) {
        near(ec_light_integration_ms(i),(float[]){12.51f,25.02f,50.04f,100.08f}[i],.001f);
        assert(ec_light_full_scale(i)==(EC_LIGHT_ATIME+1u)*(ec_light_astep(i)+1u));
    }
    /* Test the actual streaming filters rather than comparing coefficients. */
    const float freqs[]={125,1000,4000};
    const float expectedA[]={-16.2f,0,1.0f},expectedC[]={-.2f,0,-.9f};
    for(unsigned f=0;f<3;f++) {
        ec_weighting_t s;ec_weighting_reset(&s);double ea=0,ec=0,ez=0;
        for(unsigned n=0;n<96000;n++) {
            float x=.1f*sinf((float)(2*PI*freqs[f]*n/48000)),a,b;
            ec_weighting_sample(&s,x,&a,&b);
            if(n>=48000) { ea+=a*a;ec+=b*b;ez+=x*x; }
        }
        near((float)(10*log10(ea/ez)),expectedA[f],.4f);
        near((float)(10*log10(ec/ez)),expectedC[f],.4f);
    }
    puts("sensor math: compensation, DHT checksum/range, exposure and A/C weighting passed");
}
