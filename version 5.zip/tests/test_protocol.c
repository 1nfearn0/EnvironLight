#include "ec_protocol.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static uint32_t u32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static float fl(const uint8_t *p){uint32_t x=u32(p);float f;memcpy(&f,&x,4);return f;}
int main(void){
 ec_audio_t a={.seq=0x12345678,.t_us=0x123456789abcdef0ULL,.flags=17,.dbfs=-42,.coverage=1};
 a.spectrum[255]=231;a.wave_min[0]=-32767;a.wave_max[63]=32767;a.bands[7]=.75f;
 uint8_t bytes[EC_AUDIO_PACKET_SIZE+8];memset(bytes,0xcc,sizeof(bytes));
 assert(ec_encode_audio(&a,bytes,659)==0);assert(bytes[0]==0xcc);
 assert(ec_encode_audio(&a,bytes,sizeof(bytes))==660);
 assert(bytes[0]=='E'&&bytes[1]=='C'&&bytes[2]==1&&bytes[3]==1);
 assert(u32(bytes+4)==a.seq);assert(u32(bytes+8)==0x9abcdef0u);assert(fl(bytes+20)==-42);
 assert(fl(bytes+116+7*4)==.75f);assert(bytes[148+255]==231);assert(bytes[404]==1&&bytes[405]==128);
 assert(bytes[658]==255&&bytes[659]==127);assert(bytes[660]==0xcc);
 ec_atmos_t t={.pressure_us=123,.pressure_pa=101234,.pressure_hz=50};
 assert(ec_encode_pressure(&t,bytes,sizeof(bytes))==76);assert(bytes[3]==3);assert(fl(bytes+20)==101234);assert(fl(bytes+44)==50);
 ec_wav_header(bytes,48000*5);assert(!memcmp(bytes,"RIFF",4));assert(!memcmp(bytes+8,"WAVEfmt ",8));assert(u32(bytes+24)==48000);assert(u32(bytes+40)==960000);assert(u32(bytes+4)==960036);assert(bytes[34]==32);
 puts("PASS: binary endian/layout, packet bounds and WAV duration/header");
}
