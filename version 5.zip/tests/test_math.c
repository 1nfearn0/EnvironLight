#include "ec_math.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static void near(float actual,float expected,float eps){assert(isfinite(actual));assert(fabsf(actual-expected)<eps);}
int main(void){
    ec_energy_t e={0};ec_energy_add(&e,40,1);ec_energy_add(&e,60,1);near(ec_energy_db(&e),57.0329f,.001f);
    ec_energy_t empty={0};assert(isnan(ec_energy_db(&empty)));ec_energy_add(&e,NAN,1);assert(e.count==2);
    near(ec_dew_point(20,50),9.255f,.02f);near(ec_absolute_humidity(20,50),8.62f,.04f);
    assert(isnan(ec_dew_point(20,0)));assert(isnan(ec_absolute_humidity(NAN,50)));
    near(ec_relative_height(101325,101325),0,.001f);assert(ec_relative_height(101313,101325)>0);
    assert(ec_exposure_action(86,0)==-1);assert(ec_exposure_action(50,10)==0);
    assert(ec_exposure_action(15,1)==0);assert(ec_exposure_action(15,2)==1);assert(ec_exposure_action(4,0)==1);
    assert(ec_crc32("123456789",9)==0xcbf43926u);
    float r[2048],im[2048];for(int i=0;i<2048;i++){r[i]=sinf(2*3.14159265358979323846f*64*i/2048);im[i]=0;}
    ec_fft(r,im,2048);near(hypotf(r[64],im[64]),1024,.1f);assert(hypotf(r[65],im[65])<.1f);
    near(ec_a_weight_db(1000),0,.05f);near(ec_c_weight_db(1000),0,.05f);
    float p[]={1,2,3,4,5};near(ec_percentile(p,5,.5f),3,.001f);
    puts("PASS: energy, climate, height, exposure, CRC, FFT and weighting");
}
