#include "ec_radio_registry.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static ec_radio_registry_t registry;

int main(void)
{
    ec_radio_registry_observe(&registry, "b0000000000000001", "Phone", "180f", -60, 1000, 1720000000);
    assert(registry.advertisements == 1);
    assert(ec_radio_anonymous_count(&registry, 1000) == 1);
    assert(ec_radio_registry_enroll(&registry, "b0000000000000001", "Ollie phone", "0123456789abcdef0123456789abcdef", 1100, 1720000000) == 0);
    ec_radio_known_t *k = ec_radio_registry_find(&registry, "b0000000000000001");
    assert(k && !strcmp(k->name, "Ollie phone"));
    assert(ec_radio_anonymous_count(&registry, 1100) == 0);
    assert(!strcmp(ec_radio_presence(k, 1100), "present"));
    assert(!strcmp(ec_radio_presence(k, 32000), "probable"));
    assert(!strcmp(ec_radio_presence(k, 122000), "away"));
    ec_radio_registry_observe(&registry, k->id, "Phone", "180f", -40, 130000, 1720000130);
    assert(k->rssi == -55.0f);
    assert(!strcmp(ec_radio_presence(k, 130000), "present"));
    k->enabled = false;
    assert(!strcmp(ec_radio_presence(k, 140000), "archived"));
    ec_radio_registry_observe(&registry, k->id, "Phone", "180f", -30, 140000, 1720000140);
    assert(k->seen_ms == 130000); /* Disabled entries do not accumulate evidence. */
    assert(ec_radio_anonymous_count(&registry, 140000) == 0);
    ec_radio_registry_expire(&registry, 261000);
    assert(ec_radio_anonymous_count(&registry, 261000) == 0);
    assert(k->used); /* Anonymous expiration never removes enrolled names. */
    k->enabled = true;
    k->seen_this_boot = false;
    assert(!strcmp(ec_radio_presence(k, 0), "unknown"));
    assert(ec_radio_registry_enroll(&registry, "b9999999999999999", "missing", "x", 0, 0) == -1);
    assert(ec_radio_registry_enroll(&registry, NULL, "missing", "x", 0, 0) == -3);
    assert(ec_radio_registry_enroll(&registry, k->id, "", "x", 0, 0) == -3);
    ec_radio_registry_observe(&registry, "a0000000000000001", "", "wifi_ap", -50, 150000, 0);
    assert(ec_radio_anonymous_count(&registry, 150000) == 0); /* APs are not BLE density. */
    assert(ec_radio_registry_enroll(&registry, "a0000000000000001", "Home AP", "uuid", 150001, 0) == 0);
    assert(ec_radio_registry_find(&registry, "a0000000000000001"));

    memset(&registry, 0, sizeof(registry));
    for (unsigned i = 0; i < EC_RADIO_OBSERVATIONS + 10; ++i) {
        char id[EC_RADIO_ID_LEN];
        snprintf(id, sizeof(id), "b%016x", i);
        ec_radio_registry_observe(&registry, id, "", "", -50, i + 1, 0);
    }
    assert(ec_radio_anonymous_count(&registry, 100) == EC_RADIO_OBSERVATIONS);
    assert(registry.observation_evictions == 10);
    assert(registry.advertisements == EC_RADIO_OBSERVATIONS + 10);
    for (unsigned i = 10; i < EC_RADIO_KNOWN + 10; ++i) {
        char id[EC_RADIO_ID_LEN]; snprintf(id, sizeof(id), "b%016x", i);
        assert(ec_radio_registry_enroll(&registry, id, "named", "uuid", 100, 0) == 0);
    }
    assert(ec_radio_registry_enroll(&registry, "b0000000000000022", "overflow", "uuid", 100, 0) == -2);
    assert(ec_radio_anonymous_count(&registry, 100) == EC_RADIO_OBSERVATIONS - EC_RADIO_KNOWN);
    ec_radio_registry_expire(&registry, EC_RADIO_ANONYMOUS_TTL_MS + 100);
    assert(ec_radio_anonymous_count(&registry, EC_RADIO_ANONYMOUS_TTL_MS + 100) == 0);
    puts("radio registry: bounded eviction, enrollment, presence, restart and expiration passed");
    return 0;
}
