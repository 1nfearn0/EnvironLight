/* Host integration test of the production service; only platform APIs are
 * mocked. Link the system cJSON library and ec_math.c. No ESP board required. */
#define _POSIX_C_SOURCE 200809L
#define EC_HISTORY_HOST_TEST 1
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "ec.h"

typedef struct cJSON cJSON;
cJSON *cJSON_CreateObject(void);
cJSON *cJSON_CreateNumber(double);
cJSON *cJSON_CreateNull(void);
cJSON *cJSON_AddArrayToObject(cJSON *, const char *);
cJSON *cJSON_AddObjectToObject(cJSON *, const char *);
cJSON *cJSON_AddNumberToObject(cJSON *, const char *, double);
cJSON *cJSON_AddStringToObject(cJSON *, const char *, const char *);
cJSON *cJSON_AddNullToObject(cJSON *, const char *);
cJSON *cJSON_AddBoolToObject(cJSON *, const char *, int);
int cJSON_AddItemToArray(cJSON *, cJSON *);
int cJSON_InsertItemInArray(cJSON *, int, cJSON *);
int cJSON_ReplaceItemInObject(cJSON *, const char *, cJSON *);
cJSON *cJSON_GetObjectItemCaseSensitive(const cJSON *, const char *);
cJSON *cJSON_GetArrayItem(const cJSON *, int);
int cJSON_GetArraySize(const cJSON *);
double cJSON_GetNumberValue(const cJSON *);
int cJSON_IsNull(const cJSON *);
void cJSON_Delete(cJSON *);

typedef int esp_err_t;
enum { ESP_OK, ESP_FAIL, ESP_ERR_INVALID_STATE, ESP_ERR_NO_MEM, ESP_ERR_INVALID_ARG };
typedef void *SemaphoreHandle_t;
enum { pdTRUE=1, MALLOC_CAP_SPIRAM=1, MALLOC_CAP_8BIT=2, NVS_READONLY=0, NVS_READWRITE=1 };
#define pdMS_TO_TICKS(x) (x)
typedef struct { const char *base_path, *partition_label; bool format_if_mount_failed, dont_mount; } esp_vfs_littlefs_conf_t;
typedef int nvs_handle_t;
static unsigned char nvs_bytes[8192];
static size_t nvs_length;
static bool nvs_fail_commit;
static ec_snapshot_t fixture;

static SemaphoreHandle_t xSemaphoreCreateMutex(void) { static int v; return &v; }
static int xSemaphoreTake(SemaphoreHandle_t s, unsigned wait) { (void)s; (void)wait; return pdTRUE; }
static void xSemaphoreGive(SemaphoreHandle_t s) { (void)s; }
static void *heap_caps_calloc(size_t n,size_t bytes,unsigned flags) { (void)flags; return calloc(n,bytes); }
static esp_err_t esp_vfs_littlefs_register(const esp_vfs_littlefs_conf_t *c) { assert(!c->format_if_mount_failed); return ESP_OK; }
static bool esp_littlefs_mounted(const char *label) { (void)label; return true; }
static esp_err_t esp_littlefs_info(const char *label,size_t *total,size_t *used) { (void)label; *total=0x5F0000; *used=0; return ESP_OK; }
static esp_err_t nvs_open(const char *name,int mode,nvs_handle_t *h) { (void)name; (void)mode; *h=1; return ESP_OK; }
static esp_err_t nvs_get_blob(nvs_handle_t h,const char *key,void *out,size_t *length) { (void)h; (void)key; if(!nvs_length || *length<nvs_length) return ESP_FAIL; memcpy(out,nvs_bytes,nvs_length); *length=nvs_length; return ESP_OK; }
static esp_err_t nvs_set_blob(nvs_handle_t h,const char *key,const void *bytes,size_t length) { (void)h; (void)key; assert(length<=sizeof(nvs_bytes)); memcpy(nvs_bytes,bytes,length); nvs_length=length; return ESP_OK; }
static esp_err_t nvs_commit(nvs_handle_t h) { (void)h; return nvs_fail_commit?ESP_FAIL:ESP_OK; }
static void nvs_close(nvs_handle_t h) { (void)h; }
void ec_get_snapshot(ec_snapshot_t *out) { *out=fixture; }
size_t ec_events_copy(ec_event_t *out,size_t capacity,uint32_t after) { (void)out; (void)capacity; (void)after; return 0; }

#include "../components/ec_core/ec_history.c"

static void near_value(double actual,double expected,double tolerance) { assert(isfinite(actual)); assert(fabs(actual-expected)<tolerance); }
static double field(cJSON *o,const char *key) { return cJSON_GetNumberValue(cJSON_GetObjectItemCaseSensitive(o,key)); }
static void sample(unsigned second)
{
    fixture.uptime_us=(uint64_t)second*1000000; fixture.epoch_s=1800000000u+second; fixture.boot_id=42;
    fixture.audio.t_us=fixture.light.t_us=fixture.atmos.climate_us=fixture.atmos.pressure_us=fixture.uptime_us;
    fixture.audio.dbfs=-50; fixture.audio.leq_1s=45; fixture.audio.peak_dbfs=-35; fixture.audio.coverage=1;
    fixture.light.centroid_nm=550;
    for(unsigned i=0;i<8;++i) { fixture.light.profile[i]=.125f; fixture.light.basic[i]=10; }
    fixture.atmos.temperature_c=21; fixture.atmos.humidity_rh=55; fixture.atmos.pressure_pa=101325;
    ec_history_tick();
}

int main(void)
{
    /* A 20 dB level difference must produce an energy mean near 57.03 dB,
     * rather than the incorrect arithmetic mean of 50 dB. */
    aggregate_t aggregate={0};
    history_record_t a={.magic=EC_HISTORY_MAGIC,.seq=1,.span_s=1,.observed_s=1,.audio_n=1,.audio_ms=1000,.dbfs_cdb=4000,.dba_cdb=4000,.peak_cdb=4100};
    history_record_t b=a; b.seq=2; b.dbfs_cdb=b.dba_cdb=6000; b.peak_cdb=6100;
    aggregate_add(&aggregate,&a); aggregate_add(&aggregate,&b);
    history_record_t combined=aggregate_finish(&aggregate,2);
    near_value(signed_value(combined.dba_cdb,100),57.03,.01);
    assert(combined.peak_cdb==6100 && combined.audio_ms==2000);
    b.audio_ms=0; aggregate_t missing={0}; aggregate_add(&missing,&b);
    history_record_t absent=aggregate_finish(&missing,1);
    assert(absent.dba_cdb==INT16_MISSING);

    char directory[]="/tmp/ec-history-XXXXXX"; assert(mkdtemp(directory));
    char p10[128],p60[128],pevent[128],ptest[128];
    snprintf(p10,sizeof(p10),"%s/ten.bin",directory); snprintf(p60,sizeof(p60),"%s/minute.bin",directory);
    snprintf(pevent,sizeof(pevent),"%s/events.bin",directory); snprintf(ptest,sizeof(ptest),"%s/wrap.bin",directory);
    ten.path=p10; minute.path=p60; events.path=pevent;
    assert(ec_history_init()==ESP_OK);
    for(unsigned i=1;i<300;++i) sample(i);
    assert(ec_scene_capture("Daylight")==ESP_ERR_INVALID_STATE);
    sample(300); assert(ec_scene_capture("Daylight")==ESP_OK);
    cJSON *scene_list=ec_scenes_json(); cJSON *list=cJSON_GetObjectItemCaseSensitive(scene_list,"scenes");
    assert(cJSON_GetArraySize(list)==1); cJSON *scene=cJSON_GetArrayItem(list,0);
    near_value(field(scene,"dba_est"),45,.01); near_value(field(scene,"temperature_c"),21,.01);
    cJSON_Delete(scene_list);
    nvs_fail_commit=true; assert(ec_scene_capture("Not committed")==ESP_FAIL); assert(scenes.count==1); nvs_fail_commit=false;
    for(unsigned i=301;i<=3605;++i) sample(i);
    assert(ram_count==3600);
    cJSON *page=ec_history_json(1,3,0); list=cJSON_GetObjectItemCaseSensitive(page,"records");
    assert(cJSON_GetArraySize(list)==3); near_value(field(cJSON_GetArrayItem(list,0),"seq"),3603,.01);
    near_value(field(page,"next_before_seq"),3603,.01); cJSON_Delete(page);
    page=ec_history_json(1,3,3603); list=cJSON_GetObjectItemCaseSensitive(page,"records");
    near_value(field(cJSON_GetArrayItem(list,2),"seq"),3602,.01); cJSON_Delete(page);
    page=ec_history_json(10,2,0); list=cJSON_GetObjectItemCaseSensitive(page,"records");
    assert(cJSON_GetArraySize(list)==2); near_value(field(cJSON_GetArrayItem(list,1),"dba_est"),45,.01); cJSON_Delete(page);
    page=ec_history_json(300,20,0); list=cJSON_GetObjectItemCaseSensitive(page,"records");
    assert(cJSON_GetArraySize(list)==12); near_value(field(cJSON_GetArrayItem(list,11),"span_s"),300,.01);
    near_value(field(cJSON_GetArrayItem(list,11),"audio_coverage"),1,.01); cJSON_Delete(page);
    page=ec_history_json(3600,2,0); list=cJSON_GetObjectItemCaseSensitive(page,"records");
    assert(cJSON_GetArraySize(list)==1); near_value(field(cJSON_GetArrayItem(list,0),"span_s"),3600,.01);
    near_value(field(cJSON_GetArrayItem(list,0),"audio_coverage"),1,.01); cJSON_Delete(page);

    /* Capacity-three flash ring: wrap, corrupt one middle record, reboot, and
     * ensure the newest intact record and write cursor are recovered. */
    disk_ring_t ring={.path=ptest,.resolution_s=10,.record_bytes=sizeof(history_record_t)};
    disk_open(&ring,3); assert(ring.file && ring.capacity==3);
    for(unsigned seq=100;seq<=103;++seq) {
        a.seq=seq; a.crc=ec_crc32(&a,offsetof(history_record_t,crc)); assert(disk_append(&ring,&a,seq));
    }
    assert(ring.head==1 && ring.slots==3);
    unsigned char corrupt=0xff;
    assert(fseek(ring.file,(long)sizeof(file_header_t)+(long)sizeof(history_record_t)+4,SEEK_SET)==0);
    assert(fwrite(&corrupt,1,1,ring.file)==1); assert(fflush(ring.file)==0); fclose(ring.file);
    ring=(disk_ring_t){.path=ptest,.resolution_s=10,.record_bytes=sizeof(history_record_t)};
    disk_open(&ring,3); assert(ring.newest_seq==103 && ring.head==1 && ring.crc_errors==1);
    history_record_t recovered; assert(disk_read(&ring,0,&recovered) && recovered.seq==103);
    a.seq=104; a.crc=ec_crc32(&a,offsetof(history_record_t,crc)); assert(disk_append(&ring,&a,104)); fclose(ring.file);

    /* A partial final write must leave all earlier complete records intact. */
    FILE *tail=fopen(ptest,"ab"); assert(tail); assert(fwrite("torn",4,1,tail)==1); fclose(tail);
    ring=(disk_ring_t){.path=ptest,.resolution_s=10,.record_bytes=sizeof(history_record_t)};
    disk_open(&ring,3); assert(ring.newest_seq==104 && ring.crc_errors==1); fclose(ring.file);
    /* Exhaustively exercise binary page location across every pattern of CRC
     * gaps in an eight-slot ring, including an entirely damaged interval. */
    ram_capacity=8; ram_head=0;
    for(unsigned holes=0;holes<256;++holes) {
        for(unsigned back=0;back<8;++back) ram[7-back].seq=(holes&(1u<<back))?0:100-back;
        for(unsigned before=90;before<=102;++before) {
            unsigned expected=8;
            for(unsigned back=0;back<8;++back) if(ram[7-back].seq && prior(ram[7-back].seq,before)) { expected=back; break; }
            unsigned start=page_start(NULL,8,before);
            assert(start<=expected);
            for(unsigned back=start;back<expected;++back) assert(ram[7-back].seq==0);
        }
    }
    fclose(ten.file); fclose(minute.file); fclose(events.file); free(ram);
    remove(p10); remove(p60); remove(pevent); remove(ptest); assert(remove(directory)==0);
    puts("PASS: production history energy means, missing data, five-minute scenes, commit failure, RAM/flash wrap, pagination, CRC/reboot/torn-write recovery");
    return 0;
}
