# EnvironCore v0.5.0-dev1 flashing notes

The release contains one merged image per target for straightforward first
flashing, plus the individual ESP-IDF artifacts for normal development.

## EnvironLight — ESP32-S3-WROOM-1 N16R8

Flash `environlight_s3/environlight_v0_5_merged.bin` at address `0x0` on a
16 MB ESP32-S3 device. The equivalent individual layout is:

| Address | File |
|---:|---|
| `0x0` | `bootloader.bin` |
| `0x8000` | `partition-table.bin` |
| `0xe000` | `ota_data_initial.bin` |
| `0x10000` | `environlight_v0_5.bin` |

## RadioScout — DOIT ESP32-WROOM-32D (future/disabled profile)

Flash `radioscout_esp32/radioscout_v0_5_merged.bin` at address `0x0` on a
4 MB classic ESP32. The equivalent individual layout is:

| Address | File |
|---:|---|
| `0x1000` | `bootloader.bin` |
| `0x8000` | `partition-table.bin` |
| `0x10000` | `radioscout_v0_5.bin` |

## Important

These binaries were deliberately built with blank Wi-Fi credentials, API key
and OTA signing key. They provide safe build evidence and a read-only starting
image. Configure the network, an API key of at least 16 characters and (when
needed) a separate OTA key of at least 32 characters through ESP-IDF
`menuconfig`, then rebuild before relying on control actions or OTA.

RadioScout is included as a future family member but remains disabled by
default until its hardware and coexistence behaviour have been qualified.
