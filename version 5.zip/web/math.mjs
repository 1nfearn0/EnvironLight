/** Pure instrument maths. Missing observations remain missing. */
export const WAVELENGTHS = [415,445,480,515,555,590,630,680];
export const finite = v => typeof v === 'number' && Number.isFinite(v);
export const mean = a => { const x=a.filter(finite); return x.length ? x.reduce((s,v)=>s+v,0)/x.length : null; };
export function normalise(a) { const m=mean(a); if(m===null)return a.map(()=>null); const sd=Math.sqrt(mean(a.map(v=>finite(v)?(v-m)**2:null))) || 1; return a.map(v=>finite(v)?(v-m)/sd:null); }
export function pchip(xs,ys,steps=20) {
  if(xs.length!==ys.length || xs.length<2 || !xs.every(finite) || !ys.every(finite)) return [[],[]];
  const n=xs.length,h=[],d=[]; for(let i=0;i<n-1;i++){h[i]=xs[i+1]-xs[i];if(h[i]<=0)return [[],[]];d[i]=(ys[i+1]-ys[i])/h[i];}
  const m=new Array(n).fill(0); const endpoint=(h0,h1,d0,d1)=>{let v=((2*h0+h1)*d0-h0*d1)/(h0+h1);if(Math.sign(v)!==Math.sign(d0))v=0;else if(Math.sign(d0)!==Math.sign(d1)&&Math.abs(v)>3*Math.abs(d0))v=3*d0;return v;};
  if(n===2)m[0]=m[1]=d[0];else{m[0]=endpoint(h[0],h[1],d[0],d[1]);m[n-1]=endpoint(h[n-2],h[n-3],d[n-2],d[n-3]);for(let i=1;i<n-1;i++)if(d[i-1]*d[i]>0){const w1=2*h[i]+h[i-1],w2=h[i]+2*h[i-1];m[i]=(w1+w2)/(w1/d[i-1]+w2/d[i]);}}
  const x=[],y=[];for(let i=0;i<n-1;i++)for(let k=0;k<steps;k++){const t=k/steps,t2=t*t,t3=t2*t;x.push(xs[i]+h[i]*t);y.push((2*t3-3*t2+1)*ys[i]+(t3-2*t2+t)*h[i]*m[i]+(-2*t3+3*t2)*ys[i+1]+(t3-t2)*h[i]*m[i+1]);}x.push(xs[n-1]);y.push(ys[n-1]);return [x,y];
}
export function phaseSpace(values,delay=3,limit=180) { const z=normalise(values),out=[];for(let i=delay;i<z.length;i++)if(finite(z[i])&&finite(z[i-delay]))out.push({x:z[i-delay],y:z[i],index:i});return out.slice(-limit); }
export function recurrence(values,{delay=3,epsilon=.35,limit=160,theiler=1}={}) {
  const points=phaseSpace(values,Math.max(1,delay),limit),n=points.length,grid=new Uint8Array(n*n);let hits=0,possible=0;
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){if(Math.abs(points[i].index-points[j].index)<=theiler)continue;possible++;if(Math.hypot(points[i].x-points[j].x,points[i].y-points[j].y)<=epsilon){grid[i*n+j]=1;hits++;}}
  let diagonal=0,vertical=0;for(let i=0;i<n;i++)for(let j=0;j<n;j++)if(grid[i*n+j]){if(i===0||j===0||!grid[(i-1)*n+j-1]){let k=0;while(i+k<n&&j+k<n&&grid[(i+k)*n+j+k])k++;if(k>=2)diagonal+=k;}if(i===0||!grid[(i-1)*n+j]){let k=0;while(i+k<n&&grid[(i+k)*n+j])k++;if(k>=2)vertical+=k;}}
  return {points,n,grid,rate:possible?hits/possible:null,determinism:hits?diagonal/hits:null,laminarity:hits?vertical/hits:null,hits};
}
export function pearson(a,b){const pairs=a.map((v,i)=>[v,b[i]]).filter(p=>p.every(finite));if(pairs.length<3)return null;const ax=mean(pairs.map(p=>p[0])),by=mean(pairs.map(p=>p[1]));let s=0,x=0,y=0;for(const [v,w]of pairs){s+=(v-ax)*(w-by);x+=(v-ax)**2;y+=(w-by)**2;}return x&&y?s/Math.sqrt(x*y):null;}
export function historyTime(row){return finite(row.epoch_s)&&row.epoch_s>1e9?row.epoch_s:finite(row.t_us)?row.t_us/1e6:null;}
export function alignedHistory(rows,keys){const valid=rows.filter(r=>finite(historyTime(r)));const x=[],out=keys.map(()=>[]);let prev=null;for(const r of valid){const t=historyTime(r),gap=prev&&(r.boot_id!==prev.boot_id||t-historyTime(prev)>Math.max(2,(r.span_s||1)*2.5));if(gap){x.push(t-.001);out.forEach(a=>a.push(null));}x.push(t);keys.forEach((k,i)=>out[i].push(finite(r[k])?r[k]:null));prev=r;}return[x,...out];}
export function csv(rows,keys){const quote=v=>v===null||v===undefined?'':`"${String(v).replaceAll('"','""')}"`;return keys.join(',')+'\r\n'+rows.map(r=>keys.map(k=>quote(r[k])).join(',')).join('\r\n');}
