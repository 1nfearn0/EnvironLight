#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build-host
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -g -Icomponents/ec_core/include tests/test_math.c components/ec_core/ec_math.c -lm -o build-host/test-math
ASAN_OPTIONS=detect_leaks=0 ./build-host/test-math
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -g -Icomponents/ec_core/include tests/test_protocol.c components/ec_core/ec_protocol.c -lm -o build-host/test-protocol
ASAN_OPTIONS=detect_leaks=0 ./build-host/test-protocol
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -g -Icomponents/ec_sensors/include tests/test_sensors.c components/ec_sensors/ec_sensor_math.c -lm -o build-host/test-sensors
ASAN_OPTIONS=detect_leaks=0 ./build-host/test-sensors
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -g -Icomponents/ec_radio/include tests/test_radio_registry.c components/ec_radio/ec_radio_registry.c -lm -o build-host/test-radio-registry
ASAN_OPTIONS=detect_leaks=0 ./build-host/test-radio-registry
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -g -Icomponents/ec_core/include tests/test_history.c components/ec_core/ec_math.c -Wl,-l:libcjson.so.1 -lm -o build-host/test-history
ASAN_OPTIONS=detect_leaks=0 ./build-host/test-history
node --test tests/*.test.mjs
