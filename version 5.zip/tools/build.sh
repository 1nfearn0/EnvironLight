#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
target=${1:-environlight_s3}
case "$target" in environlight_s3|radioscout_esp32) ;; *) echo "Use environlight_s3 or radioscout_esp32" >&2; exit 2;; esac
shift "$(( $# > 0 ? 1 : 0 ))"
cd "apps/$target"
exec idf.py "$@" build
