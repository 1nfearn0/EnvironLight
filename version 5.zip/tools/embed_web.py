#!/usr/bin/env python3
"""Create deterministic gzip C assets from the maintainable web source tree."""
import gzip,json,sys,mimetypes
from pathlib import Path
web,out=map(Path,sys.argv[1:3]);out.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in web.rglob('*') if p.is_file() and p.suffix in {'.html','.js','.mjs','.css','.svg','.json','.woff2'})
header='''#pragma once
#include <stddef.h>
#include <stdint.h>
typedef struct { const char *path,*type; const uint8_t *data; size_t length; } ec_asset_t;
extern const ec_asset_t ec_assets[];
extern const size_t ec_assets_count;
'''
c=['#include "ec_assets.h"'];records=[]
for i,p in enumerate(files):
 data=gzip.compress(p.read_bytes(),compresslevel=9,mtime=0);name=f'asset_{i}'
 c.append('static const uint8_t '+name+'[] = {'+','.join(map(str,data))+'};')
 mime={'.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.json':'application/json'}.get(p.suffix,'application/octet-stream')
 records.append('{'+json.dumps('/'+p.relative_to(web).as_posix())+','+json.dumps(mime)+','+name+f',sizeof({name})'+'}')
c.append('const ec_asset_t ec_assets[] = {'+','.join(records)+'};\nconst size_t ec_assets_count = sizeof(ec_assets)/sizeof(ec_assets[0]);')
(out/'ec_assets.h').write_text(header);(out/'ec_assets.c').write_text('\n'.join(c)+'\n')
print(f'Embedded {len(files)} local web assets')
