param([ValidateSet("environlight_s3","radioscout_esp32")][string]$Profile="environlight_s3",[string]$Port="")
$ErrorActionPreference="Stop"
Push-Location (Join-Path $PSScriptRoot "../apps/$Profile")
try {
    idf.py build
    if ($LASTEXITCODE -ne 0) { throw "Build failed" }
    if ($Port) { idf.py -p $Port app-flash monitor }
} finally { Pop-Location }
